#!/usr/bin/env python3
"""Arm a validated goal: the fence that validates and binds an authorized run.

Arming used to be a shell fence in the command body, and three findings were
its fault class: a script path no root variable reached, a validation step
whose failure prose could be talked past, and an unconditional overwrite of
`.goals/active` that silently retargeted every hook in the directory. A
function call whose exception is the refusal makes those structurally
impossible rather than guarded - which is why this file exists even though
the shell fence could have been patched.

What arming must establish, before any Stop can run:

- the artifact and its decisions record exist and validate (errors refuse);
- another goal is not already armed - a different slug refuses, because
  overwriting it redirected an owner-authorized run, and disarming is an
  explicit owner act (`disarm`);
- the run's authorized spec baseline is recorded once, from the artifact as
  it stands at arming, into `.goals/<slug>.spec.baseline` using the legacy
  digest. Objective goals also record the full digest in `objective.baseline`.
  The gate compares every later Stop against those files and never against a digest found in
  the event log - the run can write the log, and round 4's laundering probe
  replaced it with a run-authored row carrying an edited digest and was
  allowed through. The file is deliberately NOT gitignored (`.goals/.gitignore`
  covers only the run-private files), so an authorized commit can preserve it
  and make later rewrites visible;
- the review baseline is the Git revision by default, or `none` only after an
  explicit `--allow-no-git` choice; it is write-once, so a re-arm cannot hand
  the reviewer an empty range;
- `.goals/.gitignore` names the run-private files, `*.candidate` included -
  a live claim must not ride into a commit.

`diff` prints the reviewer's range from the same baseline file the review
and critic skills read, with the same ancestor guard: a baseline that is no
longer an ancestor of HEAD means history moved under the run, and the
honest output says the range is unreliable instead of trusting the diff.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path
import re
import subprocess
import statistics
import sys
import uuid

sys.path.insert(0, str(Path(__file__).resolve().parent))
from goal_hooks import (  # noqa: E402
    SPEC_BASELINE_SUFFIX,
    OBJECTIVE_BASELINE_SUFFIX,
    _read_marker,
    _valid_slug,
    _valid_session,
    frozen_digest,
    legacy_frozen_digest,
    frozen_baselines_match,
    read_events,
    active_goal,
    ActiveGoal,
    append_event,
    completion_attempt,
    completion_attempts,
    sections,
)
from validate_artifact import validate_paths  # noqa: E402
from goal_contract import (pin_verification, check_protection, input_digest, check_review,
                           objective, objective_state, objective_margin, check_product,
                           verification_lock, product_tree, evaluate_commit, pin_objective_environment,
                           objective_environment, verification, under_paths, snapshot,
                           _tracked_paths)  # noqa: E402


GIT_BASELINE_SUFFIX = ".baseline"
IGNORE_ENTRIES = (".work/", "active", "*.candidate", "*.verification.lock", "*.driver.json", "*.driver.lock", "*.driver.tmp", "*.driver.interrupt")
PACKAGE_CONFIRMATION = "confirm package checkpoint"
FROZEN_CONFIRMATION = re.compile(r"\bfrozen:([0-9a-f]{12})\b", re.I)


def package_confirmation_digest(path: Path) -> str | None:
    """Read the final owner row without treating it as authenticated consent."""
    text = path.read_text(encoding="utf-8").split("\n## ", 1)[0]
    rows = [line.strip() for line in text.splitlines() if line.strip().startswith("|")]
    header = next((row for row in rows if "decision" in row.lower()), None)
    if header is None:
        return None
    headings = [cell.strip().lower() for cell in header.strip("|").split("|")]
    if not {"decision", "why", "who"} <= set(headings):
        return None
    decision_index, why_index, who_index = (
        headings.index("decision"), headings.index("why"), headings.index("who")
    )
    for row in rows[rows.index(header) + 1 :]:
        cells = [cell.strip() for cell in row.strip("|").split("|")]
        if len(cells) <= max(decision_index, why_index, who_index):
            continue
        if (cells[decision_index].strip("` ").lower() == PACKAGE_CONFIRMATION
                and cells[who_index].lower() == "owner"):
            match = FROZEN_CONFIRMATION.search(cells[why_index])
            return match.group(1).lower() if match else None
    return None


def initiating_session(explicit: str | None = None) -> str:
    """Resolve a native identity before arming; never infer it from a hook.

    A nested host can inherit even a single parent's identity variable.
    Therefore no environment variable is selected implicitly.
    """
    if explicit is not None:
        session = _valid_session(explicit)
        if session is not None:
            return session
        raise ValueError("Invalid --session-id; use the current native session ID.")
    raise ValueError(
        "An explicit initiating session ID is required before arming. Pass "
        "--session-id <current-native-session-id>; do not guess, copy another "
        "task's ID, or wait for the first Stop to claim this goal."
    )


def _git(root: Path, *args: str) -> subprocess.CompletedProcess:
    command = ["git", "-C", str(root), *args]
    try:
        return subprocess.run(command, capture_output=True, text=True, timeout=30)
    except (OSError, subprocess.SubprocessError) as exc:
        return subprocess.CompletedProcess(command, 127, "", str(exc))


def _write_once(path: Path, text: str) -> bool:
    """Write `text` to `path` only if it holds nothing. True if it holds it now.

    Write-once is what makes a baseline evidence rather than a suggestion:
    the arming revision survives re-arms and restarts, and a run that wants
    it moved has to delete it. Git preserves that change only if committed.
    """
    if path.is_file() and path.read_text(encoding="utf-8").strip():
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    return True


def _armed_slug(marker: Path) -> str | None:
    """The marker's slug line - the first line, never the whole file.

    Arming writes both slug and session identity. Compare only the slug here;
    ownership checks are separate and a rebind explicitly changes the session.
    """
    slug, _session = _read_marker(marker)
    return slug


def arm(
    root: Path,
    slug: str,
    session_id: str | None = None,
    allow_no_git: bool = False,
) -> str:
    if _valid_slug(slug) != slug:
        raise ValueError("Expected a goal slug, not a path.")
    session = initiating_session(session_id)
    goals = root / ".goals"
    goal_file = goals / f"{slug}.goal.md"
    decisions = goals / f"{slug}.decisions.md"
    if not goal_file.is_file() or not decisions.is_file():
        raise ValueError(
            "The goal or paired decisions record is missing. Do not author one "
            "here - that is the interview's job, and a run against an artifact "
            "nobody agreed to is the failure this design exists to prevent."
        )
    marker = goals / "active"
    legacy_resume = marker.is_file() and _armed_slug(marker) == slug
    report = validate_paths([str(goal_file), str(decisions)])
    errors = [
        finding for finding in report.findings
        if finding.severity == "error"
        and not (legacy_resume and finding.code.startswith("OWNER_CONFIRMATION_"))
    ]
    if errors:
        raise ValueError(
            "Artifact validation failed: " + "; ".join(f.message for f in errors)
        )

    definition = objective(goal_file.read_text(encoding="utf-8"))
    if definition is not None and _git(root, "rev-parse", "--verify", "HEAD^{commit}").returncode:
        raise ValueError("Objective requires a usable Git HEAD, even with --allow-no-git; the incumbent must be restorable.")
    if definition is not None:
        # Evaluations run clean checkouts of commits, so an evaluator file that exists only
        # in this work tree would be judged by a checkout that lacks it.
        # Files Git ignores count too: `git status` would not list them.
        evaluator = [path for path in verification(goal_file.read_text(encoding="utf-8"))["protected"]
                     if not under_paths(path, definition["inputs"])]
        tracked = set(_tracked_paths(root, "HEAD"))
        pending = sorted(path for path in snapshot(root, evaluator)
                         if path not in tracked and not under_paths(path, definition["inputs"]))
        if evaluator and _git(root, "diff", "--quiet", "HEAD", "--", *evaluator).returncode:
            pending.append("(modified since HEAD)")
        if pending:
            raise ValueError("Optimization mode evaluates commits: commit the protected evaluator files before "
                             "arming. Uncommitted: " + " ".join(pending[:12]))

    if not legacy_resume:
        recorded = package_confirmation_digest(decisions)
        current = frozen_digest(goal_file.read_text(encoding="utf-8"))
        if recorded != current:
            raise ValueError(
                "OWNER_CONFIRMATION_STALE: the package confirmation does not match "
                "the current frozen goal terms. Read back checkpoint C again, then "
                "replace its frozen digest before arming."
            )
    audit_goal = ActiveGoal(slug, goals, goal_file, goals / f"{slug}.events.jsonl", decisions, marker, session,
                            spec_baseline_path=goals / f"{slug}{SPEC_BASELINE_SUFFIX}")
    prior_events = read_events(audit_goal)
    if any(e.get("event") == "frozen_spec_changed" for e in prior_events):
        raise ValueError("This goal was closed after frozen conditions changed; start a newly authorized goal.")
    prior_spec = goals / f"{slug}{SPEC_BASELINE_SUFFIX}"
    prior_objective = goals / f"{slug}{OBJECTIVE_BASELINE_SUFFIX}"
    if (prior_spec.exists() or prior_objective.exists()) and not frozen_baselines_match(audit_goal, goal_file.read_text()):
        raise ValueError("Frozen conditions differ from the armed baseline; start a newly authorized goal.")
    if marker.is_file() and _armed_slug(marker) is not None:
        current = _armed_slug(marker)
        if current != slug:
            raise ValueError(
                f"Another goal is armed ({current}); disarm it explicitly first "
                "(`goal_run.py disarm <slug>`). Arming must never silently "
                "retarget the hooks of a running goal."
            )
        _, owner_session = _read_marker(marker)
        if owner_session != session:
            raise ValueError(
                "This goal belongs to another session or has a legacy unbound "
                "marker. Only an owner-authorized `rebind` may transfer it; "
                "ordinary arming cannot take over a run."
            )
        # Same slug: idempotent re-arm. The baselines are write-once and must
        # not be re-derived now - the run may already have started, and a
        # baseline invented after work began authorizes whatever the file
        # says today.
        spec_baseline = goals / f"{slug}{SPEC_BASELINE_SUFFIX}"
        if not spec_baseline.is_file():
            raise ValueError(
                "This armed run has no recorded spec baseline, and one cannot be "
                "invented after work may have begun. A fresh start (remove "
                "active, the events log and both baselines by hand) is the way "
                "to re-arm."
            )
        check_protection(active_goal(root), goal_file.read_text())
        if definition is not None:
            objective_environment(active_goal(root))
        (goals / f"{slug}.verification.lock").touch(exist_ok=True)
        return f"{slug} is already armed; baselines unchanged."

    revision = _git(root, "rev-parse", "HEAD")
    if revision.returncode != 0 and not allow_no_git:
        raise ValueError(
            "Arming requires a usable Git HEAD by default; `git init` alone is not "
            "enough. Use the enclosing repository or create a reviewed baseline commit "
            "before arming. If this is not a project, Git is unavailable, or the owner "
            "declines baseline creation, rerun with --allow-no-git; step-history "
            "coverage and committed Writer-Session exclusion will be unavailable."
        )
    base = revision.stdout.strip() if revision.returncode == 0 else "none"

    spec_digest = legacy_frozen_digest(goal_file.read_text(encoding="utf-8"))
    pin_verification(root, slug, goal_file.read_text(encoding="utf-8"))
    if definition is not None:
        pin_objective_environment(root, slug)
    # Order matters: every sidecar exists before the marker does, so no Stop
    # can arrive over an armed marker whose baseline is missing. The
    # baselines are write-once: a re-arm after a disarm keeps the previous
    # spec baseline as the authorized one, and if the artifact was edited
    # in between the gate closes the new run loudly on its first Stop
    # (frozen_spec_changed) rather than silently re-authorizing it - a
    # deliberate new spec goes through the fresh start, which removes the
    # baselines by hand.
    spec_kept = not _write_once(
        goals / f"{slug}{SPEC_BASELINE_SUFFIX}", spec_digest + "\n"
    )
    if definition is not None:
        _write_once(prior_objective, frozen_digest(goal_file.read_text(encoding="utf-8")) + "\n")
    git_baseline = goals / f"{slug}{GIT_BASELINE_SUFFIX}"
    _write_once(git_baseline, base + "\n")
    recorded_base = git_baseline.read_text(encoding="utf-8").strip()
    (goals / f"{slug}.verification.lock").touch(exist_ok=True)

    ignore = goals / ".gitignore"
    existing = ignore.read_text(encoding="utf-8") if ignore.is_file() else ""
    additions = [e for e in IGNORE_ENTRIES if e not in existing.splitlines()]
    if additions:
        ignore.write_text(
            existing.rstrip("\n") + ("\n" if existing else "")
            + "\n".join(additions) + "\n",
            encoding="utf-8",
        )

    # Exclusive creation prevents a concurrent arm from overwriting an
    # already active goal. A hook seeing a partial marker stays inert.
    if not append_event(audit_goal, {"event": "session_binding_requested",
                                    "ts": datetime.now(timezone.utc).isoformat(), "sessions": [session]}):
        raise ValueError("Cannot record the executing session before activation.")
    with marker.open("x", encoding="utf-8") as handle:
        handle.write(f"{slug}\nsession {session}\n")
    kept_note = (
        " (a previous run's spec baseline is still the authorized one - fresh "
        "start to re-arm a changed spec)"
        if spec_kept else ""
    )
    retained = len(completion_attempts(read_events(active_goal(root))))
    git_note = (
        " No-Git mode was explicitly selected: step-history coverage and committed "
        "Writer-Session exclusion are unavailable."
        if recorded_base == "none"
        else ""
    )
    return (
        f"{slug} armed for session {session}. Spec baseline {spec_digest}; review baseline {recorded_base}.{kept_note} "
        "The gate is live: completion claims are judged against the frozen "
        f"sections as they stand now.{git_note} "
        f"{retained} earlier completion attempt(s) are retained; re-arming does "
        "not reset the ceiling. A fresh run needs a new authorized goal or "
        "the documented explicit reset."
    )


def rebind(root: Path, slug: str, session_id: str | None = None) -> str:
    """Explicit owner-authorized recovery into a different native session.

    This command transfers ownership, not authority or frozen conditions.
    The caller must already have permission to resume this run. Pending
    completion claims belong to the previous session and are discarded.
    """
    if _valid_slug(slug) != slug:
        raise ValueError("Expected a goal slug, not a path.")
    session = initiating_session(session_id)
    goals = root / ".goals"
    marker = goals / "active"
    if _armed_slug(marker) != slug:
        raise ValueError("The active marker does not name this goal.")
    spec_file = goals / f"{slug}.goal.md"
    if not frozen_baselines_match(active_goal(root), spec_file.read_text()):
        raise ValueError("Frozen conditions changed or the armed baseline is missing; start a newly authorized goal.")
    check_protection(active_goal(root), spec_file.read_text())
    if not append_event(active_goal(root), {"event": "session_binding_requested",
            "ts": datetime.now(timezone.utc).isoformat(),
            "sessions": [_read_marker(marker)[1], session]}):
        raise ValueError("Cannot preserve previous executing sessions before rebind.")
    candidate = goals / f"{slug}.candidate"
    candidate.unlink(missing_ok=True)
    from goal_drive import halt
    halt(active_goal(root), "paused", "Session rebound; old wait delivery is invalid")
    marker.write_text(f"{slug}\nsession {session}\n", encoding="utf-8")
    return f"{slug} rebound to session {session}; baselines preserved, previous completion claim discarded."


def disarm(root: Path, slug: str) -> str:
    marker = root / ".goals" / "active"
    if not marker.is_file() or _armed_slug(marker) != slug:
        raise ValueError(
            "The active marker does not name this goal; nothing was removed."
        )
    from goal_drive import halt
    halt(active_goal(root), "canceled", "Explicit disarm")
    try:
        marker.unlink()
    except OSError as exc:
        raise ValueError(f"The marker could not be removed: {exc}") from exc
    candidate = root / ".goals" / f"{slug}.candidate"
    try:
        candidate.unlink()
    except OSError:
        pass
    return (
        f"{slug} disarmed. The events log and baselines remain for audit; a "
        "fresh start removes them by hand."
    )


def review_diff(root: Path, slug: str) -> str:
    """The reviewer's range, with the ancestor guard the skills carry.

    A baseline that is not an ancestor of HEAD means history was rewritten
    under the run; the range is then unreliable and saying so is the honest
    output - the ported shape this file is based on lacked the guard.
    """
    marker = root / ".goals" / "active"
    if not marker.is_file() or _armed_slug(marker) != slug:
        raise ValueError("This goal is not armed.")
    base_file = root / ".goals" / f"{slug}{GIT_BASELINE_SUFFIX}"
    base = base_file.read_text(encoding="utf-8").strip() if base_file.is_file() else ""
    if not base or base == "none":
        return (
            "ultra-goal: no review range can be formed - this run recorded no "
            "git baseline. Report the review as unavailable rather than "
            "reviewing an unbounded tree."
        )
    guard = _git(root, "merge-base", "--is-ancestor", base, "HEAD")
    warning = (
        ""
        if guard.returncode == 0 else
        f"ultra-goal: baseline {base} is not an ancestor of HEAD - history "
        "moved under the run and the recorded range is unreliable. Report that "
        "instead of trusting this diff.\n"
    )
    diff = _git(root, "diff", "--no-ext-diff", base, "--")
    untracked = _git(
        root, "ls-files", "--others", "--exclude-standard"
    )
    return (
        f"{warning}Review baseline: {base}\n\n{diff.stdout}\n\n"
        "Untracked files (review only those inside the goal boundary):\n"
        f"{untracked.stdout}"
    )


def verify(root: Path, slug: str, session_id: str | None = None,
           claim: str = "Proposed completion of the accepted contract") -> dict:
    """Run the existing gate as a tool, so its result precedes final delivery.

    This is an explicit completion attempt, not a synthetic host Stop or a
    continuation driver. The same frozen terms, evidence and attempt ceiling apply.
    """
    from goal_stop import handle

    session = initiating_session(session_id)
    goal = active_goal(root)
    if goal is None or goal.slug != slug or goal.owner_session != session:
        raise ValueError("Verify requires the active goal's bound native session.")
    if not isinstance(claim, str) or not claim.strip():
        raise ValueError("A completion claim must be nonempty.")
    attempt_id = uuid.uuid4().hex
    message = handle({"session_id": session, "verification_id": attempt_id}, goal,
                     command=True, claim=claim)
    observations = [e for e in read_events(goal) if e.get("verification_id") == attempt_id]
    measured = [e for e in observations if completion_attempt(e)]
    observation = measured[-1] if measured else None
    passed = bool(observation and observation.get("verification_passed") is True)
    return {"verification_passed": passed, "fresh_check": observation is not None,
            "observation": observation, "message": message,
            "event_log": f".goals/{slug}.events.jsonl"}


def _objective_refused(goal: ActiveGoal, session: str | None, action: str, reason: str) -> dict:
    recorded = append_event(goal, {"ts": datetime.now(timezone.utc).isoformat(),
        "event": "objective_refused", "session_id": session, "action": action, "reason": reason})
    return {"refused": True, "reason": reason + ("" if recorded else " Event log is unwritable; refusal was not recorded.")}


def _objective_check(goal: ActiveGoal, spec: str, tree: str | None = None) -> str:
    current = goal.goal_path.read_text(encoding="utf-8")
    if frozen_digest(current) != frozen_digest(spec) or not frozen_baselines_match(goal, current):
        raise ValueError("Frozen Objective or goal terms differ from the armed spec baseline; stop and raise a challenge.")
    check_protection(goal, spec)
    return check_product(goal.goals_dir.parent, tree)


def _objective_counters(state: dict) -> dict:
    return {key: state[key] for key in ("candidates_used", "budget", "since_last_keep", "keeps_since_audit",
                                       "audit_failures", "audit_failure_limit", "audit_failures_remaining", "voided_keeps")}


def _objective_flags(state: dict) -> dict:
    return {key: state[key] for key in ("plateau", "audit_due", "target_reached", "budget_exhausted",
                                       "margin_below_noise", "strategy_unchanged_after_plateau")}


def _measure(goal: ActiveGoal, spec: str, definition: dict, state: dict, tree: str, session: str,
             strategy: str | None, hypothesis: str | None) -> dict:
    root = goal.goals_dir.parent
    incumbent = state["incumbent"]
    remeasure = bool(incumbent and tree == incumbent["product_tree"])
    if not remeasure and tree in state["judged_trees"]:
        raise ValueError("This product tree was already judged; restore the incumbent or start a newly authorized goal.")
    if not incumbent:
        revision = (goal.goals_dir / f"{goal.slug}.baseline").read_text().strip()
        if tree != product_tree(root, revision):
            raise ValueError(f"Establish the baseline by measuring arming revision {revision} first.")
    elif not remeasure:
        if not strategy or not strategy.strip() or not hypothesis or not hypothesis.strip():
            raise ValueError("Candidates require --strategy and --hypothesis before measurement.")
        strategy = strategy.strip()
        if state["plateau"] and strategy == state["last_strategy"]:
            raise ValueError(f"Objective plateau in strategy class {strategy!r}; change strategy class before measurement.")
    if not remeasure and state["budget_exhausted"]:
        raise ValueError("Objective budget exhausted; restore the incumbent and finalize.")
    if not remeasure and state["audit_due"]:
        raise ValueError("Objective audit due; restore the incumbent, obtain review and run audit.")
    revision = _git(root, "rev-parse", "HEAD").stdout.strip()
    margin = objective_margin(definition, incumbent["best_value"]) if incumbent else None
    def would_keep(value):
        return incumbent is None or (value < incumbent["best_value"] - margin if definition["direction"] == "lower"
                                     else value > incumbent["best_value"] + margin)
    evaluation = evaluate_commit(goal, spec, revision, floors=not remeasure,
                                 measure=definition["samples"],
                                 holdout=definition["samples"] if not incumbent and definition.get("holdout") else 0,
                                 screen=True, floor_if=would_keep)
    anchor = evaluation["anchor"]
    reading = evaluation.get("measure", {})
    samples, median = reading.get("samples", []), reading.get("value")
    holdout = evaluation.get("holdout", {})
    verdict, reason = "discard", None
    if evaluation.get("invalid"):
        verdict, reason = "invalid", evaluation["invalid"]
    elif evaluation.get("setup_failed"):
        verdict, reason = "unknown", "setup_failed"
    elif evaluation.get("screen", {}).get("outcome", "green") != "green":
        outcome = evaluation["screen"]["outcome"]
        verdict, reason = ("discard", "screen_red") if outcome == "red" else ("unknown", "screen_unknown")
    elif reading.get("outcome") != "measured":
        verdict = reading.get("outcome", "crash")
        reason = "measure_" + verdict
    elif not remeasure and anchor["outcome"] in ("red", "unknown"):
        verdict, reason = ("discard", "floor_red") if anchor["outcome"] == "red" else ("unknown", "floor_unknown")
    elif remeasure:
        verdict = "remeasured"
    elif incumbent is None:
        verdict = "baseline"
        if holdout and holdout["outcome"] != "measured":
            verdict, reason = holdout["outcome"], "baseline_holdout_failed"
    elif would_keep(median):
        verdict = "keep"
    else:
        reason = "within_margin"
    try:
        _objective_check(goal, spec, tree)
    except (ValueError, OSError, subprocess.SubprocessError) as exc:
        verdict, reason = "invalid", str(exc)
    unchanged = bool(incumbent and not remeasure and state["plateau"] and strategy == state["last_strategy"])
    entry = {"ts": datetime.now(timezone.utc).isoformat(), "event": "objective_measured",
             "index": 1 + sum(e.get("event") == "objective_measured" for e in read_events(goal)),
             "session_id": session, "commit": revision, "product_tree": tree,
             "strategy": strategy if incumbent and not remeasure else None,
             "hypothesis": hypothesis if incumbent and not remeasure else None,
             "strategy_unchanged_after_plateau": unchanged,
             "verdict": verdict, "reason": reason, "anchor": anchor, "samples": samples,
             "median": median, "incumbent_before": incumbent, "margin_abs": margin,
             "direction": definition["direction"], "holdout": holdout, "remeasure": remeasure,
             "spec_digest": frozen_digest(spec), "env_digest": evaluation["env_digest"]}
    if evaluation.get("setup_failed"):
        entry["setup_error"] = evaluation["setup_failed"]
    if "screen" in evaluation:
        entry["screen"] = evaluation["screen"]
    if evaluation.get("cleanup_error"):
        entry["cleanup_error"] = evaluation["cleanup_error"]
    after = objective_state([*read_events(goal), entry], definition)
    entry.update(incumbent_after=after["incumbent"], counters=_objective_counters(after), flags=_objective_flags(after))
    if not append_event(goal, entry):
        raise ValueError("Measurement was not recorded; fix the event log before continuing.")
    current = after["incumbent"]
    next_step = f"Continue from incumbent {current['commit']}." if current else "Restore the floor and establish a baseline."
    if after["audit_failures"]:
        next_step += (f" {after['voided_keeps']} keeps voided by failed audits; "
                      f"{after['audit_failures_remaining']} failed audits remaining before closure.")
    if after["plateau"]:
        next_step += " Plateau: change strategy class."
    if after["audit_due"]:
        next_step += " Audit due: obtain review and run audit."
    if after["budget_exhausted"]:
        next_step += " Budget exhausted: restore the incumbent and finalize."
    if after["target_reached"]:
        next_step += " Target reached: confirm with audit."
    return {**entry, "value": median, "incumbent": current, "baseline": after["baseline"],
            "restore_commit": current["commit"] if current else None, "next": next_step}


def _objective_isolation_references(definition: dict, state: dict,
                                    incumbent_holdout: float | None = None) -> dict:
    """Ledger values a clean baseline checkout must read closer to than the incumbent's.

    The incumbent's reference is the median of all its samples, not its best median:
    the best reading is the optimistic tail and makes a leaked baseline look isolated.
    A phase is checked only when the ledger separates the two by more than the margin, in
    either direction: a holdout that loads shared code can read worse as well as better.
    """
    def separated(base, other):
        if base is None or other is None:
            return False
        return abs(other - base) > objective_margin(definition, base)

    references = {}
    if separated(state["baseline"]["value"], state["incumbent"]["value"]):
        references["measure"] = {"baseline": state["baseline"]["value"],
                                 "incumbent": state["incumbent"]["value"]}
    if separated(state["baseline"].get("holdout"), incumbent_holdout):
        references["holdout"] = {"baseline": state["baseline"]["holdout"], "incumbent": incumbent_holdout}
    return references


def _objective_not_isolated(references: dict, medians: dict) -> bool:
    """A baseline checkout reading at least as close to the incumbent as to the baseline."""
    return any(medians.get(phase) is not None
               and abs(medians[phase] - reference["baseline"]) >= abs(medians[phase] - reference["incumbent"])
               for phase, reference in references.items())


OBJECTIVE_ISOLATION_EXPLANATION = (
    "The baseline checkout now reads like the incumbent, so the readings no longer separate the two "
    "versions. Either the evaluator loads product code from outside its checkout, such as an editable "
    "install or an activated environment, or the measuring environment changed since the baseline, "
    "such as the machine or its load. Stop and raise a challenge with these readings; retry once the "
    "evaluator loads the product from its own checkout and the environment matches the baseline's."
)


def _audit(goal: ActiveGoal, spec: str, definition: dict, state: dict, tree: str, session: str) -> dict:
    incumbent = state["incumbent"]
    if not incumbent:
        raise ValueError("No Objective incumbent; run measure to establish the baseline first.")
    if tree != incumbent["product_tree"]:
        raise ValueError(f"Restore incumbent commit {incumbent['commit']} before audit.")
    evidence = check_review(goal, spec, retain=True, allow_failure=True)
    if evidence["verdict"] != "pass":
        entry = {"ts": datetime.now(timezone.utc).isoformat(), "event": "objective_audit_failed",
                 "session_id": session, "incumbent": incumbent, "verdict": evidence["verdict"],
                 "reason": "review_" + evidence["verdict"], "evidence": evidence["evidence"],
                 "review_evidence": evidence, "env_digest": objective_environment(goal)[1],
                 "spec_digest": frozen_digest(spec)}
        if not append_event(goal, entry):
            raise ValueError("Failed audit was not recorded; fix the event log before continuing.")
        after = objective_state(read_events(goal), definition)
        rolled = after["incumbent"]
        next_step = f"Restore incumbent {rolled['commit']}; "
        if after["closed"]:
            next_step += "search closed; stop, raise a challenge and finalize."
        else:
            next_step += (f"{after['voided_keeps']} keeps voided by failed audits; "
                          f"{after['audit_failures_remaining']} failed audits remaining before closure. "
                          "Continue with a different approach addressing the review finding.")
        return {"audited": False, "audit_failed": True, "drift_alarm": False, "reason": entry["reason"],
                "closed": after["closed"], "restore_commit": rolled["commit"],
                "counters": _objective_counters(after), "next": next_step}
    references = _objective_isolation_references(definition, state)
    if references:
        evaluation = evaluate_commit(goal, spec, state["baseline"]["commit"], measure=definition["samples"])
        if evaluation.get("invalid"):
            raise ValueError(evaluation["invalid"])
        if evaluation.get("setup_failed"):
            raise ValueError(f"Baseline isolation setup_failed: {evaluation['setup_failed']}")
        reading = evaluation["measure"]
        if reading["outcome"] != "measured":
            raise ValueError(f"Baseline isolation measure failed ({reading['outcome']}).")
        _objective_check(goal, spec, tree)
        if _objective_not_isolated(references, {"measure": reading["value"]}):
            entry = {"ts": datetime.now(timezone.utc).isoformat(), "event": "objective_isolation_failed",
                     "session_id": session, "incumbent": incumbent, "reason": "not_isolated",
                     "baseline_evaluation": evaluation, "isolation_references": references,
                     "review_evidence": evidence, "env_digest": evaluation["env_digest"],
                     "spec_digest": frozen_digest(spec)}
            if not append_event(goal, entry):
                raise ValueError("Isolation failure was not recorded; fix the event log before continuing.")
            raise ValueError("objective_isolation_failed (not_isolated): " + OBJECTIVE_ISOLATION_EXPLANATION)
    holdout = {}
    if definition.get("holdout"):
        evaluation = evaluate_commit(goal, spec, incumbent["commit"], holdout=definition["samples"])
        if evaluation.get("invalid"):
            raise ValueError(evaluation["invalid"])
        if evaluation.get("setup_failed"):
            raise ValueError(f"Holdout setup_failed: {evaluation['setup_failed']}")
        holdout = evaluation["holdout"]
        if holdout["outcome"] != "measured":
            raise ValueError(f"Holdout failed ({holdout['outcome']}).")
        held = _objective_isolation_references(definition, state, holdout["value"]).get("holdout")
        if held:
            check = evaluate_commit(goal, spec, state["baseline"]["commit"], holdout=definition["samples"])
            if check.get("invalid") or check.get("setup_failed"):
                raise ValueError(f"Baseline holdout isolation failed to run: {check.get('invalid') or check.get('setup_failed')}")
            if check["holdout"]["outcome"] != "measured":
                raise ValueError(f"Baseline holdout isolation measure failed ({check['holdout']['outcome']}).")
            if _objective_not_isolated({"holdout": held}, {"holdout": check["holdout"]["value"]}):
                entry = {"ts": datetime.now(timezone.utc).isoformat(), "event": "objective_isolation_failed",
                         "session_id": session, "incumbent": incumbent, "reason": "not_isolated", "phase": "holdout",
                         "baseline_evaluation": check, "isolation_references": {"holdout": held},
                         "review_evidence": evidence, "env_digest": check["env_digest"],
                         "spec_digest": frozen_digest(spec)}
                if not append_event(goal, entry):
                    raise ValueError("Isolation failure was not recorded; fix the event log before continuing.")
                raise ValueError("objective_isolation_failed (not_isolated) in the holdout: " + OBJECTIVE_ISOLATION_EXPLANATION)
    _objective_check(goal, spec, tree)
    evidence = check_review(goal, spec, retain=True)
    baseline = state["baseline"]["holdout"]
    baseline_value = state["baseline"]["value"]
    delta = incumbent["value"] - baseline_value if definition["direction"] == "higher" else baseline_value - incumbent["value"]
    objective_gain = delta / abs(baseline_value) if baseline_value else None
    relative_margin = objective_margin(definition, baseline_value) / abs(baseline_value) if baseline_value else None
    comparison = {"objective_gain": objective_gain, "holdout_gain": None, "gain_ratio": None,
                  "rule": "none", "reason": None, "objective_margin_relative": relative_margin,
                  "holdout_margin_relative": None, "transfer": definition.get("transfer")}
    if holdout:
        if baseline is None:
            raise ValueError("Holdout audit requires the baseline holdout reading.")
        margin = objective_margin(definition, baseline)
        delta = holdout["value"] - baseline if definition["direction"] == "higher" else baseline - holdout["value"]
        # A zero baseline leaves relative gains undefined: regression still applies, transfer cannot.
        holdout_gain = delta / abs(baseline) if baseline else None
        comparison.update(holdout_gain=holdout_gain,
                          gain_ratio=holdout_gain / objective_gain if holdout_gain is not None and objective_gain else None,
                          holdout_margin_relative=margin / abs(baseline) if baseline else None, margin_abs=margin,
                          rule="regression")
        worse = (holdout["value"] > baseline + margin if definition["direction"] == "lower"
                 else holdout["value"] < baseline - margin)
        if worse:
            comparison["reason"] = "regression"
        elif None not in (objective_gain, relative_margin, holdout_gain) and objective_gain > relative_margin:
            comparison["rule"] = "transfer"
            if holdout_gain < definition["transfer"] * objective_gain:
                comparison["reason"] = "transfer"
    entry = {"ts": datetime.now(timezone.utc).isoformat(), "event": "objective_audited",
             "session_id": session, "incumbent": incumbent, "holdout": holdout,
             "baseline_holdout": baseline, "review_evidence": evidence,
             "spec_digest": frozen_digest(spec), "env_digest": objective_environment(goal)[1], **comparison}
    if comparison["reason"]:
        entry["event"] = "objective_drift_alarm"
    if not append_event(goal, entry):
        raise ValueError("Audit was not recorded; fix the event log before continuing.")
    alarm = entry["event"] == "objective_drift_alarm"
    after = objective_state(read_events(goal), definition)
    rolled = after["incumbent"]
    return {"audited": not alarm, "audit_failed": False, "drift_alarm": alarm,
            "reason": comparison["reason"], "closed": after["closed"],
            "restore_commit": rolled["commit"], "counters": _objective_counters(after),
            "next": f"Restore incumbent {rolled['commit']}; stop and raise a challenge, then finalize."
                    if alarm else "Incumbent audited; run replay, then verify to finalize."}


def _replay(goal: ActiveGoal, spec: str, definition: dict, state: dict, session: str | None) -> dict:
    if not state["baseline"] or not state["incumbent"]:
        raise ValueError("Replay requires measured baseline and incumbent commits.")
    if state["incumbent"]["product_tree"] == state["baseline"]["product_tree"]:
        # Comparing the baseline with itself would read as a falsified gain.
        raise ValueError("The incumbent is the baseline: there is no gain to replay, and none is needed to finalize.")
    readings = {name: {"measure": [], "holdout": []} for name in ("baseline", "incumbent")}
    pairs = []
    env_digest = objective_environment(goal)[1]
    def at_incumbent():
        try:
            check_product(goal.goals_dir.parent, state["incumbent"]["product_tree"])
            return True
        except (ValueError, OSError, subprocess.SubprocessError):
            return False
    binding = at_incumbent()
    for _ in range(definition["samples"]):
        pair = {}
        for name in ("baseline", "incumbent"):
            evaluation = evaluate_commit(goal, spec, state[name]["commit"],
                                         measure=1, holdout=1 if definition.get("holdout") else 0)
            if evaluation["env_digest"] != env_digest:
                raise ValueError("Pinned Objective environment changed during replay.")
            pair[name] = evaluation
            for phase in ("measure", "holdout"):
                readings[name][phase].extend(evaluation.get(phase, {}).get("samples", []))
        pairs.append(pair)
    medians = {name: {} for name in readings}
    valid = all(not observation.get("invalid") and not observation.get("setup_failed")
                for pair in pairs for observation in pair.values())
    for name in readings:
        for phase in ("measure", "holdout") if definition.get("holdout") else ("measure",):
            samples = readings[name][phase]
            measured = len(samples) == definition["samples"] and all(s["outcome"] == "measured" for s in samples)
            valid &= measured
            medians[name][phase] = statistics.median(s["value"] for s in samples) if measured else None
    baseline, incumbent = (medians[name]["measure"] for name in ("baseline", "incumbent"))
    gain = None
    reproduces = False
    last = state.get("last_audit") or {}
    audited_holdout = ((last.get("holdout") or {}).get("value")
                       if (last.get("incumbent") or {}).get("product_tree") == state["incumbent"]["product_tree"]
                       else None)
    references = _objective_isolation_references(definition, state, audited_holdout)
    not_isolated = valid and bool(references) and _objective_not_isolated(
        references, {"measure": baseline, "holdout": medians["baseline"].get("holdout")})
    if not_isolated:
        valid = False
    if valid:
        delta = incumbent - baseline if definition["direction"] == "higher" else baseline - incumbent
        gain = delta / abs(baseline) if baseline else None
        reproduces = delta > objective_margin(definition, baseline)
    entry = {"ts": datetime.now(timezone.utc).isoformat(), "event": "objective_replayed",
             "session_id": session, "baseline": state["baseline"], "incumbent": state["incumbent"],
             "pairs": pairs, "readings": readings, "medians": medians, "relative_gain": gain,
             "reproduces": reproduces, "valid": valid, "binding": binding and at_incumbent(), "env_digest": env_digest,
             "spec_digest": frozen_digest(spec)}
    if not_isolated:
        entry.update(reason="not_isolated", isolation_references=references, next=OBJECTIVE_ISOLATION_EXPLANATION)
    if not append_event(goal, entry):
        raise ValueError("Replay was not recorded; fix the event log before continuing.")
    return entry


def _objective_run(root: Path, slug: str, session_id: str | None, action: str,
                   strategy: str | None = None, hypothesis: str | None = None) -> dict:
    goal = active_goal(root)
    if action == "replay" and (goal is None or goal.slug != slug) and _valid_slug(slug) == slug:
        goals = root / ".goals"
        goal = ActiveGoal(slug, goals, goals / f"{slug}.goal.md", goals / f"{slug}.events.jsonl",
                          goals / f"{slug}.decisions.md", goals / "active",
                          spec_baseline_path=goals / f"{slug}{SPEC_BASELINE_SUFFIX}")
    if goal is None or goal.slug != slug:
        return {"refused": True, "reason": f"{action} requires the active goal's bound native session."}
    try:
        session = session_id if action == "replay" else initiating_session(session_id)
        if action != "replay" and goal.owner_session != session:
            raise ValueError(f"{action} requires the active goal's bound native session.")
        with verification_lock(goal):
            spec = goal.goal_path.read_text(encoding="utf-8")
            if not frozen_baselines_match(goal, spec):
                raise ValueError("Frozen Objective or goal terms differ from the armed spec baseline; stop and raise a challenge.")
            definition = objective(spec)
            if definition is None:
                raise ValueError("This goal has no Objective.")
            state = objective_state(read_events(goal), definition)
            try:
                if action == "replay":
                    check_protection(goal, spec)
                    return _replay(goal, spec, definition, state, session)
                if action == "measure" and state["closed"]:
                    raise ValueError(f"Objective search closed ({state['closure_reason']}); restore incumbent {state['incumbent']['commit']} and finalize.")
                tree = _objective_check(goal, spec)
            except (ValueError, OSError, subprocess.SubprocessError) as exc:
                if action == "audit" and state["incumbent"]:
                    raise ValueError(f"Audit refused; restore incumbent commit {state['incumbent']['commit']}: {exc}") from exc
                raise
            if action == "measure":
                return _measure(goal, spec, definition, state, tree, session, strategy, hypothesis)
            if state["closed"]:
                raise ValueError(f"Objective search closed ({state['closure_reason']}); restore the rolled-back incumbent and finalize.")
            return _audit(goal, spec, definition, state, tree, session)
    except (ValueError, OSError, subprocess.SubprocessError) as exc:
        return _objective_refused(goal, session_id, action, str(exc))


def measure(root: Path, slug: str, session_id: str | None = None, *,
            strategy: str | None = None, hypothesis: str | None = None) -> dict:
    return _objective_run(root, slug, session_id, "measure", strategy, hypothesis)


def audit(root: Path, slug: str, session_id: str | None = None) -> dict:
    return _objective_run(root, slug, session_id, "audit")


def replay(root: Path, slug: str, session_id: str | None = None) -> dict:
    return _objective_run(root, slug, session_id, "replay")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=__doc__.splitlines()[0],
    )
    parser.add_argument(
        "action",
        choices=("arm", "diff", "disarm", "rebind", "review-inputs", "spec-digest", "verify", "measure", "audit", "replay"),
    )
    parser.add_argument("slug")
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--session-id", help="Current native session ID, never another task's ID")
    parser.add_argument("--strategy", help="Pre-registered candidate strategy class")
    parser.add_argument("--hypothesis", help="Predicted effect of the candidate")
    parser.add_argument("--claim", default="Proposed completion of the accepted contract")
    parser.add_argument("--driver", choices=("codex", "claude", "grok"),
                        help="Enable autonomous continuation without native Goal mode")
    parser.add_argument(
        "--allow-no-git",
        action="store_true",
        help="Arm without a usable HEAD after accepting reduced audit coverage",
    )
    args = parser.parse_args(argv)
    try:
        if args.action in ("measure", "audit", "replay"):
            result = _objective_run(args.root, args.slug, args.session_id, args.action, args.strategy, args.hypothesis)
            print(json.dumps(result, ensure_ascii=False))
            return 1 if result.get("refused") or result.get("verdict") == "invalid" or result.get("drift_alarm") or result.get("audit_failed") or result.get("valid") is False else 0
        elif args.action == "verify":
            result = verify(args.root, args.slug, args.session_id, args.claim)
            print(json.dumps(result, ensure_ascii=False))
            return 0 if result["verification_passed"] else 1
        elif args.action == "review-inputs":
            if _valid_slug(args.slug) != args.slug:
                raise ValueError("Expected a goal slug, not a path.")
            print(input_digest(args.root, (args.root / ".goals" / f"{args.slug}.goal.md").read_text()))
        elif args.action == "spec-digest":
            if _valid_slug(args.slug) != args.slug:
                raise ValueError("Expected a goal slug, not a path.")
            goal = args.root / ".goals" / f"{args.slug}.goal.md"
            print(frozen_digest(goal.read_text(encoding="utf-8")))
        elif args.action == "arm":
            if args.driver and os.name != "posix":
                raise ValueError("Autonomous execution currently requires a POSIX host.")
            print(arm(args.root, args.slug, args.session_id, args.allow_no_git))
            if args.driver:
                from goal_drive import start
                print(json.dumps(start(active_goal(args.root), args.driver)))
        elif args.action == "rebind":
            print(rebind(args.root, args.slug, args.session_id))
        elif args.action == "diff":
            print(review_diff(args.root, args.slug))
        else:
            print(disarm(args.root, args.slug))
        return 0
    except (ValueError, OSError) as exc:
        print(f"ultra-goal: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    # Arming refuses loudly rather than fail-open: this is an owner act, not
    # a host hook, so exit 1 with a message is the contract.
    raise SystemExit(main())
