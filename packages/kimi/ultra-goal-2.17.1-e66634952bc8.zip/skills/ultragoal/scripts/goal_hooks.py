#!/usr/bin/env python3
"""Shared activation and fail-open plumbing for the goal hooks.

Every hook's first act is to decide whether a goal is active in this project.
Where none is, that decision is the entire run: nothing is read beyond one
marker file, nothing is written, no command is executed, and the exit code is 0.

That early exit is the only thing standing between an installed hook and a
project that never asked for one, so it is deliberately dumb: one file, one
line, no parsing that can fail in an interesting way. Every failure path in
this module ends in "not active" rather than in an exception.

The same applies to the handlers this module runs. A hook that raises must not
be able to stop the host from working - the historical failure here is a Stop
hook that blocked forever because its own check was broken.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from typing import Any, Callable


GOALS_DIR = ".goals"
# The sections a run may never edit. Their digest is recorded once, by the
# arming command, into `<slug>.spec.baseline` and compared by the gate on
# every later Stop against that file - never against a digest found in the
# event log, because the run can write the log.
FROZEN_SECTIONS = ("intent", "boundary", "anchor", "stop condition", "verification")
ACTIVE_MARKER = "active"
SPEC_BASELINE_SUFFIX = ".spec.baseline"
DISABLE_ENV = "ULTRA_GOAL_HOOKS_DISABLED"
# A slug names one artifact in `.goals/`. It is never a path.
SLUG_MAX = 100
# The marker's required second line names the session that owns the run. A
# session id is ownership information, not an anti-forgery key: any process
# that can write files can write the marker. What the line buys is that a
# *different* session's ordinary hooks - a Stop that would gate, a prompt
# that would reset the streak, an injection that would hand over the spec -
# leave the run alone.
SESSION_MAX = 200
# The Stop registration in hooks/hooks.json declares this timeout, and the host
# kills the hook process when it expires. Every budget inside the gate has to
# fit under it, so the number lives here once and a test pins it against the
# manifest - two copies with no stated relationship is how a gate acquires a
# ceiling nobody chose.
#
# 600 is the hooks reference's documented default for a `command` hook, and it
# is used here for exactly that reason. The previous 200 was a number I picked,
# which capped every anchor in this design at under three minutes - so an anchor
# that legitimately takes five was permanently `unknown`, held there by a limit
# its owner never chose. That is the failure `## Stop condition` forbids, and it
# had migrated into the clock. A long anchor still costs only what the artifact
# declares: `budget:` is the owner's number, and this is only its ceiling.
HOOK_TIMEOUT_SECONDS = 600
# Headroom for reading the artifact, the log, and writing the event.
ANCHOR_BUDGET_CEILING = 570
DEFAULT_ANCHOR_BUDGET = 180


@dataclass(frozen=True)
class ActiveGoal:
    """The goal this project is currently running."""

    slug: str
    goals_dir: Path
    goal_path: Path
    events_path: Path
    decisions_path: Path
    marker_path: Path
    owner_session: str | None = None
    spec_baseline_path: Path | None = None


@dataclass(frozen=True)
class HostFacts:
    """What a host will actually do with a blocked Stop.

    `continuation_budget` is the gate's OWN bound: how many completion
    attempts in a row it will deny within one host turn it can observe,
    before it releases the stop with its own reason. It is not "the host's
    cap minus one", and it claims nothing about how any host counts: the
    one host cap that was read precisely (Claude Code 2.1.260) counts
    consecutive blocks since the last tool *progress*, not blocks per turn,
    so it is recorded here as the backstop that sizes the number, never as
    the number's definition. `None` means no informed bound exists, so the
    owner's ceiling is the only one. Every number cites where it came from:
    a budget without a source is a constant copied from Claude Code.

    `chain_flag` names the Stop-input field through which the host itself
    reports whether this Stop is a continuation of a blocked one - an explicit
    false is a directly observed fresh chain, so the budget's count starts
    from zero rather than inheriting the log's tail. It is set only where the
    host's reference documents the field *and* its meaning; a field name
    without documented semantics is an inference, and this project does not
    mechanise on inference.
    """

    continuation_budget: int | None
    source: str
    chain_flag: str | None = None


HOSTS: dict[str, HostFacts] = {
    "pi": HostFacts(1, "Pi extension allows one corrective follow-up per user prompt; ordinary stops do not continue"),
    # Claude Code force-ends a turn after 8 consecutive Stop blocks with no
    # tool progress in between (the counter is `stopHookBlockingCount`,
    # reset by progress, raisable via CLAUDE_CODE_STOP_HOOK_BLOCK_CAP; read
    # from the running 2.1.260 binary). The cap counts progress-free runs of
    # blocks, NOT blocks per turn - an earlier version read it as per-turn
    # and defined this budget as "cap minus one". The number stays 7, now as
    # the gate's own bound on consecutive denied attempts, sized so the
    # gate's reason is the last word before the host's force-end backstop.
    "claude": HostFacts(
        7,
        "sized under the host's force-end of 8 consecutive no-progress blocks "
        "(CLAUDE_CODE_STOP_HOOK_BLOCK_CAP default, Claude Code 2.1.260 binary)",
        # The hooks reference documents the field, and the binary's cap
        # message states its meaning: true while this stop continues a
        # previously blocked one.
        chain_flag="stop_hook_active",
    ),
    # zCode's hooks reference: "After 3 consecutive continuations the run is
    # force-ended to prevent infinite loops" (zcode.z.ai/en/docs/hooks).
    "zcode": HostFacts(
        2,
        "sized under the host's force-end of 3 consecutive continuations "
        "(zCode hooks reference)",
        # Declared degradation, and both halves are the reference's fault: it
        # lists stop_hook_active among Stop's input fields but spells no
        # semantics for it, and its exactly-seven event list includes no turn
        # boundary at all - so this host offers neither a readable chain flag
        # nor a turn identity, and the streak resets only on facts this gate
        # itself observed (an allow, or a chain-ender). What the run loses,
        # named: a blocked chain that ends without one of those - an owner
        # interrupt, an error, a session end - carries its tail into the next
        # turn, which can park one block early (budget 2, so one block of it
        # already spent). The release is loud and names its reason; what is
        # never claimed is a turn-scoped budget this host cannot observe.
        chain_flag=None,
    ),
    # Kimi triggers a blocking Stop only while `!stopHookContinuationUsed`
    # (0.40.1 binary: the flag is a local of runStepLoop, one call per host
    # turn, so one continuation per turn is the mechanical max) - its
    # reference documents no cap at all. The turn boundary is the host's own
    # TurnStarted event (registered: goal_turn_started.py), which fires for
    # every new turn whatever its origin - user, task or system_trigger -
    # and carries turn_id; the reference's UserPromptSubmit means only that a
    # user sent a message. The binary passes a stopHookActive input too, but
    # constant-false by construction (it is only read inside the !used
    # guard), so it carries no information.
    "kimi": HostFacts(
        1,
        "host triggers a blocking Stop at most once per turn (Kimi 0.40.1 binary)",
        chain_flag=None,
    ),
    # No cap in Codex's hooks reference and none visible in the 0.150.1
    # binary; the documented self-guard is the stop_hook_active input. UNVERIFIED
    # that unbounded blocking is allowed - if a hidden cap exists, the host's
    # force-end is the backstop.
    "codex": HostFacts(
        None,
        "no cap documented (Codex hooks reference) or visible in the 0.150.1 binary",
        # learn.chatgpt.com/docs/hooks: "Whether this turn was already
        # continued by Stop" - documented field and meaning.
        chain_flag="stop_hook_active",
    ),
}
# A host the table has never heard of gets the smallest documented budget
# rather than Claude's eight: an unknown cap can only be undershot safely.
UNKNOWN_HOST = HostFacts(
    1, "unknown host: the smallest budget any measured host allows"
)
# The shared hooks/hooks.json speaks Claude Code's format and is what an
# untagged invocation runs under; every other entry point tags itself.
DEFAULT_HOST = "claude"


def host_facts(host: str | None) -> HostFacts:
    return HOSTS.get(host or DEFAULT_HOST, UNKNOWN_HOST)


def _valid_slug(raw: str) -> str | None:
    slug = raw.strip()
    if not slug or len(slug) > SLUG_MAX:
        return None
    # The marker holds a slug, not a path. Traversal is not a goal.
    if slug != Path(slug).name or slug in {".", ".."}:
        return None
    if any(ch in slug for ch in ("/", "\\", "\0")):
        return None
    return slug


def _valid_session(raw: str) -> str | None:
    """A session token: one lineless, pathless, printable word.

    UUIDs and the native prefixed IDs are accepted. An invalid identity makes
    arming refuse and hook events inert; it can never claim an unbound goal.
    """
    token = raw.strip()
    if not token or len(token) > SESSION_MAX:
        return None
    if token != Path(token).name or token in {".", ".."}:
        return None
    if any(ch in token for ch in ("/", "\\", "\0", " ", "\t")):
        return None
    if not token.isprintable():
        return None
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]*", token):
        return None
    return token


def _read_marker(marker: Path) -> tuple[str | None, str | None]:
    """Read the marker's slug and session line, including legacy unbound markers.

    Still deliberately dumb: fixed first line, one keyed line, and
    anything unparsable reads as absent rather than fatal.
    """
    try:
        lines = [
            line.strip()
            for line in marker.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
    except (OSError, UnicodeError):
        return None, None
    if not lines:
        return None, None
    session: str | None = None
    for line in lines[1:]:
        key, sep, value = line.partition(" ")
        if sep and key.lower() == "session":
            token = _valid_session(value)
            if token is not None:
                session = token
    return lines[0], session


def active_goal(cwd: Any) -> ActiveGoal | None:
    """Return the active goal for `cwd`, or None. Never raises."""
    try:
        if not isinstance(cwd, (str, Path)) or not str(cwd):
            return None
        goals = Path(cwd) / GOALS_DIR
        marker = goals / ACTIVE_MARKER
        if not marker.is_file():
            return None
        raw_slug, session = _read_marker(marker)
        slug = _valid_slug(raw_slug or "")
        if slug is None:
            return None
        goal = goals / f"{slug}.goal.md"
        if not goal.is_file():
            return None
        return ActiveGoal(
            slug=slug,
            goals_dir=goals,
            goal_path=goal,
            events_path=goals / f"{slug}.events.jsonl",
            decisions_path=goals / f"{slug}.decisions.md",
            marker_path=marker,
            owner_session=session,
            spec_baseline_path=goals / f"{slug}{SPEC_BASELINE_SUFFIX}",
        )
    except (OSError, UnicodeError, ValueError):
        return None


def read_spec_baseline(goal: ActiveGoal) -> str | None:
    """The frozen-spec digest the arming command recorded, or None.

    This file is the run's only authorized baseline. The gate compares every
    Stop against it and never against a digest found in the event log: the
    log is writable by the run, and round 4's laundering probe replaced it
    with a run-authored row carrying an edited digest and was allowed
    through. `None` means the run was never armed through the fence - the
    gate refuses completion claims rather than judging them unverified.
    """
    if goal.spec_baseline_path is None:
        return None
    try:
        text = goal.spec_baseline_path.read_text(encoding="utf-8").strip()
    except (OSError, UnicodeError):
        return None
    return text if re.fullmatch(r"[0-9a-f]{12}", text) else None


def goal_commits(artifact: Path) -> list[dict]:
    """Read declared work since arming; Git records provenance, not authorship proof.

    No Git baseline means this optional source is unavailable. Never substitute
    another branch or all repository history for a recorded range.
    """
    slug = artifact.name.removesuffix(".goal.md")
    baseline_path = artifact.with_name(f"{slug}.baseline")
    if not baseline_path.is_file():
        return []
    baseline = baseline_path.read_text(encoding="utf-8").strip()
    if baseline == "none":
        return []
    if not re.fullmatch(r"(?:[0-9a-f]{40}|[0-9a-f]{64})", baseline):
        raise ValueError("Work history has no valid arming-time Git revision.")

    def git(*args: str) -> str:
        try:
            result = subprocess.run(["git", *args], cwd=artifact.parent,
                                    capture_output=True, text=True, timeout=30)
        except (OSError, subprocess.SubprocessError) as exc:
            raise ValueError("Work history is unavailable; inspect the recorded Git range.") from exc
        if result.returncode:
            raise ValueError("Work history is unavailable or its baseline is not an ancestor of HEAD.")
        return result.stdout

    git("merge-base", "--is-ancestor", baseline, "HEAD")
    parts = git("log", "--reverse", "--no-show-signature",
                "--format=%H%x00%s%x00%b%x00", f"{baseline}..HEAD", "--").split("\0")
    prefix = rf"^goal\({re.escape(slug)}\)"
    records = []
    for index in range(0, len(parts) - 2, 3):
        commit, subject, body = parts[index:index + 3]
        if not re.match(prefix + r"(?:\s*:|\s+(?:step|turn\s+\d+)\s*:)", subject):
            continue
        fields: dict[str, list[str]] = {}
        for key, value in re.findall(r"^(Reason|Check|Remaining|Evidence|Writer-Session):[ \t]*(.*)$", body, re.M):
            if value.strip():
                fields.setdefault(key.lower(), []).append(value.strip())
        records.append({"commit": commit.strip(), "subject": subject,
                        "step": bool(re.match(prefix + r"\s+step\s*:", subject)),
                        "fields": fields})
    return records


def event_session(event: dict[str, Any]) -> str | None:
    """The session identity the host put in the payload, where it does.

    All four measured host envelopes include `session_id`. An earlier
    reading of Kimi's event-specific input missed the common envelope.
    Missing identity never grants ownership, including on legacy markers.
    """
    value = event.get("session_id")
    if isinstance(value, str):
        return _valid_session(value)
    return None


def owns_goal(goal: ActiveGoal, event: dict[str, Any]) -> bool:
    """Is this event the owning session's?

    Ownership is bound by the initiating session during arming. A foreign
    or identity-less event cannot consume a candidate or change recovery
    state. Legacy unbound markers are inert until explicitly re-armed.
    """
    session = event_session(event)
    return session is not None and session == goal.owner_session


def emit(payload: dict[str, Any]) -> None:
    """Write one JSON object to stdout. Silent on failure."""
    try:
        sys.stdout.write(json.dumps(payload, ensure_ascii=False))
    except (TypeError, ValueError, OSError):
        pass


def run_hook(
    event_name: str,
    handler: Callable[[dict[str, Any], ActiveGoal, str | None], dict[str, Any] | None],
    stdin_text: str | None = None,
    env: dict[str, str] | None = None,
    host: str | None = None,
) -> int:
    """Run `handler` only when this really is `event_name` on an active goal.

    Returns an exit code. It is always 0: a hook that cannot decide must let
    the host continue. Blocking, where a hook is entitled to it, travels through the
    emitted JSON rather than through the exit code, so a crash can never be
    mistaken for a deliberate block.

    There is deliberately no `stop_hook_active` early exit here. That flag
    marks a continuation - a turn this gate itself kept alive - and the guard
    it used to implement made the gate block exactly once per host turn, which
    is the difference between a loop and a nudge. The guard against a gate
    that denies forever is the per-host continuation budget in `HOSTS`,
    counted from this gate's own events. The flag is still read, but only as
    a boundary fact and only for the hosts whose references document both the
    field and its meaning (Claude Code and Codex spell `stop_hook_active`;
    Kimi's binary passes a constant camelCase `stopHookActive` that carries
    no information) - an explicit false tells the gate a fresh chain began,
    it never suppresses the check itself.
    """
    try:
        environ = os.environ if env is None else env
        if environ.get(DISABLE_ENV) == "1":
            return 0

        raw = sys.stdin.read() if stdin_text is None else stdin_text
        try:
            event = json.loads(raw)
        except (json.JSONDecodeError, UnicodeError, TypeError):
            return 0
        if not isinstance(event, dict):
            return 0
        if event.get("hook_event_name") != event_name:
            return 0

        goal = active_goal(event.get("cwd"))
        if goal is None:
            return 0
        if goal.owner_session is None:
            if event_name == "Stop":
                emit({"systemMessage": (
                    f"[ultra-goal] {goal.slug}: .goals/active has a legacy or invalid session binding. "
                    "Hooks are inactive; no verification was performed. "
                    "Use goal_run.py rebind for an authorized recovery, or disarm before arming an agreed goal."
                )})
            return 0
        if not owns_goal(goal, event):
            # Another session's event over this cwd's goal: not its run to
            # gate, inject into, or reset. Silent and side-effect free.
            return 0

        payload = handler(event, goal, host)
        if payload:
            emit(payload)
        return 0
    except BaseException:  # noqa: BLE001 - a hook must never take the host down
        return 0


def completion_attempt(entry: dict[str, Any]) -> bool:
    """Recognize a settled attempt; use completion_attempts to count starts too."""
    return entry.get("event") in {
        "anchor_checked", "candidate_refused", "anchor_unavailable", "ceiling_reached",
        "verification_interrupted",
    } or (entry.get("event") == "frozen_spec_changed" and entry.get("completion_candidate") is True)


def completion_attempts(events: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """One latest observation per attempt, including starts without an outcome.

    Legacy rows without an ID remain separate attempts. Starting and settling a
    new attempt must not spend its ceiling twice.
    """
    attempts: list[dict[str, Any]] = []
    positions: dict[str, int] = {}
    for entry in events:
        if entry.get("event") != "verification_started" and not completion_attempt(entry):
            continue
        identity = entry.get("verification_id")
        if isinstance(identity, str) and identity:
            if identity in positions:
                attempts[positions[identity]] = entry
                continue
            positions[identity] = len(attempts)
        attempts.append(entry)
    return attempts


def append_event(goal: ActiveGoal, entry: dict[str, Any]) -> bool:
    """Append one line to the goal's event log. Returns whether it landed.

    A silent failure here used to be announced as a success: the gate said
    "passed on attempt N" over an empty log (round 4's probe wrote a green
    allow while the log stayed zero bytes). The caller decides what an
    unrecorded attempt means; this just refuses to pretend it was recorded.
    """
    try:
        goal.goals_dir.mkdir(parents=True, exist_ok=True)
        with goal.events_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(entry, ensure_ascii=False, sort_keys=True) + "\n")
        return True
    except (OSError, UnicodeError, TypeError, ValueError):
        return False


def read_events(goal: ActiveGoal) -> list[dict[str, Any]]:
    """Read the goal's event log. A malformed line is skipped, not fatal."""
    events: list[dict[str, Any]] = []
    try:
        if not goal.events_path.is_file():
            return events
        for line in goal.events_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
            except (json.JSONDecodeError, UnicodeError):
                continue
            if isinstance(entry, dict):
                events.append(entry)
    except (OSError, UnicodeError):
        return events
    return events


def sections(text: str) -> dict[str, str]:
    """Map lowercased `## ` headings to their body text."""
    found: dict[str, str] = {}
    current: str | None = None
    body: list[str] = []
    for line in text.splitlines():
        if line.startswith("## "):
            if current is not None:
                found[current] = "\n".join(body)
            current = line[3:].strip().lower()
            body = []
        elif current is not None:
            body.append(line)
    if current is not None:
        found[current] = "\n".join(body)
    return found


def frozen_digest(spec: str) -> str:
    """Digest exactly the sections the run may not edit.

    Machine-written and machine-compared, which is the only reason it is worth
    anything: the model authors the artifact, so its own account of whether the
    goal moved is a claim. This is not tamper-proof - an agent can write any
    file it can read - but the event log is committed, so a moved goalpost turns
    up in `--audit` and in `git log` instead of passing silently. Making it
    visible is the achievable property; making it impossible is not.
    """
    parts = sections(spec)
    joined = "\n".join(parts.get(name, "") for name in FROZEN_SECTIONS)
    # Requirement text is invariant; checkboxes are mutable progress claims.
    joined += "\nacceptance:\n" + re.sub(
        r"(?m)^(\s*[-*]\s+)\[[ xX]\]", r"\1[ ]", parts.get("acceptance", "")
    )
    # Include continuation lines: moving a label to the next line cannot
    # turn an owner-owned declaration into mutable prose.
    labelled = [block for block in bullet_blocks(parts.get("means", ""))
                if re.search(r"\[(?:load-bearing|droppable)\]", block, re.I)]
    if labelled:
        joined += "\nmeans labels:\n" + "\n".join(labelled)
    return hashlib.sha256(joined.encode("utf-8", "replace")).hexdigest()[:12]


def bullet_blocks(text: str) -> list[str]:
    """A bullet and its indented continuation lines, shared by validation/digests."""
    blocks: list[str] = []
    current: list[str] = []
    for line in text.splitlines():
        if re.match(r"^\s*[-*]\s+", line):
            if current:
                blocks.append("\n".join(current))
            current = [line.strip()]
        elif current and line[:1].isspace() and line.strip():
            current.append(line.strip())
        else:
            if current:
                blocks.append("\n".join(current))
            current = []
    if current:
        blocks.append("\n".join(current))
    return blocks
