"""Shared acceptance contract and evidence checks; no task scheduling.

The owner approves criteria and provenance. These checks bind declared criteria,
evaluator files and review inputs; they do not authenticate a writable filesystem
or prove that a chosen criterion captures the owner's intent.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
from datetime import datetime, timezone
import random
import time
from contextlib import contextmanager, ExitStack
from collections.abc import Callable
from pathlib import Path
import re
import shlex
import signal
import statistics
import subprocess
import tempfile
import unicodedata
import zipfile

from goal_hooks import ActiveGoal, sections, read_events, frozen_digest, frozen_baselines_match, goal_commits

VERIFICATION_BASELINE_SUFFIX = ".verification.baseline"
ACCEPTANCE = re.compile(r"^\s*[-*]\s+\[[ xX]\]\s+([A-Za-z][A-Za-z0-9_-]*):\s+(.+)$", re.M)
OBJECTIVE_FIELDS = frozenset(("measure", "direction", "margin", "samples", "timeout", "measures",
                              "plateau", "audit", "audit_failures", "target", "holdout", "screen", "transfer", "frontier", "inputs"))
OBJECTIVE_FIELD = re.compile(r"\s*([A-Za-z][A-Za-z0-9_-]*):\s*(.*?)\s*")
# The gate cleans `__pycache__/` and points the interpreter at a fresh cache prefix; a
# command that names its own prefix would load whatever bytecode sits there instead.
CACHE_OVERRIDE = re.compile(r"pycache_prefix|PYTHONPYCACHEPREFIX", re.I)
COMPILED_SUFFIXES = (".pyc", ".pyo", ".pyd", ".so")


def cache_override(text: str) -> bool:
    """Whether a command names its own bytecode cache location, read as the shell joins quotes.

    A check on commands the owner approved, catching a misconfiguration; a command
    written to hide the setting, such as through a variable, is beyond it.
    """
    for line in text.splitlines() or [text]:
        try:
            line = " ".join(shlex.split(line))
        except ValueError:
            # An unbalanced quote elsewhere on the line; drop the quoting characters instead.
            line = re.sub(r"[\"'\\]", "", line)
        if CACHE_OVERRIDE.search(line):
            return True
    return False


def objective(spec: str) -> dict | None:
    """Parse the owner-frozen optimization judge, without interpreting prose."""
    body = sections(spec).get("objective")
    if body is None:
        return None
    fields = {}
    for line in body.splitlines():
        match = OBJECTIVE_FIELD.fullmatch(line)
        if match:
            key, value = match.group(1).lower(), match.group(2)
            if key not in OBJECTIVE_FIELDS:
                continue
            if key in fields:
                raise ValueError(f"Objective has duplicate key: {key}.")
            fields[key] = value
    for key in ("measure", "direction", "margin", "measures", "audit"):
        if key not in fields:
            raise ValueError(f"Objective requires {key}.")
    if ("holdout" in fields) != ("transfer" in fields):
        raise ValueError("Objective transfer is required with holdout and invalid without it.")
    data = dict(fields)
    for key in ("measure", "holdout", "screen"):
        if key in fields:
            match = re.fullmatch(r"`([^`\n]+)`", fields[key])
            if not match or not match.group(1).strip():
                raise ValueError(f"Objective {key} requires exactly one backticked command.")
            data[key] = match.group(1).strip()
            if cache_override(data[key]):
                raise ValueError(f"Objective {key} sets the Python bytecode cache location, which the gate controls.")
    if fields["direction"] not in ("higher", "lower"):
        raise ValueError("Objective direction must be higher or lower.")
    for key in ("margin", "target", "transfer"):
        if key not in fields:
            continue
        raw = fields[key]
        percent = key in ("margin", "transfer") and raw.endswith("%")
        try:
            number = float(raw[:-1] if percent else raw)
        except ValueError as exc:
            raise ValueError(f"Objective {key} must be a finite number.") from exc
        if not math.isfinite(number) or (key == "margin" and number < 0):
            raise ValueError(f"Objective {key} must be finite" + (" and nonnegative." if key == "margin" else "."))
        if key == "transfer" and (not percent or not 0 < number <= 100):
            raise ValueError("Objective transfer must be N% with 0 < N <= 100.")
        data[key] = number / 100 if key == "transfer" else number
        if key == "margin":
            data["margin_percent"] = percent
    data["inputs"] = re.split(r"[\s,]+", fields["inputs"].strip()) if fields.get("inputs", "").strip() else []
    _paths(data["inputs"])
    protected = verification(spec)["protected"]
    if any(not under_paths(path, protected) for path in data["inputs"]):
        raise ValueError("Objective inputs must be under protected paths.")
    data["samples"] = fields.get("samples", "3")
    data["audit_failures"] = fields.get("audit_failures", "2")
    for key in ("measures", "audit", "audit_failures", "samples", "plateau"):
        if key not in data:
            continue
        raw = data[key]
        if key == "measures" and raw == "none":
            data[key] = None
        else:
            expected = "an integer from 1 to 50" if key == "samples" else "a positive integer"
            if key == "measures":
                expected += " or none"
            if not re.fullmatch(r"[0-9]+", raw) or int(raw) < 1 or (key == "samples" and int(raw) > 50):
                raise ValueError(f"Objective {key} must be {expected}.")
            data[key] = int(raw)
    duration = re.fullmatch(r"([0-9]+)\s+(second|minute|hour)s?", fields.get("timeout", "10 minutes"), re.I)
    if not duration or int(duration.group(1)) < 1:
        raise ValueError("Objective timeout must be a positive N seconds, minutes or hours.")
    data["timeout"] = int(duration.group(1)) * {"second": 1, "minute": 60, "hour": 3600}[duration.group(2).lower()]
    if verification(spec)["review"] is None:
        raise ValueError("Objective requires an independent review contract; review cannot be null.")
    return data


def objective_margin(definition: dict, value: float) -> float:
    return abs(value) * definition["margin"] / 100 if definition["margin_percent"] else definition["margin"]


def objective_state(events: list[dict], definition: dict) -> dict:
    """Project measurements, rollback and replay from the append-only ledger."""
    baseline = incumbent = last_audit = safe = replay = None
    used = since_keep = keeps = audits = keeps_since_audit = failures = voided_keeps = 0
    closed = None
    alarm = False
    readings, bests, changes = {}, {}, {}
    audit_history = []
    pending_keeps, judged_trees = [], set()
    reference_failures = set()
    last_change = replay_position = -1
    strategy = None
    margin_below_noise = strategy_unchanged = False
    audit_window_value = None
    for position, event in enumerate(events):
        kind = event.get("event")
        current_replay = bool(kind == "objective_replayed" and incumbent
                              and event.get("incumbent", {}).get("product_tree") == incumbent["product_tree"]
                              and event.get("binding", True) is True
                              and event.get("valid") is True)
        falsified = current_replay and event.get("reproduces") is False
        if kind in ("objective_drift_alarm", "objective_audit_failed") or falsified:
            audit_window_value = None
            if kind == "objective_audit_failed":
                failures += 1
                voided_keeps += len(pending_keeps)
                for tree in pending_keeps:
                    judged_trees.discard(tree)
                    readings.pop(tree, None)
                    bests.pop(tree, None)
                    changes.pop(tree, None)
            if falsified:
                prior = [audit for index, audit in audit_history if index < changes[incumbent["product_tree"]]]
                last_audit = prior[-1] if prior else None
                safe = last_audit["incumbent"] if last_audit else None
                replay, replay_position = event, position
            if kind != "objective_audit_failed" or failures >= definition["audit_failures"]:
                closed = "replay" if falsified else event.get("reason") or kind
            alarm |= kind == "objective_drift_alarm"
            incumbent = {key: value for key, value in (safe or baseline).items() if key != "holdout"} if (safe or baseline) else None
            if incumbent:
                incumbent["value"] = statistics.median(readings[incumbent["product_tree"]])
                incumbent["best_value"] = bests[incumbent["product_tree"]]
                last_change = changes[incumbent["product_tree"]]
            keeps_since_audit = 0
            pending_keeps.clear()
        elif kind == "objective_audited":
            last_audit = event
            audit_window_value = event.get("incumbent_measure_median") if event.get("decision_rule") == "paired-v1" else None
            audit_history.append((position, event))
            safe = dict(event["incumbent"])
            audits += 1
            keeps_since_audit = 0
            pending_keeps.clear()
        elif kind == "objective_replayed":
            if current_replay and event.get("reproduces") is True:
                replay, replay_position = event, position
        elif kind == "objective_measured":
            verdict = event.get("verdict")
            reference_failed = verdict == "unknown" and (event.get("reason") or "").startswith("reference_")
            tree = event.get("product_tree")
            retry_without_budget = verdict == "unknown" and (
                event.get("reason") == "setup_failed" or (reference_failed and tree not in reference_failures))
            if reference_failed:
                reference_failures.add(tree)
            if not retry_without_budget and (verdict == "invalid" or (
                    verdict in ("baseline", "keep", "discard", "crash", "unknown")
                    and not event.get("remeasure", False))):
                used += 1
                since_keep += 1
            if event.get("strategy") and not retry_without_budget:
                strategy = event["strategy"]
                strategy_unchanged = event.get("strategy_unchanged_after_plateau", False)
            if verdict in ("baseline", "keep") or (verdict == "discard" and baseline is not None):
                judged_trees.add(event["product_tree"])
            if verdict in ("baseline", "keep", "remeasured"):
                tree = event["product_tree"]
                values = [sample["value"] for sample in event.get("samples", [])]
                readings.setdefault(tree, []).extend(values or [event["median"]])
                better = min if definition["direction"] == "lower" else max
                bests[tree] = better(bests.get(tree, event["median"]), event["median"])
                if verdict in ("baseline", "keep"):
                    incumbent = {"index": event["index"], "commit": event["commit"],
                                 "product_tree": tree, "value": statistics.median(readings[tree]),
                                 "best_value": bests[tree]}
                    last_change = changes[tree] = position
                    audit_window_value = None
                    since_keep = 0
                    if verdict == "baseline":
                        baseline = {**incumbent, "holdout": event.get("holdout", {}).get("value")}
                        noise = (2 * 1.2533 * statistics.stdev(values) * math.sqrt(2 / len(values))
                                 if len(values) >= 2 else None)
                        margin_below_noise = noise is not None and objective_margin(definition, event["median"]) <= noise
                    else:
                        keeps += 1
                        keeps_since_audit += 1
                        pending_keeps.append(tree)
                elif incumbent and tree == incumbent["product_tree"]:
                    incumbent = {**incumbent, "value": statistics.median(readings[tree]), "best_value": bests[tree]}
    target = definition.get("target")
    target_value = (audit_window_value if incumbent and last_audit
                    and last_audit.get("incumbent", {}).get("product_tree") == incumbent["product_tree"]
                    and audit_window_value is not None else None)
    reached = bool(target_value is not None and target is not None and (
        target_value >= target if definition["direction"] == "higher" else target_value <= target))
    audited = bool(incumbent and last_audit
                   and last_audit.get("incumbent", {}).get("product_tree") == incumbent["product_tree"])
    replayed = bool(incumbent and replay and replay_position > last_change
                    and replay.get("incumbent", {}).get("product_tree") == incumbent["product_tree"]
                    and replay.get("valid") is True and replay.get("reproduces") is True)
    return {"baseline": baseline, "incumbent": incumbent, "candidates_used": used,
            "budget": definition["measures"], "since_last_keep": since_keep,
            "keeps": keeps, "audits": audits, "keeps_since_audit": keeps_since_audit,
            "audit_failures": failures, "audit_failure_limit": definition["audit_failures"],
            "audit_failures_remaining": max(0, definition["audit_failures"] - failures),
            "voided_keeps": voided_keeps, "judged_trees": sorted(judged_trees),
            "audit_due": not closed and keeps_since_audit >= definition["audit"], "drift_alarm": alarm,
            "closed": bool(closed), "closure_reason": closed, "last_strategy": strategy,
            "margin_below_noise": margin_below_noise,
            "strategy_unchanged_after_plateau": strategy_unchanged,
            "last_audit": last_audit, "audited": audited, "target_reached": reached,
            "replay": replay, "replayed": replayed,
            **{key: (last_audit or {}).get(key) for key in ("objective_gain", "holdout_gain", "gain_ratio", "rule")},
            "plateau": bool(definition.get("plateau") and since_keep >= definition["plateau"]),
            "budget_exhausted": definition["measures"] is not None and used >= definition["measures"],
            "target": target, "frontier": definition.get("frontier")}


def product_tree(root: Path, commit: str = "HEAD") -> str:
    result = subprocess.run(["git", "ls-tree", "-r", commit], cwd=root,
                            capture_output=True, timeout=30)
    if result.returncode:
        raise ValueError("Objective requires a usable Git HEAD.")
    # Git quotes special filenames; the directory prefix remains literal.
    lines = [line for line in result.stdout.splitlines(keepends=True)
             if not line.split(b"\t", 1)[-1].lstrip(b'"').startswith(b".goals/")]
    return hashlib.sha256(b"".join(lines)).hexdigest()[:12]


def check_product(root: Path, expected: str | None = None) -> str:
    tree = product_tree(root)
    result = subprocess.run(["git", "status", "--porcelain", "--", ".", ":!.goals"],
                            cwd=root, capture_output=True, timeout=30)
    if result.returncode or result.stdout.strip():
        raise ValueError("Objective requires a clean product work tree outside .goals/.")
    if expected is not None and tree != expected:
        raise ValueError("Product tree changed; restore the incumbent before continuing.")
    return tree


class VerificationLockError(OSError):
    pass


@contextmanager
def verification_lock(goal: ActiveGoal):
    # Keep the inode: unlinking a lock can let two gates lock different files.
    try:
        lock = (goal.goals_dir / f"{goal.slug}.verification.lock").open("a+b")
    except OSError as exc:
        raise VerificationLockError("Verification lock is unavailable.") from exc
    with lock:
        try:
            if os.name == "nt":
                import msvcrt
                if lock.seek(0, 2) == 0:
                    lock.write(b"\0"); lock.flush()
                lock.seek(0)
                msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            raise VerificationLockError("Verification is already in progress or its lock is unavailable.") from exc
        yield


def verification(spec: str) -> dict:
    """Read the exact contract consumed by arming and completion checks."""
    found = sections(spec)
    blocks = re.findall(r"```json\s*\n(.*?)\n```", found.get("verification", ""), re.S)
    if len(blocks) != 1:
        raise ValueError("Verification needs a JSON contract; prose alone cannot declare independent evidence.")
    try:
        data = json.loads(blocks[0])
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid Verification JSON: {exc.msg}") from exc
    if not isinstance(data, dict) or set(data) != {"source", "basis", "protected", "covers", "review"}:
        raise ValueError("Verification requires exactly source, basis, protected, covers and review.")
    if data["source"] not in ("owner-approved", "external") or not isinstance(data["basis"], str) or not data["basis"].strip():
        raise ValueError("Name owner-approved or external evidence and its concrete basis; generator self-review is not a source.")
    _paths(data["protected"])
    if data["source"] == "owner-approved" and not data["protected"]:
        raise ValueError("Owner-approved evaluator definitions need protected files.")
    items = ACCEPTANCE.findall(found.get("acceptance", ""))
    ids = [item[0] for item in items]
    bullets = re.findall(r"^\s*[-*]\s+\[[ xX]\]", found.get("acceptance", ""), re.M)
    if not ids or len(ids) != len(set(ids)) or len(ids) != len(bullets):
        raise ValueError("Acceptance needs unique '- [ ] requirement-id: outcome' entries.")
    covers = data["covers"]
    if not isinstance(covers, dict) or set(covers) != set(ids) or any(v not in ("anchor", "review") for v in covers.values()):
        raise ValueError("Verification covers must map every Acceptance ID exactly once to anchor or review.")
    if not re.search(r"^success:\s*verified\s*$", found.get("stop condition", ""), re.M):
        raise ValueError("Stop condition needs 'success: verified': current anchor and all required review evidence must pass.")
    if not re.search(r"^ceiling:\s*(none|\d+)\s*$", found.get("stop condition", ""), re.M):
        raise ValueError("Stop condition needs an explicit 'ceiling: N' or 'ceiling: none'.")
    review = data["review"]
    if review is None:
        if "review" in covers.values():
            raise ValueError("Acceptance assigned to review requires a review contract.")
    else:
        if not isinstance(review, dict) or set(review) != {"path", "verifiers", "inputs"}:
            raise ValueError("Review requires exactly path, verifiers and inputs; use null when no semantic review is required.")
        _paths([review["path"]]); _paths(review["inputs"])
        if not review["inputs"] or not isinstance(review["verifiers"], list) or not review["verifiers"]:
            raise ValueError("Review needs bounded inputs and at least one approved verifier identity.")
        if any(not isinstance(v, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]*", v) for v in review["verifiers"]):
            raise ValueError("Review verifier identities must be nonempty tokens.")
        receipt = Path(review["path"])
        if any(receipt == Path(p) or Path(p) in receipt.parents for p in review["inputs"]):
            raise ValueError("The review receipt cannot be among its own reviewed inputs.")
    return data


def _paths(paths: object) -> None:
    if not isinstance(paths, list) or any(not isinstance(p, str) or not p or Path(p).is_absolute()
                                        or ".." in Path(p).parts or p == "." for p in paths):
        raise ValueError("Evidence paths must be explicit project-relative files or directories, without '..'.")


def _folded(name: str) -> str:
    return unicodedata.normalize("NFC", name).casefold()


def bytecode_cache(path: str) -> bool:
    """A file in Python's own cache folder, rewritten by every run of the files beside it.

    Hashing it made the first Python anchor look like tampering. Only `__pycache__/`
    qualifies: Python never imports a file there without its source (PEP 3147), while a
    sourceless `.pyc` placed beside a script can shadow a module and stays protected.
    Every file there counts, whatever its name: a case-insensitive disk opens `X.PYC`,
    `__PYCACHE__/` or `ſcoring` (long s) when the importer asks for
    `__pycache__/x.pyc` or `scoring`, and its folding rules are not Python's.
    """
    return "__pycache__" in [_folded(part) for part in path.split("/")[:-1]]


def _tracked(root: Path, paths: list[str]) -> set[str]:
    """Which of `paths` Git tracks, asked of the repository that holds each folder.

    Each repository lists its whole index once, and names compare after normalization
    and case folding: a case-insensitive disk can hold a tracked file under another
    spelling, and no file name reaches Git as a pathspec it could misread. A nested
    repository or submodule answers for its own files; a folder that no longer exists
    holds nothing. Outside any repository nothing is tracked; a failure inside one
    raises, because reading it as "untracked" would let the purge delete tracked files.
    """
    base = root.resolve()
    tops: dict[Path, Path | None] = {}
    indexes: dict[Path, set[str]] = {}
    tracked = set()
    for path in paths:
        folder = base / path.rpartition("/")[0]
        if not folder.is_dir():
            continue
        if folder not in tops:
            tops[folder] = _repository_top(folder)
        top = tops[folder]
        if top is None:
            continue
        if top not in indexes:
            listed = subprocess.run(["git", "ls-files", "-z"], cwd=top, capture_output=True, timeout=30)
            if listed.returncode:
                raise ValueError("Cannot list tracked files: " + listed.stderr.decode("utf-8", "replace").strip())
            indexes[top] = {_folded(os.fsdecode(entry)) for entry in listed.stdout.split(b"\0") if entry}
        if _folded(Path(os.path.relpath(base / path, top)).as_posix()) in indexes[top]:
            tracked.add(path)
    return tracked


def _repository_top(folder: Path) -> Path | None:
    """The work tree that holds `folder`, or None outside any repository."""
    result = subprocess.run(["git", "rev-parse", "--show-toplevel"], cwd=folder,
                            capture_output=True, timeout=30)
    if result.returncode == 0:
        return Path(os.fsdecode(result.stdout.strip())).resolve()
    # lexists: a `.git` link that points nowhere is still a repository that failed.
    if any(os.path.lexists(parent / ".git") for parent in (folder, *folder.parents)):
        raise ValueError("Cannot read the repository: " + result.stderr.decode("utf-8", "replace").strip())
    return None


def _without_symlinks(root: Path, child: Path) -> bool:
    """Whether `child` is reached from `root` without passing through any symlink."""
    return child.resolve() == root.resolve() / child.relative_to(root)


def _protected_scope(path: str, protected: list[str]) -> bool:
    """A protected path, or anything under the cache folder beside a protected module."""
    if under_paths(path, protected):
        return True
    parts = path.split("/")
    return any(_folded(part) == "__pycache__"
               and any(_folded(Path(raw).suffix) == ".py" and Path(raw).parent == Path(*parts[:index])
                       for raw in protected)
               for index, part in enumerate(parts[:-1]))


def _cache_folder_entries(parent: Path) -> list[Path]:
    """Every entry named `__pycache__` in `parent`, and all beneath it.

    Names fold as the disk may fold them, and are listed rather than globbed, since a glob
    matches case-sensitively and the importer may not. Links are listed, not followed, so
    the caller can refuse them before looking at what they point to.
    """
    entries = []
    for folder in sorted(parent.iterdir()):
        if _folded(folder.name) == "__pycache__":
            entries.append(folder)
            if folder.is_dir() and not folder.is_symlink():
                entries.extend(sorted(folder.rglob("*")))
    return entries


def _cache_entries(root: Path, raw: str, listed: set[Path] | None = None) -> list[Path]:
    """The cache folder entries beside a protected module; each folder once per `listed`."""
    path = root / raw
    if _folded(path.suffix) != ".py" or not path.parent.is_dir():
        return []
    if listed is not None:
        if path.parent in listed:
            return []
        listed.add(path.parent)
    return _cache_folder_entries(path.parent)


def _bytecode_scope(root: Path, raw: str, listed: set[Path] | None = None) -> list[Path]:
    """The bytecode caches of a protected path: within it, or beside a protected module.

    Every file counts, not the module's own name: the disk decides which name opens.
    """
    path = root / raw
    if path.is_dir():
        return [child for child in sorted(path.rglob("*"))
                if child.is_file() and bytecode_cache(child.relative_to(root).as_posix())]
    return [entry for entry in _cache_entries(root, raw, listed) if entry.is_file()]


def snapshot(root: Path, paths: list[str]) -> dict[str, str]:
    """Hash the declared file set, including additions/removals under directories.

    Bytecode caches count only when Git tracks them: committed bytecode can replace a
    protected module, while an untracked cache is deleted before every evaluator the
    gate runs (`purge_bytecode`) and so is neither trusted nor hashed.
    """
    _paths(paths)
    files: dict[str, str] = {}
    caches: dict[str, Path] = {}
    listed: set[Path] = set()
    for raw in paths:
        path = root / raw
        if not path.exists():
            raise ValueError(f"Evidence input is missing: {raw}")
        children = [path, *sorted(path.rglob("*"))] if path.is_dir() else [path]
        for child in [*children, *_cache_entries(root, raw, listed)]:
            if not _without_symlinks(root, child):
                raise ValueError(f"Evidence input must not traverse a symlink: {raw}")
            relative = child.relative_to(root).as_posix()
            if not child.is_file():
                continue
            if bytecode_cache(relative):
                caches[relative] = child
                continue
            with child.open("rb") as stream:
                files[relative] = _stream_digest(stream)
    for relative in _tracked(root, sorted(caches)):
        with caches[relative].open("rb") as stream:
            files[relative] = _stream_digest(stream)
    return files


def recorded_snapshot(path: Path, root: Path) -> dict[str, str]:
    """An armed baseline, minus untracked bytecode recorded before snapshots skipped it."""
    recorded = json.loads(path.read_text())
    tracked = _tracked(root, sorted(name for name in recorded if bytecode_cache(name)))
    return {name: digest for name, digest in recorded.items()
            if not bytecode_cache(name) or name in tracked}


def purge_bytecode(root: Path, paths: list[str]) -> None:
    """Delete untracked bytecode caches of protected paths before an evaluator runs.

    Hashing them refused every Python anchor after its first run, and skipping them
    was unsafe: an interpreter started with -E or -I ignores PYTHONPYCACHEPREFIX and
    loads a planted unchecked-hash cache instead of the protected source. With the
    cache gone Python rebuilds it from that source. Nothing reached through a symlink
    is deleted: Git cannot see behind one, so its target may be a tracked file.
    """
    listed: set[Path] = set()
    caches = {child.relative_to(root).as_posix(): child
              for raw in paths for child in _bytecode_scope(root, raw, listed)
              if _without_symlinks(root, child)}
    tracked = _tracked(root, sorted(caches))
    for relative, child in caches.items():
        if relative not in tracked:
            child.unlink(missing_ok=True)


def _stream_digest(stream) -> str:
    digest = hashlib.sha256()
    for chunk in iter(lambda: stream.read(1 << 20), b""):
        digest.update(chunk)
    return digest.hexdigest()


def _input_digest(spec: str, files: dict[str, str], tree: str | None = None) -> str:
    data = {"contract": frozen_digest(spec), "files": files}
    if tree is not None:
        data["product_tree"] = tree
    payload = json.dumps(data,
                         sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode()).hexdigest()


def input_digest(root: Path, spec: str) -> str:
    review = verification(spec)["review"]
    if review is None:
        raise ValueError("This goal has no required review.")
    return _input_digest(spec, snapshot(root, review["inputs"]),
                         product_tree(root) if objective(spec) is not None else None)


def pin_verification(root: Path, slug: str, spec: str) -> None:
    """Write before activation, never silently replace an existing baseline."""
    definition = verification(spec)
    observed = snapshot(root, definition["protected"])
    if definition["source"] == "owner-approved" and not observed:
        raise ValueError("No evaluator files were found in the protected paths.")
    path = root / ".goals" / f"{slug}{VERIFICATION_BASELINE_SUFFIX}"
    if path.exists():
        if recorded_snapshot(path, root) != observed:
            raise ValueError("Protected evaluator inputs changed; restore them or start a newly authorized goal.")
        return
    with path.open("x", encoding="utf-8") as handle:
        json.dump(observed, handle, sort_keys=True)
        handle.write("\n")


def check_protection(goal: ActiveGoal, spec: str) -> None:
    baseline = goal.goals_dir / f"{goal.slug}{VERIFICATION_BASELINE_SUFFIX}"
    if not baseline.is_file():
        raise ValueError("No arming-time evaluator baseline; this goal has not established its verification contract.")
    if objective(spec) is not None:
        check_objective_protection(goal, spec, goal.goals_dir.parent)
        return
    if recorded_snapshot(baseline, goal.goals_dir.parent) != snapshot(goal.goals_dir.parent, verification(spec)["protected"]):
        raise ValueError("Protected evaluator inputs changed; restore them, do not weaken the checker or re-baseline the run.")


def under_paths(path: str, paths: list[str]) -> bool:
    return any(Path(path) == Path(raw) or Path(raw) in Path(path).parents for raw in paths)


def objective_command_paths(command: str, root: Path) -> list[str]:
    """Project paths named by a command, including files not created yet."""
    extensions = {".py", ".pyc", ".pyw", ".sh", ".bash", ".zsh", ".js", ".mjs", ".cjs", ".jsx", ".ts", ".tsx",
                  ".rb", ".pl", ".r", ".lua", ".php", ".ps1", ".bat", ".cmd", ".json", ".jsonl", ".ndjson",
                  ".csv", ".tsv", ".yaml", ".yml", ".toml", ".txt", ".dat", ".data"}
    paths = []
    for token in shlex.split(command, posix=os.name != "nt"):
        token = token.strip('"')
        if token.startswith("-") and "=" in token:
            token = token.split("=", 1)[1].strip('"')
        candidate = Path(os.path.abspath(root / token))
        if (candidate.is_relative_to(root)
                and ("/" in token or "\\" in token or candidate.suffix.lower() in extensions or candidate.exists())):
            paths.append(candidate.relative_to(root).as_posix())
    return paths


def _tracked_paths(root: Path, commit: str) -> list[str]:
    result = subprocess.run(["git", "ls-tree", "-rz", "--name-only", commit], cwd=root,
                            capture_output=True, timeout=30, check=True)
    return [os.fsdecode(path) for path in result.stdout.split(b"\0") if path]


def _tracked_blobs(root: Path, commit: str) -> list[tuple[str, str]]:
    """(path, object id) for every file in `commit`."""
    result = subprocess.run(["git", "ls-tree", "-rz", commit], cwd=root,
                            capture_output=True, timeout=30, check=True)
    entries = []
    for entry in result.stdout.split(b"\0"):
        if entry:
            meta, path = entry.split(b"\t", 1)
            entries.append((os.fsdecode(path), meta.split()[2].decode()))
    return entries


def check_objective_protection(goal: ActiveGoal, spec: str, checkout: Path) -> None:
    root = goal.goals_dir.parent
    inputs = objective(spec)["inputs"]
    protected = verification(spec)["protected"]
    revision = (goal.goals_dir / f"{goal.slug}.baseline").read_text().strip()
    # Tracked means tracked at the arming revision, never in the work tree being judged.
    armed = json.loads((goal.goals_dir / f"{goal.slug}{VERIFICATION_BASELINE_SUFFIX}").read_text())
    tracked = [path for path in _tracked_paths(root, revision) if _protected_scope(path, protected)]
    expected = {path: digest for path, digest in armed.items()
                if path in tracked or under_paths(path, inputs)}
    current = [path for path in _tracked_paths(checkout, "HEAD")
               if under_paths(path, protected) and not under_paths(path, inputs)]
    observed = {**snapshot(checkout, current), **snapshot(root, inputs)}
    if observed != expected:
        raise ValueError("Protected evaluator inputs changed; restore them, do not re-baseline the run.")


OBJECTIVE_ENV = ("PATH", "HOME", "USER", "LOGNAME", "SHELL", "LANG", "LC_ALL", "LC_CTYPE", "TZ", "TERM")
WINDOWS_ENV = ("SYSTEMROOT", "COMSPEC", "PATHEXT", "USERPROFILE", "APPDATA", "LOCALAPPDATA")


def pin_objective_environment(root: Path, slug: str) -> None:
    path = root / ".goals" / f"{slug}.objective-env.json"
    if not path.exists():
        keys = (*OBJECTIVE_ENV, *WINDOWS_ENV) if os.name == "nt" else OBJECTIVE_ENV
        with path.open("x", encoding="utf-8") as handle:
            json.dump({key: os.environ[key] for key in keys if key in os.environ}, handle, sort_keys=True)
            handle.write("\n")


def objective_environment(goal: ActiveGoal) -> tuple[dict, str]:
    encoded = (goal.goals_dir / f"{goal.slug}.objective-env.json").read_bytes()
    env = json.loads(encoded)
    allowed = {*OBJECTIVE_ENV, *WINDOWS_ENV} if os.name == "nt" else set(OBJECTIVE_ENV)
    if (not isinstance(env, dict) or not set(env).issubset(allowed)
            or any(not isinstance(value, str) for value in env.values())):
        raise ValueError("Invalid pinned Objective environment.")
    return env, hashlib.sha256(encoded).hexdigest()


def _evaluation_command(command: str, checkout: Path, env: dict, timeout: int) -> dict:
    process = None
    drained = False
    try:
        group = ({"creationflags": getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0x00000200)}
                 if os.name == "nt" else {"start_new_session": True})
        process = subprocess.Popen(command, shell=True, cwd=checkout, env=env, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, text=True, **group)
        try:
            output, error = process.communicate(timeout=timeout)
            drained = True
        except subprocess.TimeoutExpired:
            failures = []
            try:
                if os.name == "nt":
                    subprocess.run(["taskkill", "/F", "/T", "/PID", str(process.pid)],
                                   capture_output=True, timeout=5, check=True)
                else:
                    os.killpg(process.pid, signal.SIGKILL)
            except (OSError, subprocess.SubprocessError) as exc:
                failures.append(str(exc))
                try:
                    process.kill()
                except OSError as exc:
                    failures.append(str(exc))
            try:
                output, error = process.communicate(timeout=5)
                drained = True
            except (OSError, ValueError, UnicodeError, subprocess.SubprocessError) as exc:
                output = error = ""
                failures.append(str(exc))
            return {"exit_code": None, "output": (output + error + "\n".join(failures))[-2000:], "timed_out": True, "stdout": output}
        return {"exit_code": process.returncode, "output": output + error, "stdout": output}
    except (OSError, ValueError, UnicodeError) as exc:
        return {"exit_code": None, "output": str(exc)}
    finally:
        # Windows reader threads own the pipes until drained; close() can otherwise block.
        if process is not None and drained:
            for stream in (process.stdout, process.stderr):
                if stream is not None:
                    stream.close()


@contextmanager
def _evaluation_checkout(goal: ActiveGoal, spec: str, commit: str, env: dict,
                         env_digest: str, result: dict):
    """The common isolated checkout lifecycle for single and paired evaluation."""
    root = goal.goals_dir.parent.resolve()
    definition = objective(spec)
    try:
        evaluation_directory = tempfile.TemporaryDirectory(prefix="ultragoal-eval-")
    except OSError as exc:
        result["setup_failed"] = str(exc)
        yield None
        return
    with evaluation_directory as directory:
        base = Path(directory)
        if base.resolve().is_relative_to(root):
            raise ValueError("Evaluation temporary directory must be outside the project.")
        checkout = base / "checkout"
        temporary = base / "tmp"
        env.update({key: str(temporary) for key in ("TMPDIR", "TMP", "TEMP")})
        env["PYTHONPYCACHEPREFIX"] = str(base / "pycache")
        guarded = [path for path in verification(spec)["protected"]
                   if not under_paths(path, definition["inputs"])]

        def check():
            current = goal.goal_path.read_text()
            if frozen_digest(current) != frozen_digest(spec) or not frozen_baselines_match(goal, current):
                raise ValueError("Frozen goal terms changed during evaluation.")
            if objective_environment(goal)[1] != env_digest:
                raise ValueError("Pinned Objective environment changed during evaluation.")
            check_objective_protection(goal, spec, checkout)
            protected = verification(spec)["protected"] + definition["inputs"]
            for name in ("measure", "holdout", "screen"):
                if name in definition:
                    for path in objective_command_paths(definition[name], checkout):
                        if not under_paths(path, protected):
                            raise ValueError(f"Objective {name} names an unprotected project path: {path}.")
            status = subprocess.run(["git", "status", "--porcelain", "--untracked-files=no"],
                                    cwd=checkout, capture_output=True, timeout=30, check=True)
            if status.stdout.strip():
                raise ValueError("Tracked files changed during evaluation.")

        prepared = entered = False
        try:
            temporary.mkdir()
            # No repository hooks: `post-checkout` lives in `.git/`, which the run can write.
            (base / "no-hooks").mkdir()
            subprocess.run(["git", "-c", f"core.hooksPath={base / 'no-hooks'}", "worktree", "add", "--detach",
                            str(checkout), commit], cwd=root, capture_output=True, timeout=30, check=True)
            tracked = _tracked_paths(checkout, "HEAD")
            # Committed bytecode and extension modules can stand in for any module and no
            # reviewer can read them: refuse any that differ from the arming revision.
            armed = (goal.goals_dir / f"{goal.slug}.baseline").read_text().strip()
            allowed = set(_tracked_blobs(root, armed))
            committed = sorted(path for path, blob in _tracked_blobs(checkout, "HEAD")
                               if path.lower().endswith(COMPILED_SUFFIXES) and (path, blob) not in allowed)
            if committed:
                raise ValueError("Committed bytecode or extension modules cannot be reviewed or protected: "
                                 + ", ".join(committed[:5]))
            for raw in definition["inputs"]:
                if any(under_paths(path, [raw]) or under_paths(raw, [path]) for path in tracked):
                    raise ValueError(f"Objective input is tracked in {commit}: {raw}")
                destination = checkout / raw
                if destination.exists() or destination.is_symlink():
                    raise ValueError(f"Objective input destination already exists: {raw}")
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.symlink_to(root / raw, target_is_directory=(root / raw).is_dir())
            prepared = True
            check()
            entered = True
            yield checkout, env, check, guarded
        except (ValueError, OSError, subprocess.SubprocessError) as exc:
            if not prepared and not isinstance(exc, ValueError):
                detail = getattr(exc, "stderr", None)
                if isinstance(detail, bytes):
                    detail = detail.decode("utf-8", "replace")
                result["setup_failed"] = str(exc) + (f" {detail.strip()}" if detail else "")
            else:
                result["invalid"] = str(exc)
            if not entered:
                yield None
        finally:
            cleanup_errors = []
            try:
                removed = subprocess.run(["git", "worktree", "remove", "--force", str(checkout)],
                                         cwd=root, capture_output=True, timeout=30)
                if removed.returncode and checkout.exists():
                    cleanup_errors.append("Evaluation worktree removal failed.")
            except (OSError, subprocess.SubprocessError) as exc:
                cleanup_errors.append(f"Evaluation worktree removal failed: {exc}")
            finally:
                try:
                    subprocess.run(["git", "worktree", "prune"], cwd=root, capture_output=True,
                                            timeout=30, check=True)
                except (OSError, subprocess.SubprocessError) as exc:
                    cleanup_errors.append(f"Evaluation worktree prune failed: {exc}")
            if cleanup_errors:
                result["cleanup_error"] = " ".join(cleanup_errors)
                if not result.get("setup_failed"):
                    result["invalid"] = result["cleanup_error"]


def _run_in_checkout(context: tuple, goal: ActiveGoal, spec: str, command: str, timeout: int) -> dict:
    checkout, env, _, guarded = context
    purge_bytecode(checkout, guarded)
    purge_bytecode(goal.goals_dir.parent.resolve(), objective(spec)["inputs"])
    observation = _evaluation_command(command, checkout, env, timeout)
    return observation


def _numeric_sample(observation: dict) -> dict:
    code = observation["exit_code"]
    lines = observation.get("stdout", "").strip().splitlines()
    last = lines[-1].strip() if lines else ""
    sample = {"exit_code": code, "last_line": last, "value": None,
              "outcome": "unknown" if observation.get("timed_out") else "crash"}
    if code == 0:
        try:
            value = float(last)
            if math.isfinite(value):
                sample.update(value=value, outcome="measured")
        except ValueError:
            pass
    return sample


def evaluate_commit(goal: ActiveGoal, spec: str, commit: str, *, floors: bool = False,
                    measure: int = 0, holdout: int = 0, screen: bool = False,
                    floor_if: Callable[[float], bool] | None = None, hook: bool = False) -> dict:
    """Run one commit in a disposable checkout with the armed judge and environment."""
    from goal_stop import _first_command, _budget, UNRUNNABLE_EXITS

    definition = objective(spec)
    env, env_digest = objective_environment(goal)
    result = {"env_digest": env_digest, "anchor": {"outcome": "not_run", "exit_code": None}}
    phases = []
    section = sections(spec).get("anchor", "")
    if screen and definition.get("screen"):
        phases.append(("screen", definition["screen"], 1, _budget(section, hook=hook)[0]))
    if measure:
        phases.append(("measure", definition["measure"], measure, definition["timeout"]))
    if floors:
        command, ambiguous = _first_command(section)
        if not command or ambiguous:
            raise ValueError(ambiguous or "Anchor unavailable.")
        if cache_override(command):
            raise ValueError("The anchor sets the Python bytecode cache location, which the gate controls.")
        phases.append(("anchor", command, 1, _budget(section, hook=hook)[0]))
    if holdout:
        phases.append(("holdout", definition["holdout"], holdout, definition["timeout"]))
    with _evaluation_checkout(goal, spec, commit, env, env_digest, result) as context:
        if context is None:
            return result
        for name, command, count, timeout in phases:
            if name == "anchor" and floor_if is not None and not floor_if(result["measure"]["value"]):
                continue
            samples = []
            if name not in ("anchor", "screen"):
                result[name] = {"samples": samples, "value": None, "outcome": "crash"}
            for _ in range(count):
                observation = _run_in_checkout(context, goal, spec, command, timeout)
                code, output = observation["exit_code"], observation["output"]
                if name in ("anchor", "screen"):
                    outcome = "green" if code == 0 else "unknown" if code is None or code in UNRUNNABLE_EXITS else "red"
                    result[name] = {**observation, "outcome": outcome,
                                    "output_digest": hashlib.sha256(output.encode("utf-8", "replace")).hexdigest()[:12],
                                    "tail": output.splitlines()[-1][:200] if output else ""}
                else:
                    sample = _numeric_sample(observation)
                    samples.append(sample)
                    result[name].update(outcome=sample["outcome"], output=output[-2000:])
                context[2]()
                if name in ("anchor", "screen") and result[name]["outcome"] != "green":
                    return result
                if name not in ("anchor", "screen") and sample["outcome"] != "measured":
                    return result
            if name not in ("anchor", "screen"):
                result[name]["value"] = statistics.median(sample["value"] for sample in samples)
    return result


def pair_gain(definition: dict, reference: float, candidate: float, *, relative: bool | None = None) -> float | None:
    """Improvement toward the declared direction, in relative or absolute units."""
    delta = reference - candidate if definition["direction"] == "lower" else candidate - reference
    use_relative = definition["margin_percent"] if relative is None else relative
    if use_relative:
        return delta / abs(reference) if reference else None
    return delta


def paired_keep_decision(gains: list[float], definition: dict) -> dict:
    """The paired-v1 fixed eight-pair rule, with a conclusive second-loss stop."""
    wins = sum(gain > 0 for gain in gains)
    losses = len(gains) - wins
    median = statistics.median(gains) if gains else None
    verdict = reason = None
    if losses >= 2:
        verdict, reason = "discard", "not_better"
    elif len(gains) == 8:
        margin = definition["margin"] / 100 if definition["margin_percent"] else definition["margin"]
        verdict, reason = ("keep", None) if median > margin else ("discard", "below_margin")
    return {"verdict": verdict, "reason": reason, "wins": wins, "losses": losses, "median_pair_gain": median}


def evaluate_paired(goal: ActiveGoal, spec: str, reference: str, candidate: str, *, pairs: int,
                    holdout: bool = False, after_pair: Callable[[dict], bool] | None = None,
                    order_seed: int | None = None, allow_nonpositive_reference: bool = False) -> dict:
    """Compare two once-prepared checkouts in a seeded, balanced, same-window run."""
    definition = objective(spec)
    phases = ("measure", "holdout") if holdout else ("measure",)
    env, env_digest = objective_environment(goal)
    seed = random.SystemRandom().getrandbits(128) if order_seed is None else order_seed
    rng = random.Random(seed)
    orders = []
    for _ in range(pairs // 2):
        order = ["reference", "candidate"] if rng.getrandbits(1) else ["candidate", "reference"]
        orders.extend((order, order[::-1]))
    if pairs % 2:
        orders.append(["reference", "candidate"] if rng.getrandbits(1) else ["candidate", "reference"])
    positive = definition["margin_percent"]
    readings = {side: {phase: [] for phase in phases} for side in ("reference", "candidate")}
    result = {"decision_rule": "paired-v1", "order_seed": seed, "env_digest": env_digest,
              "pairs": [], "warmups": [], "readings": readings, "medians": {},
              "gains": {phase: [] for phase in phases}, "median_gains": {},
              "relative_gains": {phase: [] for phase in phases}, "median_relative_gains": {},
              "n_runs": 0, "outcome": "measured", "reason": None}
    started = time.monotonic()

    def run(context, side, phase, pair_seed):
        # Record before the post-run checks too: a tampering run is still evidence.
        checkout, side_env, check, guarded = context
        purge_bytecode(checkout, guarded)
        purge_bytecode(goal.goals_dir.parent.resolve(), definition["inputs"])
        side_env["ULTRAGOAL_PAIR_SEED"] = pair_seed
        start = datetime.now(timezone.utc).isoformat()
        observation = _evaluation_command(definition[phase], checkout, side_env, definition["timeout"])
        sample = {**_numeric_sample(observation), "side": side, "command": phase, "seed": pair_seed,
                  "start_time": start, "end_time": datetime.now(timezone.utc).isoformat()}
        result["n_runs"] += 1
        return sample, check

    def failed(sample):
        if sample["outcome"] != "measured":
            result.update(outcome="unknown" if sample["side"] == "reference" else sample["outcome"],
                          reason=f"{sample['side']}_{sample['command']}_{sample['outcome']}")
            return True
        return False

    try:
        with ExitStack() as stack:
            contexts = {}
            for side, commit in (("reference", reference), ("candidate", candidate)):
                contexts[side] = stack.enter_context(_evaluation_checkout(goal, spec, commit, dict(env), env_digest, result))
                if contexts[side] is None:
                    return result
            for side in ("reference", "candidate"):
                for phase in phases:
                    sample, check = run(contexts[side], side, phase, f"{seed}:warmup:{side}:{phase}")
                    result["warmups"].append(sample)
                    check()
                    if failed(sample):
                        return result
            for index, order in enumerate(orders):
                pair_seed = f"{seed}:pair:{index}"
                pair = {"index": index + 1, "seed": pair_seed, "order": order,
                        "reference": {}, "candidate": {}, "gains": {}, "relative_gains": {}}
                result["pairs"].append(pair)
                for side in order:
                    for phase in phases:
                        sample, check = run(contexts[side], side, phase, pair_seed)
                        pair[side][phase] = sample
                        readings[side][phase].append(sample)
                        check()
                        if failed(sample):
                            return result
                for phase in phases:
                    ref, cand = (pair[side][phase]["value"] for side in ("reference", "candidate"))
                    if phase == "measure" and positive and (ref <= 0 or cand <= 0) and not (allow_nonpositive_reference and ref <= 0):
                        result.update(outcome="unknown", reason="reference_measure_non_positive" if ref <= 0
                                      else "candidate_measure_non_positive")
                        return result
                    gain = pair_gain(definition, ref, cand)
                    relative_gain = pair_gain(definition, ref, cand, relative=True)
                    pair["gains"][phase], pair["relative_gains"][phase] = gain, relative_gain
                    result["gains"][phase].append(gain)
                    result["relative_gains"][phase].append(relative_gain)
                if after_pair is not None and after_pair(pair):
                    break
    finally:
        if result.get("setup_failed"):
            result.update(outcome="unknown", reason="setup_failed")
        elif result.get("invalid"):
            result.update(outcome="invalid", reason=result["invalid"])
        for side in readings:
            result["medians"][side] = {}
            for phase, samples in readings[side].items():
                values = [s["value"] for s in samples if s["outcome"] == "measured"]
                result["medians"][side][phase] = statistics.median(values) if values else None
        for key in ("gains", "relative_gains"):
            for phase, gains in result[key].items():
                result["median_" + key][phase] = statistics.median(gains) if gains and None not in gains else None
        result["elapsed_seconds"] = time.monotonic() - started
    return result


def check_review(goal: ActiveGoal, spec: str, *, retain: bool = False, allow_failure: bool = False) -> dict | None:
    """Consume a current independent review receipt, never a tool-success proxy.

    Reviewer identity is a declared provenance field, not an authentication token.
    The host/owner must supply the stated input isolation and write authority.
    The final gate retains accepted evidence before recording its result. Reading
    an archive is a separate historical audit, never a missing live receipt fallback.
    """
    contract = verification(spec)
    review = contract["review"]
    if review is None:
        return None
    path = goal.goals_dir.parent / review["path"]
    if not path.is_file() or path.is_symlink():
        raise ValueError(f"Required independent review is missing: {review['path']}")
    receipt_bytes = path.read_bytes()
    receipt = json.loads(receipt_bytes)
    if not isinstance(receipt, dict):
        raise ValueError("Review receipt must be a JSON object.")
    if receipt.get("verifier") not in review["verifiers"]:
        raise ValueError("Review did not name an approved verifier or fallback.")
    session = receipt.get("session_id")
    owners = {goal.owner_session}
    for event in read_events(goal):
        if event.get("event") == "session_binding_requested" and isinstance(event.get("sessions"), list):
            owners.update(s for s in event["sessions"] if isinstance(s, str))
    for commit in goal_commits(goal.goal_path):
        owners.update(commit["fields"].get("writer-session", []))
    if not isinstance(session, str) or not session or session in owners:
        raise ValueError("Review needs a distinct verifier session; the generator or a recorded product writer cannot verify itself.")
    files = snapshot(goal.goals_dir.parent, review["inputs"])
    tree = product_tree(goal.goals_dir.parent) if objective(spec) is not None else None
    if receipt.get("input_digest") != _input_digest(spec, files, tree):
        raise ValueError("Review is stale or refers to different inputs; review the current result.")
    required = {key for key, value in contract["covers"].items() if value == "review"}
    if (not isinstance(receipt.get("covers"), list)
            or any(not isinstance(item, str) for item in receipt["covers"])
            or not required.issubset(receipt["covers"])):
        raise ValueError("Review does not cover the required acceptance IDs.")
    if ((receipt.get("verdict") != "pass" and not allow_failure)
            or not isinstance(receipt.get("verdict"), str) or not receipt["verdict"].strip()
            or not isinstance(receipt.get("evidence"), str) or not receipt["evidence"].strip()):
        raise ValueError("Independent review did not pass with an evidence explanation.")
    checks = receipt.get("checks")
    if not isinstance(checks, dict) or not required.issubset(checks):
        raise ValueError("Review needs a concrete check with input evidence for every required acceptance ID.")
    for key in required:
        check = checks[key]
        if (not isinstance(check, dict) or not isinstance(check.get("claim"), str)
                or not check["claim"].strip() or not isinstance(check.get("evidence"), list)
                or not check["evidence"]):
            raise ValueError(f"Review check {key} needs a claim and nonempty evidence references.")
        for reference in check["evidence"]:
            if (not isinstance(reference, dict) or not isinstance(reference.get("path"), str)
                    or reference["path"] not in files or not isinstance(reference.get("quote"), str)
                    or not reference["quote"].strip()):
                raise ValueError(f"Review check {key} must quote a file in the declared review inputs.")
            try:
                quoted_bytes = (goal.goals_dir.parent / reference["path"]).read_bytes()
                if hashlib.sha256(quoted_bytes).hexdigest() != files[reference["path"]]:
                    raise ValueError("Review inputs changed while checking their quoted evidence.")
                text = quoted_bytes.decode("utf-8")
            except UnicodeError as exc:
                raise ValueError("Review quotes require a text evidence input.") from exc
            if reference["quote"] not in text:
                raise ValueError(f"Review evidence quote is absent from {reference['path']}.")
    # References establish inspectable support, not semantic entailment or identity.
    evidence = {"path": review["path"], "sha256": hashlib.sha256(receipt_bytes).hexdigest(),
                "verifier": receipt["verifier"], "session_id": session, "input_digest": receipt["input_digest"]}
    if tree is not None:
        evidence.update(product_tree=tree, verdict=receipt["verdict"], evidence=receipt["evidence"])
    if retain:
        evidence["archive"] = _retain_review(goal, spec, receipt_bytes, files, evidence)
    return evidence


def _retain_review(goal: ActiveGoal, spec: str, receipt: bytes, files: dict[str, str], evidence: dict) -> dict:
    """Keep the declared review scope outside disposable work, using bounded memory.

    No size policy narrows an approved evidence set. Disk, permissions and hook
    time still bound this local copy; a failed copy must not become a passed gate.
    """
    root = goal.goals_dir.parent
    directory = goal.goals_dir / f"{goal.slug}.reviews"
    relative = directory.relative_to(root)
    if any(Path(raw) == relative or Path(raw) in relative.parents
           for raw in verification(spec)["review"]["inputs"]):
        raise ValueError("Review archive destination overlaps reviewed inputs; an authorized artifact layout is required.")
    retained = {"receipt.json": receipt, "goal.md": spec.encode("utf-8")}
    manifest = {"version": 1, "input_digest": evidence["input_digest"], "files": {
        **{name: hashlib.sha256(content).hexdigest() for name, content in retained.items()},
        **{f"inputs/{name}": digest for name, digest in files.items()},
    }}
    encoded = json.dumps(manifest, sort_keys=True, separators=(",", ":")).encode("utf-8") + b"\n"
    path = directory / f"{hashlib.sha256(encoded).hexdigest()}.zip"
    if directory.is_symlink() or not directory.resolve().is_relative_to(root.resolve()):
        raise ValueError("Review archive destination must stay inside the project without a symlink.")
    directory.mkdir(exist_ok=True)
    for event in read_events(goal):
        previous = event.get("review_evidence")
        if (isinstance(previous, dict) and isinstance(previous.get("archive"), dict)
                and previous["archive"].get("path") == path.relative_to(root).as_posix()):
            read_review_archive(root, previous)
            break
    if not path.exists():
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(dir=directory, prefix=".pending-", delete=False) as handle:
                temporary = Path(handle.name)
                with zipfile.ZipFile(handle, "w", compression=zipfile.ZIP_DEFLATED) as archive:
                    for name, content in {"manifest.json": encoded, **retained}.items():
                        entry = zipfile.ZipInfo(name)
                        entry.compress_type = zipfile.ZIP_DEFLATED
                        archive.writestr(entry, content)
                    for name, expected in files.items():
                        source = root / name
                        if source.is_symlink() or not source.resolve().is_relative_to(root.resolve()):
                            raise ValueError(f"Review input changed to a symlink while retaining evidence: {name}")
                        digest = hashlib.sha256()
                        entry = zipfile.ZipInfo(f"inputs/{name}")
                        entry.compress_type = zipfile.ZIP_DEFLATED
                        with source.open("rb") as incoming, archive.open(entry, "w", force_zip64=True) as outgoing:
                            for chunk in iter(lambda: incoming.read(1 << 20), b""):
                                digest.update(chunk)
                                outgoing.write(chunk)
                        if digest.hexdigest() != expected:
                            raise ValueError(f"Review input changed while retaining evidence: {name}")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, path)
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)
    with path.open("rb") as stream:
        recorded = {"path": path.relative_to(root).as_posix(), "sha256": _stream_digest(stream)}
    # Reuse is checked as strictly as a historical audit; never silently repair
    # or overwrite an altered package already referenced by previous events.
    read_review_archive(root, {**evidence, "archive": recorded})
    return recorded


def read_review_archive(root: Path, evidence: dict) -> dict:
    """Verify a historical package and return its manifest, without extracting it.

    This proves retained byte identity against the event, not current acceptance,
    semantic entailment or authenticated authorship on a shared writable disk.
    """
    reference = evidence.get("archive")
    if not isinstance(reference, dict) or not isinstance(reference.get("sha256"), str):
        raise ValueError("No retained review archive is recorded for this observation.")
    _paths([reference.get("path")])
    path = root / reference["path"]
    if path.is_symlink() or not path.resolve().is_relative_to(root.resolve()):
        raise ValueError("Review archive path must stay inside the project without a symlink.")
    with path.open("rb") as stream:
        if _stream_digest(stream) != reference["sha256"]:
            raise ValueError("Review archive digest mismatch; the retained package changed.")
    try:
        with zipfile.ZipFile(path) as archive:
            encoded = archive.read("manifest.json")
            manifest = json.loads(encoded)
            if (not isinstance(manifest, dict) or manifest.get("version") != 1
                    or not isinstance(manifest.get("files"), dict)
                    or manifest.get("input_digest") != evidence.get("input_digest")
                    or manifest["files"].get("receipt.json") != evidence.get("sha256")
                    or "goal.md" not in manifest["files"]
                    or hashlib.sha256(encoded).hexdigest() != path.stem):
                raise ValueError("Review archive manifest does not match its recorded evidence.")
            names = archive.namelist()
            if len(names) != len(set(names)) or set(names) != {"manifest.json", *manifest["files"]}:
                raise ValueError("Review archive member set does not match its manifest.")
            inputs = {}
            for name, expected in manifest["files"].items():
                if name not in ("receipt.json", "goal.md"):
                    if not name.startswith("inputs/"):
                        raise ValueError("Review archive has an unexpected member path.")
                    _paths([name[len("inputs/"):]])
                    inputs[name[len("inputs/"):]] = expected
                with archive.open(name) as stream:
                    if _stream_digest(stream) != expected:
                        raise ValueError(f"Review archive member digest mismatch: {name}")
            if _input_digest(archive.read("goal.md").decode("utf-8"), inputs, evidence.get("product_tree")) != evidence.get("input_digest"):
                raise ValueError("Review archive inputs and goal do not match the reviewed digest.")
    except (zipfile.BadZipFile, KeyError, UnicodeError) as exc:
        raise ValueError(f"Review archive is unreadable: {exc}") from exc
    return {**reference, "manifest": manifest}
