# Inquiry working draft

<!-- Write in the user's language. Replace these prompts with actual content;
     remove unused sections. Reuse an existing inquiry/task section before creating
     this standalone draft. Preserve borrowed headings and editing boundaries.
     This is a working structure, not a per-turn form. -->

## Current position

<!-- Where applicable, name adopted direction, plan/milestone, accepted terms and
     the current-state record by accessible path/section and source date/revision.
     Omit absent layers. A research branch keeps only its own position here;
     reference the main task's state instead of copying its progress. -->

- Question and purpose: key owner wording and corrections, then current interpretation:
- Scope, intended deliverable, and sufficient outcome:
- Stage: Frame / Clarify / Research / Synthesize / Check / Deliver
- Status: active / waiting_user / waiting_evidence / delivered / paused / ended
- Settled so far and the basis for each:
- Latest material change and its basis:
- Still open: pivotal gaps, pending owner choices, and what would settle each:
- Next action and why it serves the whole inquiry:
- Result path and whether it has been delivered:

## Problem structure and current judgment

Preserve the user's meanings and goals, the focal subject and environment, current
explanations, options, and consequential assumptions. Attribute proposals and open
interpretations. Distinguish desired outcomes and confirmed constraints from examples
and candidate means; repetition does not change their status. Keep current conclusions
distinct from superseded judgments.

## Factors and evidence

| Question or claim | Why it matters | Direct source, date, and locator | Observation and applicability | Support, counterevidence, and gap | Effect on judgment |
| --- | --- | --- | --- | --- | --- |

Separate source inspection by the assistant from verification the user actually
reports. Attach raw material only when needed, with its path and purpose.

## Alternatives, Alpha, and objections

Record useful rival explanations and candidate possibilities. Distinguish personal
novelty, external distinctiveness, and evidential support. Preserve consequential
disagreements and the evidence or conditions that could resolve them.

## Meaningful changes and parked branches

Record the prior judgment, evidence or correction, resulting judgment, and consequence
for the approach or next action. Record
user uptake only from their actual explanation or use. Park a branch with its
useful idea and a reason to reopen; do not retain every conversational turn.

## Delivery or pause

State what exists, what was checked, what remains, and the user's actual instruction
or feedback. Distinguish delivery, acceptance, pause, and early termination.
