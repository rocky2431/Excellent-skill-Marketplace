# One goal contract, any execution shape

Every run owns `.goals/<slug>.goal.md` and its decisions record. A workflow or
delegation file is an optional execution attachment with the same slug. Every
shape uses the same arming, frozen specification, evidence and completion path.
Do not emit a workflow without an installed, exercised consumer; a syntax check
does not establish that `agent()` or `pipeline()` exists in the current host.

## Author and confirm

Resolve repository facts before asking. Interview only material uncertainty, then
read back intent, each acceptance requirement, authority, success and exit
conditions, load-bearing/droppable means and verification obligations. Before
confirmation, attempt a counterexample where every check passes but the owner
would reject the result. Resolve that counterexample or disclose the remaining
uncertainty; a deterministic command cannot prove that its specification is right.

Every owner-facing interview turn shows its position before the one question or
readback, using current files rather than memory:

`Settling: B Execution and evidence · confirmed: 6 · assumed: 2 · open: Verifier, Divergence · next: confirm B`

Confirm content in three checkpoints:

| Checkpoint | Material shown together |
|---|---|
| A Framing | Original owner words and interpreted Intent; Boundary, effects and collaboration scope |
| B Execution and evidence | Every remaining goal section: Anchor and budget, Acceptance and any Objective, Stop condition, Verification, Means, Roles, Carry-over and Handoff; current decisions and execution attachments |
| C Package | The complete current goal, decisions and attachments; Means, Roles, critique dispositions and promised result-and-evidence package |

Checkpoint C is the second confirmation of the whole package. A and B update the
substantive decisions they covered from `agent` to `owner`; they do not add ceremonial
rows. If critique or later drafting changes confirmed A/B material, repeat the
affected checkpoint before C. After the explicit C reply, compute the current frozen
contract digest:

```bash
python3 <skill-dir>/scripts/goal_run.py spec-digest <slug> --root <project>
```

Then add exactly one decision named `Confirm package checkpoint`, with `Who` set to
`owner` and `frozen:<12-hex-digest>` in its Why cell. The validator refuses a missing,
duplicate or digest-less row, and first arm refuses a digest that does not match the current frozen
goal terms. Any covered edit reopens its A/B checkpoint and C; remove the package row
until both confirmations are current. An already-active legacy goal may idempotently resume
without fabricated backfill; its next fresh arm uses the current process.

The row and digest make omission and stale frozen text detectable. They are provenance
in an owner-controlled workspace, not authenticated consent, do not freeze mutable
execution attachments, and cannot prove the criteria are semantically adequate.

Use a native structured question UI when the current host exposes one, with the
readback in ordinary visible prose and the UI only collecting the answer. Otherwise
ask one plain explicit question. The invariant is shown material plus an explicit
reply, not a vendor-specific UI.

During Init, probe only an unknown that could change a material goal decision and
stop once it is resolved. Testing whether an existing entry point starts is a
feasibility check; completing the deliverable before the readback is execution.
Do not turn exploration into an unconfirmed implementation project.

Separate the desired outcome, explicitly required constraints, examples and proposed
means before drafting acceptance. For a consequential proposal, explain what evidence
or owner choice supports it and the premise connecting it to the outcome. Distinguish
necessity from conditional usefulness. A plausible satisfactory result without the
means challenges necessity; it does not override an owner's explicit requirement.
Apply this to the agent's own proposals. Repetition, confidence and agreement without
a substantive decision do not promote them into owner terms.

A counterexample must identify an unmet part of the owner's actual intent.
Manual production of a correct one-off result is not a counterexample unless
repeatability is required. Do not promote a preferred method, reproducible
pipeline, extra report or architecture standard into acceptance by yourself.
Likewise, a checker proving that a report exists does not prove it is readable.
Reuse explicit owner answers; ask again only when new evidence invalidates them.

Preserve the owner's material words and clarifications verbatim in `## Intent`,
with a conversation/source locator when available, separately from the operational
interpretation. Do not invent a quotation or treat an agent summary as the source.
Show a draft to an independent reviewer before offering unattended execution,
when specification adequacy is unresolved, or when the owner requires it. The
reviewer compares each acceptance item with those original words, tries a concrete
all-green-but-unsatisfactory result and a satisfactory result the checks would
wrongly reject. Resolve material objections in the existing decisions record
before confirmation; no new ledger or numeric confidence vote is needed.
If the owner says to start before checkpoint C, perform the independent critique
against the draft, resolve material objections, then show the resulting current
package. One explicit reply may both confirm C and authorize start; an earlier start
request cannot approve material that had not yet been shown.
An explicit owner waiver or an unavailable independent context must be disclosed
as a limit, never inferred from "start now" or recorded as a passing critique.
The reviewer needs the original owner request as well as the draft and evidence,
not just the author's rationale. Confirmation approves
the complete contract, not a blank authorization to invent weaker criteria later.

Keep material qualifications and example/proposal status when consuming a research
handoff; an earlier Skill's summary is not fresh evidence or additional authority.
On a consequential challenge, record the previous judgment, inspected evidence or
correction, resulting judgment and execution consequence in the existing decisions
record. An unresolved fact stays unresolved; retain a supported view when the challenge
does not defeat it. This does not permit editing frozen terms: use the existing
owner-approved modification path when those terms need to change.

These inference and revision checks adapt [Academic Research Skills' argumentation](https://github.com/imbad0202/academic-research-skills/blob/c7af8b9017954c745ed7ad4afed4dba460a6c247/deep-research/references/argumentation_reasoning_framework.md)
and [Socratic questioning](https://github.com/imbad0202/academic-research-skills/blob/c7af8b9017954c745ed7ad4afed4dba460a6c247/deep-research/references/socratic_questioning_framework.md)
(inspected 2026-09-11). They guide semantic judgment; no claim of measured improvement
or deterministic intent alignment follows from these instructions.

## Required machine contract

Every acceptance bullet has a stable ID. IDs are case-sensitive, beginning with a letter
and continuing with letters, digits, `_` or `-` (for example `A1` or `import-total`).
Preserve upstream IDs exactly in both Acceptance and `covers`; never lowercase them
or silently replace them during handoff. The text is frozen; `[ ]`/`[x]` are
mutable claims. A claim never supplies completion evidence.

````markdown
## Acceptance

- [ ] audit: No high-severity dependency advisories remain.
- [ ] build: Existing product acceptance checks and build pass.

## Stop condition

success: verified
ceiling: 6

## Anchor

```sh
pnpm audit --audit-level=high && pnpm test -- --run && pnpm build
```
````

`success: verified` means the current anchor is green and every required review
has passed on the current declared inputs. Thresholds belong in those checks.
The ceiling counts completion attempts, not tool calls, host turns, tokens or
money. Configure native budgets for those resources during setup; exhausting any
budget ends or pauses unverified, never successfully. `ceiling: none` is explicit.
Size the work against the actual native time/token/spend limits and observed tool
latency. Leave room within the approved budget for required review, verification
and delivery; an optional critic must not consume the only remaining opportunity
to close the goal. There is no universal reserved percentage or extra allowance.

`## Verification` contains exactly one JSON block with these fields:

```json
{
  "source": "owner-approved",
  "basis": "Owner accepted the independently inspected acceptance program and fixtures.",
  "protected": ["verification/acceptance.py", "verification/cases.json"],
  "covers": {"audit": "anchor", "build": "anchor"},
  "review": null
}
```

- `source`: `owner-approved` for an accepted evaluator definition or `external`
  for an authoritative external evidence source. Neither means self-review.
- `basis`: the concrete provenance and what the owner accepted. This is a
  declaration to inspect during confirmation, not an authenticated credential.
- `protected`: explicit project-relative evaluator files/directories. Pin the
  acceptance logic, fixtures and configuration it depends on, including indirect
  scripts. Arming records hashes in `<slug>.verification.baseline`; changes or
  missing inputs refuse verification. Untracked files anywhere under a `__pycache__/`
  folder inside a protected directory or beside a protected module are not hashed: every
  run rewrites them, so the gate deletes them before each evaluator it runs - in place,
  in a checkout and in linked Objective inputs - and the in-place anchor also gets a
  fresh `PYTHONPYCACHEPREFIX`. Every file there counts, whatever its name: a
  case-insensitive disk can open a differently spelled file when Python asks for its
  cache, and its folding rules are not Python's. Nothing is hashed or deleted through a
  symlink; any symlink, dangling or not, in a
  protected path or its cache directory refuses verification. Whether a cache is tracked
  is asked of the repository that holds it, comparing names after normalization and case
  folding, so a nested repository answers for its own files and a folder renamed in case
  cannot hide one; a Git failure refuses instead of counting files as untracked. An evaluator
  command that sets its own cache location (`-X pycache_prefix`, `PYTHONPYCACHEPREFIX`)
  fails validation, and an anchor armed before that check refuses when it runs; this
  catches a misconfigured command, not one written to hide the setting. Tracked bytecode stays protected against changes, and optimization mode also
  refuses its removal. Every other file stays strict, including ignored ones and a
  sourceless `.pyc` beside a script, which can shadow a module. These rules cover the cache paths the gate controls, not an evaluator that
  loads code from elsewhere the run can write. Do not protect the implementation being
  improved. External evidence may have no local evaluator inputs; declare that
  weaker local coverage honestly. All local definitions still need protection.
- `covers`: every acceptance ID maps exactly once to `anchor` or `review`. This
  checks declared coverage, not the semantic adequacy of the mapping.
- `review`: `null` when the accepted anchor fully covers the requirements, or
  the required independent review contract below. Additional advisory review is
  free to vary; a required review cannot be silently made optional.

An anchor is observational and must check the current requested result end to
end. It must not modify protected definitions or the reviewed product. Runtime
dependencies and external services can drift: either bind the relevant identity
in the evaluator or name the limit. A copied command string is not a pinned
evaluator. Generate project-specific checks only after settling the criteria;
allow independent inspection before the owner approves them.

## Required independent review

When semantic acceptance needs independent judgment, replace `review: null`:

```json
{
  "path": ".goals/demo.review.json",
  "verifiers": ["claude-reviewer", "kimi-reviewer"],
  "inputs": ["src", "report.md"]
}
```

The list authorizes equivalent verifier identities/fallbacks; it does not
authorize the generator to review itself. The independent verifier reads the
criteria and actual bounded inputs, obtains its own native session identity,
and computes a digest binding the frozen goal terms and current input files with:

```sh
python3 /installed/skill/scripts/goal_run.py review-inputs demo --root /project
```

Resolve the actual installed script path and project root. The verifier writes
the configured JSON receipt itself, alongside any detailed human-readable review:

```json
{
  "verifier": "claude-reviewer",
  "session_id": "actual-independent-native-session-id",
  "input_digest": "the SHA-256 returned by review-inputs",
  "covers": ["semantic-requirement-id"],
  "verdict": "pass",
  "evidence": "Checks performed, observations and remaining limits.",
  "checks": {
    "semantic-requirement-id": {
      "claim": "The report's material conclusion agrees with the original evidence.",
      "evidence": [{"path": "report.md", "quote": "An exact excerpt read from this input"}]
    }
  }
}
```

Use a non-pass verdict when unresolved findings remain. Do not manufacture a
passing receipt for a missing review. The completion gate checks the approved
identity, a session distinct from every recorded bound execution session, current
input digest, required IDs, passing verdict and an evidence-backed `checks` entry
for each requirement assigned to review. Each entry has a concrete `claim` and
nonempty `evidence` references; every `path` must be a file under `review.inputs`
and each `quote` must occur there verbatim. For a report, include both the claimed
result and the original supporting evidence in the review inputs, then check all
material factual statements and limitations, not merely presence or readability.
Quotes provide inspectable references; matching text does not prove the claim
follows from it. The reviewer must establish that relationship independently.
The generator must wait for invoked writers before requesting review
and must request a new review after changing those inputs.

Keep required receipts outside disposable `.work/` by default. After the current
anchor and review checks pass, the gate retains an archive of the exact receipt,
goal and all declared `review.inputs` in `.goals/<slug>.reviews/<digest>.zip`.
The event records its path and SHA-256; inability to retain the evidence refuses
completion. The archive survives scratch cleanup and supports later integrity
audit. It never replaces a current receipt, authenticates the author, or includes
undeclared upstream facts automatically. Choose the evidence location and any
commit/publication with the task's existing data and authority boundaries.

This is provenance checking in an owner-controlled environment, not identity
authentication. A process that can rewrite every file can forge receipts and
baselines. Use native permissions, isolated verifier workspaces or authenticated
external receipts when the task requires stronger protection. An older receipt must be regenerated when upgrading to this contract-bound digest
and per-requirement evidence format. If the needed
boundary cannot be established, disclose that before offering unattended work.

## Evidence counterexamples

Use these when the corresponding risk is present in the goal; they are checks on
the criteria and verifier, not new requirements for the business result:

- **All green, wrong intent:** a checker verifies that a report exists while the
  material conclusion is unsupported; a correct row count hides the wrong people.
  Compare the result with original source facts and the owner's words.
- **Correct result, wrong rejection:** a one-off output satisfies every outcome
  through an authorized alternative method, but the checks demand the initial
  droppable tool. Remove that extra method requirement before freezing the goal.
- **Protected entrypoint, unprotected dependency:** change a helper or fixture
  the checker imports. If a bad product can pass, include the relevant dependency
  in the existing `protected`/`basis` contract, or disclose the remaining coverage.
- **True quote, false conclusion:** the cited sentence occurs in the input but
  contradicts the reviewer's conclusion, omits a qualifier or refers to another
  population. Exact quotation matching is necessary provenance, not entailment.
- **Unchanged file, expired fact:** a remote result or environment identity has
  changed while local hashes still match. Record the source identity, observation
  time and validity condition; re-observe when the condition no longer holds.

Calibrate semantic reviewers on independently settled good and bad examples where
this judgment is load-bearing. Keep the evaluator blind to the generator's defense
and compare against actual source facts, computation or a user-visible path.
Record false acceptance and false rejection; agreement among reviewers is not a
substitute for that independent reference. A missing calibration run is a limit,
not evidence of passing one.

## Ambition, floor and objective

The ambition readback looks above and beneath the request without replacing it.
**Altitude** asks what the deliverable is for and what the run needs to pursue that
outcome directly: fixing one crash versus keeping a release crash-free needs crash
reports, a version-to-commit map and machines that reproduce failures. **Depth** asks
four questions before rewriting anything: what a leading practitioner would do that
the request omits; the rawest material they would start from instead of a digested
summary; the methods and instruments they would actually use; and what other than the
generator or the owner would show the result is right. **Range** restates the
deliverable as verbs and names fields whose methods apply. Asking for an expert's
voice changes wording, not method; record the method.

Every proposal names its judge. The owner needs to understand the judge, not the
solution: a held-out set the generator never sees, a backtest showing the new method
would have caught past cases earlier, a side-by-side run against the current method,
reproduction of a believed cause from raw data, or an external tool's measurement.
Settle the judge and protect its definitions and data before the run generates
anything; a result the owner cannot inspect can otherwise be fitted to its check.

An adopted ambitious target splits in two. The **floor** is ordinary Acceptance: it
decides `success: verified`, and in optimization mode every kept state must pass it
too. The **objective** is the quantity pushed past the floor, declared in
`## Objective` with an owner-frozen measure; its `target:` is the stretch value,
reported and never required. If missing a value should fail the goal, it is a floor.
A one-shot goal with a measurable target uses the same section with a small budget.

The readback adapts one practitioner's reported method; see
[research basis](research-basis.md#ambition-and-long-horizon-optimization) for its
evidence limits and for the optimization precedents below.

## Optimization mode

Use it when the result is a measurable quantity worth improving over many rounds.
The owner defines what counts and freezes the judge; the run searches; the gate
evaluates every committed experiment in a clean checkout and keeps only what it
measured as better. A goal is in optimization mode exactly when it has an
`## Objective` section:

````markdown
## Objective

Lower p95 latency of the checkout API on the protected load fixture.

measure: `python3 verification/perf.py --metric p95_ms`
direction: lower
margin: 2%
samples: 3
measures: 300
plateau: 15
audit: 10
target: 200
holdout: `python3 verification/perf.py --metric p95_ms --fixture sealed`
transfer: 70%
frontier: 180 ms p95, Example Corp engineering blog (2026-08-02), comparable fixture class, not reproduced here
````

One field per line. Prose lines are allowed but should not begin with `word:`;
an unknown field is reported as an advisory so a misspelled one is not silently lost.

- `measure:` (required) one observational command, run from the root of a clean
  checkout of the commit being judged. Its last non-empty stdout line is a single
  number; anything else, a nonzero exit or a timeout is not a reading. Every project
  file it runs must be in `protected`: a script path outside it is an error even
  before the file exists, every evaluation rechecks the command in its checkout, and
  a runner defined by product files, such as `npm run` or `make`, is an advisory.
- `direction:` (required) `higher` or `lower`.
- `margin:` (required) the median paired gain a keep must strictly exceed: an
  absolute improvement or a percentage relative to each pair's reference reading.
  Set it to the smallest improvement worth keeping. With independent pairs the
  7-of-8 rule, not the margin, bounds keeps of unchanged candidates, so do not
  inflate the margin to cover single-run noise: a margin far above the per-pair
  noise discards real gains that win most of their pairs. The per-pair noise is the
  spread of pair gains between two runs of the same version; estimate it by running
  one version in alternating pairs. When the two runs of a pair are independent it
  is about 1.4 times the spread of single runs (for a percentage margin, while that
  spread is small relative to the reading); inputs shared through the pair seed make
  it smaller. When the evaluator may carry state between runs (warming caches, JIT,
  reused files), pairs are correlated and the margin is the only buffer: reset that
  state for every run, or keep the margin at roughly twice the per-pair noise or more.
  Percentage keep comparisons require positive measure readings on both sides.
  Check the reference first: zero or less records retryable `unknown` with reason
  `reference_measure_non_positive`; otherwise a non-positive candidate records
  `candidate_measure_non_positive`. The candidate-side reason spends budget; the
  reference-side reason follows the free-once rule below. An incumbent whose reported
  value (the median of all its readings) is zero or less refuses new candidates before
  evaluation: stop and raise a challenge so the owner can re-author the goal with an
  absolute margin. A single non-positive sample does not refuse candidates when
  that median is positive.
  The baseline's noise advisory, `margin_below_noise`, marks a margin no larger than
  twice the approximate standard error of the difference between two medians of
  that many runs, estimated from the baseline samples' standard deviation; it
  shrinks as `samples` grows, and one outlier sample inflates it. It is reported for
  the owner and does not decide keeps.
- `samples:` the number of baseline runs, also used for incumbent remeasurement
  (default 3; fewer than two leaves baseline noise unmeasured). Keeps always use at
  most 8 pairs; audits and replay use `max(2 * samples, 10)` pairs.
- `screen:` an optional fast subset of the floors, one backticked command, run first in
  every `measure` call (baseline and re-measures included) with the anchor's budget; a
  candidate failing it is discarded without measuring. Audit, replay and completion do
  not run it.
- `timeout:` per-sample limit such as `10 minutes` (default 10 minutes).
- `measures:` (required) the experiment budget in candidate evaluations, not host
  turns or completion attempts; `none` leaves only native budgets.
- `plateau:` consecutive candidates without a keep after which the run must change
  strategy class; while the plateau lasts, `measure` refuses a candidate whose class
  matches the most recently evaluated candidate's.
- `audit:` (required) kept improvements between independent audits.
- `audit_failures:` how many failed audits close the search (default 2; `1` closes at
  the first). Each earlier failure rolls back and the search continues. Failures
  accumulate over the whole search; a passing audit does not reset the count.
- `target:` the stretch value. Reaching it is reported, never required. The current
  incumbent's latest passing paired audit supplies its measure median; after a keep
  or rollback, or without such an audit, `target_reached` is false. A keep whose own
  window readings beat the target says so in `next` and suggests an audit.
- `holdout:` the same metric measured on data no keep decision uses: `samples`
  baseline runs, then both sides of every audit and replay pair. Its mechanical
  protection rests on fresh inputs per pair, used once by each side, generated from
  the same distribution or held where the run cannot read them. Warm-ups use separate
  inputs. Use `ULTRAGOAL_PAIR_SEED` to generate matching inputs within each pair. A stored file read in several
  timed passes lets a plain input cache improve the holdout as much as the measure; a
  stored file the run can read can be targeted directly. With either, the transfer and
  regression rules no longer catch gains confined to known inputs, and review becomes
  the main line - settle which in the interview.
- `transfer:` (required with `holdout:`) the share of the objective's relative gain
  over the baseline that the holdout must also show, as `N%`. Gains confined to the
  measure's own data - a cache keyed by its inputs, embedded answers - leave the
  holdout flat; only this rule catches them mechanically. At `70%`, up to 30% of a
  reported gain can still be confined to the measure's data.
- `inputs:` project-relative paths the evaluators need that Git does not track, such
  as datasets. They are linked into each evaluation checkout and must be `protected`.
- `frontier:` a named external result with source, date and conditions, reported
  beside the incumbent. It is not something the run measured.

Optimization mode requires Git with the protected evaluator files committed (arming
refuses otherwise), host write access to the repository's `.git` for commits and
evaluation worktrees (some sandboxes keep it read-only by default), authority to
commit candidates and to discard the run's own unkept commits on the goal's branch,
and a required review contract.
Guardrails - what the objective could be bought with - are Acceptance floors that the
anchor checks, so the anchor gates every kept state. During the interview, name the
cheapest exploit of the measure and show which floor, holdout or review requirement
catches it. Include a review-covered requirement that the improvement comes from
changes serving the intent rather than from exploiting the measure.

### Evaluate in a clean checkout

Every evaluation runs in a clean detached worktree outside the project, removed
on every outcome, with a fresh temporary directory, its own `PYTHONPYCACHEPREFIX`,
an empty hooks directory and the environment recorded when the goal was armed
(`.goals/<slug>.objective-env.json`). Protected files are checked in
that checkout against the armed baseline before anything runs. Nothing the run
leaves in its own work tree - ignored caches, uncommitted edits, a different
interpreter on its `PATH` - reaches the judge, except linked `inputs:`, which stay
protected and have their caches cleaned before each command. The checkout runs none of
the repository's hooks; every reading can be reproduced from a clean checkout of its
commit under the same local Git configuration.

A paired window prepares the reference and candidate checkouts once each and reuses
those two checkouts throughout the window. Each declared command runs once per side
as a warm-up, recorded but excluded from all decisions. Each two-pair block randomly
chooses reference-first then candidate-first, or the reverse; a trailing odd pair
has a random order. The per-call order seed is recorded. Every pair gives both sides
the same `ULTRAGOAL_PAIR_SEED`; seeds differ between pairs and from all warm-ups.
An evaluator generating inputs should initialize a local random generator from this
string and generate the same workload on both sides, without incorporating the side,
commit, wall clock or process ID. Measure and holdout should use distinct generator
namespaces so holdout data stays separate. Both checkouts retain cache purges before
every command and frozen-term, environment and protection checks after every run.
Every run records its side, command, start/end time, exit code, last stdout line,
value and outcome. Reference-side crashes or timeouts make the comparison retryable
`unknown`; candidate-side failures retain the ordinary candidate outcomes.

Evaluators must load the product from the checkout they run in. An editable install or
an activated environment that points at the main work tree makes a clean checkout
measure the main tree's code: `measure` and `audit` then look right only because the
main tree holds the same commit, and replay compares one version with itself. Put the
checkout first on the import path (for Python, `PYTHONPATH=src` or `python -m` from the
checkout root) or build the environment inside the checkout (`uv run` there). Every
audit and replay checks this: a baseline checkout that reads like the incumbent is
reported as not isolated, refuses the audit or invalidates the replay, and is never
counted as a failed audit or a falsified gain. A changed measuring environment, such
as a slower machine, reads the same way, so the report names both causes.

### Measure, keep or discard

```sh
python3 <skill-dir>/scripts/goal_run.py measure <slug> --root <project> --session-id <current-native-session-id> --strategy <class> --hypothesis "<predicted effect>"
```

The run commits a candidate, names its strategy class and predicted effect, then
calls `measure`. It refuses unless the bound session calls it, the frozen terms and
protected files are unchanged, the work tree outside `.goals/` is clean, budget
remains, no audit is due, the search is open and this product tree was not already
judged. The first measurement must be the arming revision: it is the baseline, with
the holdout measured beside it when declared. For a candidate the `screen` runs first when
declared, then a paired window against the incumbent, with at most 8 pairs. The full
floors run only for the baseline and for a candidate that clears the paired keep rule,
after that decision. Red floors discard the candidate; floors that time out or cannot
run record `unknown`, which may be retried, and the arming revision may be measured
again until it yields a baseline. Evaluations use the anchor's declared `budget:`; only
the Stop hook path caps it at the hook's limit. The first failing measurement sample
ends the evaluation as `crash`
(nonzero exit or no number) or `unknown` (timeout), and such a tree may be tried
again. A checkout the host will not prepare records `unknown` with reason
`setup_failed` and spends no budget; an input that breaks the contract or a protection
mismatch found in the checkout stays `invalid`.
An incumbent-side failure records retryable `unknown` with a `reference_...` reason;
only the first such event per candidate product tree spends no budget. Every later
such event for the same tree spends budget like any other `unknown`, including when
the evaluator loads a crashing candidate from outside its checkout and the reference
warm-up fails first. Remeasure the incumbent; if it passes alone, check for a shared
product path such as an editable install. Setup failures remain free on every attempt.

A pair wins only when its gain is strictly positive; a tie is a loss. Stop at the
second loss and discard with `not_better`. After 8 pairs, keep only with at least
7 wins and a median pair gain strictly above the margin. Otherwise discard with
`below_margin` for 7 or more wins, or `not_better`. For a lower-is-better percentage
metric the gain is `1 - candidate/reference`; for higher it is
`candidate/reference - 1`. Absolute margins use the difference toward improvement.
`best_value` is retained for reporting and never decides a keep.
The incumbent's reported value is the median of all its individual samples;
measuring the incumbent again adds a reading, is exempt from the
already-judged rule and spends no budget unless it is `invalid`. The baseline
evaluation spends budget like any candidate.

A candidate discarded with `not_better` or `below_margin` records the advisory
`isolation_hint: true` when the incumbent side's window median differs from the
incumbent's recorded value by more than the margin and lies closer to the candidate's
window median than to that recorded value. Either the evaluator loads the product from
outside its checkout, for example an editable install, so both sides run the same code,
or the machine's speed changed; `next` names both and asks the run to check before
continuing. A keep never carries the hint, nor does a discard whose sides read further
apart than the incumbent moved, since the checkouts then plainly run different code;
the hint never changes a verdict.

Every call appends one gate-written `objective_measured` event: index, commit,
product tree, strategy, hypothesis, floor outcome, samples, median, prior incumbent,
margin, environment digest, verdict (`baseline`, `keep`, `discard`, `crash`,
`unknown`, `remeasured` or `invalid`) and counters. Paired candidate events add
`decision_rule: "paired-v1"`, all pairs and warm-ups, their order, times and seeds,
wins/losses, median pair gain, incumbent window samples and median, order seed,
run count and elapsed seconds. The existing `samples` and `median` fields describe
the candidate's paired readings. These events are the experiment
ledger; the incumbent, budget, plateau and audit counts derive from it, never from
run-written files. The command prints the same facts as JSON and exits 0 when it
recorded an evaluation, whatever its verdict; read `verdict` for the outcome. A change to the frozen terms or protected files during an
evaluation makes the verdict `invalid`: it exits 1, keeps the incumbent and spends
budget; so does a candidate whose compiled Python files - bytecode or extension
modules - differ from the arming revision, since they can be neither reviewed nor
protected. One inside the cache folder beside a protected module is also a protected
change, which `measure` refuses and records before evaluating anything. Lessons cite ledger indexes; a lesson without one is a claim.

### Audit, failure and rollback

When kept improvements since the last passing audit reach `audit`, `measure` refuses
new candidates until the incumbent is audited:

```sh
python3 <skill-dir>/scripts/goal_run.py audit <slug> --root <project> --session-id <current-native-session-id>
```

`audit` requires the work tree to be the incumbent. In optimization mode the review
receipt's input digest also binds the incumbent's product tree, so a receipt for any
other state is stale. A non-passing receipt records `objective_audit_failed`. A
passing one is followed by a single paired window of baseline and incumbent:
`max(2 * samples, 10)` pairs, running measure and, when declared, holdout on both
sides. Regression compares the median per-pair holdout gain with minus the margin:
relative gains for a percentage margin, differences for an absolute one. With a
percentage margin, the threshold is `margin / 100` whenever every reference reading
in that phase is nonzero, even when their median is zero. Transfer
uses `G_m` and `G_h`, the medians of the per-pair relative gains, each normalized by
its reference's absolute value: when `G_m` exceeds `margin / 100` for a percentage
margin, or the absolute margin divided by the absolute baseline-window median for
an absolute margin, `G_h < transfer * G_m` fails transfer. A zero reference reading
leaves that phase's relative median undefined: regression then uses the median
per-pair difference against the absolute margin (for a percentage margin,
`margin * abs(reference median) / 100`). Transfer is omitted when either relative
median is undefined, or the absolute-margin normalization is undefined. Holdout
readings may be zero or negative. Choose an absolute margin when holdout readings
can approach zero, since relative gains near zero can raise false regression alarms. A
regression or transfer failure records `objective_drift_alarm`; otherwise
`objective_audited`. Baseline-side
window medians drive the existing isolation checks for both measure and holdout;
failure records `objective_isolation_failed`, refuses the audit and leaves it due.
Audit and drift-alarm events carry the pairs, medians, gains, seed, warm-ups and
incumbent measure median. Failed windows remain retryable and consume no audit-failure
allowance.

A failed audit voids the keeps since the last passing audit: the incumbent rolls back
to that state, or the baseline, and the search continues from it; the voided trees may
be judged again, starting a fresh sample history, while the voided keeps stay in the
ledger and keep their budget. Reaching `audit_failures` failed audits, or any drift alarm, closes the
search instead. Either way the ledger selects the rolled-back incumbent; restore the
commit `audit` prints. After closure `measure` refuses every call, re-measures included,
giving the closure reason first; completion is allowed only on the rolled-back state,
with the failures or alarm reported; reopening the search is the owner's decision under
a new goal. `audit` prints pass, failure or alarm without holdout readings, which stay
in the ledger for the owner.

A run that continues after a failed audit has seen why the reviewer objected. Treat the
objection as a reason to change approach, never as an obstacle to route around:
removing a behavior and teaching its concealment look identical from outside. Where one
second chance is too costly, the owner sets `audit_failures: 1`.

Give the auditor the original owner words, the frozen goal, `goal_run.py diff` from the
arming baseline to the incumbent and the ledger summary from status, never the run's
argument for its changes. Prefer a model family other than the generator's.
The auditor judges the change itself: whether it serves the intent for any input of
the measured kind, without recognizing, storing or precomputing particular inputs or
results. A change the auditor cannot read - compiled or generated code without its
source - fails, and so does one that alters how the evaluator runs, such as product
code that replaces a timer, a standard-library function or one of the evaluator's
imports: the gate sees neither. The holdout is the gate's mechanical check after a
passing receipt; asking the auditor for holdout evidence it cannot yet see fails sound
changes for an ordering reason.

### Finalize and replay

Stop searching when the target is reached and the holdout agrees, the budget is spent,
the plateau persists across different strategy classes, or the search closes. Restore
the incumbent, obtain the final review, run `audit`, then `replay`, then `verify`.
After the search closes, `audit` is refused and not needed: the rolled-back state was
audited already or is the baseline. Obtain the final review, `replay` unless it is the
baseline, then `verify`:

```sh
python3 <skill-dir>/scripts/goal_run.py replay <slug> --root <project>
```

`replay` uses one randomized balanced window of `max(2 * samples, 10)` pairs,
measuring both baseline and incumbent, including holdout when declared, without
screen or floors. It reproduces when the median per-pair measure gain strictly
exceeds the margin in its units: relative gains for a percentage margin, differences
for an absolute one. The percentage threshold is `margin / 100` whenever every
reference measure reading is nonzero, independent of their median. Only an undefined
relative median falls back to median per-pair measure differences against
`margin * abs(reference median) / 100` for a percentage margin.
When the recorded baseline is zero or negative, as in a goal with keeps made under
2.21, audit and replay allow non-positive reference measure readings, including a
non-positive candidate paired with them. Relative medians still apply when defined.
With a zero reference reading, replay judges measure differences; the audit checks
holdout regression and skips transfer when either relative median is undefined.
Other non-positive measure readings under a percentage margin make the window
unknown and retryable, without closure, with the side-specific reasons above.
Holdout readings have no positivity requirement.
Existing event fields remain, with the complete window added. A baseline incumbent has no gain to
replay, so its replay is refused. It binds only when the main work tree
is clean at the incumbent from start to end; otherwise it is recorded for information,
changes no state and cannot satisfy completion. When the ledger
separates baseline and incumbent by more than the margin, in either direction, a
baseline checkout that reads closer to the incumbent's value
(the median of all its samples) than to the baseline's, equal distances included, or
whose holdout reads closer to the incumbent's audited holdout, means the readings no
longer separate the two versions - the evaluator is not isolated, or the measuring
environment changed: that replay is invalid, never a falsification. An incumbent checkout that reads like the baseline is the falsification. Completion requires the work tree to be the incumbent with a
passing audit and a replay after its last keep (the baseline needs neither, though the
final review is still required); the final floors run in a clean checkout. Deliver the best measured state, not the last one
tried, with the replay result and this command, which the owner can run at any time
without the run's session. A replay that does not reproduce the claimed gain is
reported, not hidden. A valid replay with `reproduces: false` has falsified that gain: it
closes the search with reason `replay` and rolls back to the audited state before that
incumbent, or the baseline, which then needs its own replay unless it is the baseline.
A replay with failed or invalid readings satisfies nothing; run it again.

### Threat model and limits

With independent pairs, a no-change candidate is kept at most `9/256` (about 3.5%)
of the time, whatever the noise shape; the median margin can reduce this further.
Such a keep does not make the result worse, and replay checks the median per-pair measure gain. A
slower candidate is practically never kept in the design's simulations. These
claims assume independent pairs: a version with its own slow drift, such as a cache
it warms run after run, correlates the pairs and raises false keeps. Balanced order
reduces order bias; it cannot remove correlation, thermal effects or all load drift.

Audit false alarms are the price of catching gains confined to the measure's data.
The design's simulations give transfer-alarm rates of 4–10% when measure and holdout
are both truly 7.5% better, 1–4% at 10%, and at most 0.3% at 15%. These are simulation
figures, not a universal noise-model guarantee. A clearly slower candidate costs
about 7 evaluator runs, no change about 10, and a keep 18, plus the screen when
declared and floors for would-be keeps. With holdout, an audit or replay costs four
warm-up command runs plus four runs per pair.

Goals armed under 2.21 continue without re-arming: their Objective fields, frozen
digests and confirmations are unchanged, and recorded events keep their contents.
New comparisons use `paired-v1`, and the current rules apply when old events are
projected: `target_reached` needs a passing audit window over the current incumbent,
and the budget exemptions above apply. A percentage-margin goal whose incumbent has
a non-positive reported median, which 2.21 compared through normalized gains, now refuses
candidates until the owner re-authors it with an absolute margin.

This mode protects the judge from what optimization pressure stumbles into: noise
ratcheting into progress, caches and side effects outside the commit, a changed
environment, gains confined to the measure's data, and lost progress. It cannot
prevent a run that deliberately subverts the gate, and detects only part of it. The
gate runs in the run's own process tree and files: it notices changed protected files,
changed frozen terms and the compiled files it inspects, but not product code that
patches the evaluator while it runs, scripts or a ledger rewritten in place,
user-level interpreter configuration, or local Git settings in `.git/` such as checkout
filters, which still apply when an evaluation checks out a commit. Review of the diff is the defense for what the
diff shows. Only an evaluator outside the run's process tree - another account,
machine or service - closes the rest; settle in the interview whether the goal needs
one. A holdout the run or the product under test
can read is not sealed. The ledger, holdout readings included, is readable by the run.
A run that discards a failing receipt before calling `audit` can shop for a passing
review. State under the recorded home directory persists between evaluations. A
frontier comparison is only as comparable as its stated conditions.

### Older UltraGoal on the same machine

Every host's installed UltraGoal runs its own hooks, and a marketplace update does not
update them all at once. An older Stop hook reads `<slug>.spec.baseline` with its own
digest, which knows nothing of `## Objective`; a baseline that included the Objective
would look changed to it and close the run at the first turn end, as both validation runs
recorded after their final verification. That baseline therefore keeps the digest
without the Objective, a separate `<slug>.objective.baseline` holds the full digest this
version checks, and the owner's package confirmation covers the full digest. A missing
or invalid Objective baseline, or an Objective removed or emptied after arming, is a
frozen-terms change, and re-arming or rebinding never backfills that baseline. An older
hook then neither closes an optimization goal nor enforces its rules: update UltraGoal on
every host that may end a turn in the project before relying on them.

## Autonomy and recovery

Frozen: intent, boundary, full success/exit contract, verification obligations,
acceptance requirement text, the objective and complete labelled means declarations. Changing
these needs owner authority and a new goal. A decisions row records an action;
it cannot grant authority to lower acceptance or enlarge resource limits.

Within those terms the model chooses strategy, ordering, tools, workers, plans
and execution shape. It may drop a droppable means or use a pre-authorized
verifier fallback, recording the evidence in decisions. Carry-over/State/Lessons/
Next are freely rewritten. Expose a genuinely impossible term through Challenges;
do not relabel it or pretend budget exhaustion is success.

Every compiled goal includes compact `## Carry-over` with State, Lessons and Next,
even when started only once. Read it before acting and rewrite it before finishing
or a known context transition; link to current evidence and unfinished work. Cadence
only specifies repeated scheduling. Recovery does not renew authority or budgets.
Compaction may retain a summary; it does not guarantee that every necessary fact
survives. Reconcile Carry-over against the named inputs, host state and current
observations before relying on it. Compactness is advisory: keep a necessary
fourth lesson rather than discarding evidence to satisfy a bullet count.

A failed delegation is a transport observation. It stays in the audit even if
a fallback succeeds. Required output/review evidence decides completion; the
original target need not recover. Call success is neither a join nor a review.
Silence or a lost reply is unconfirmed, not `input-required`. Read the native
task/receipt state: a worker may still be running or may already have finished.
Use `input-required` only for a concrete unanswered question or an explicit native
waiting-for-input state. Unavailable status is an unknown observation; name its
readback/retry condition instead of inventing a question for the owner.

Separate artifacts do not isolate shared products. For parallel writers, name
their actual files/resources, shared interfaces and integration owner in the
existing mission. Reuse available worktrees or scratch isolation where appropriate;
join and validate the integrated state before review and a completion claim.

Arming and rebind record requested execution-session bindings before activation.
Previous bound sessions remain excluded from required review after recovery. These
checks also exclude `Writer-Session` identities declared in this goal's commits
since arming. An unreadable recorded Git range refuses the review rather than
silently losing that evidence; no Git baseline means this additional source is
unavailable. These declarations do not discover every delegated writer: the caller must also keep a worker
that authored the result out of its independent review. A recorded frozen-contract
closure cannot be undone by ordinary re-arming, even after restoring the original
text. Each observed closure is audited; it consumes an attempt only if a completion
candidate was present. Use a newly authorized goal to pursue revised terms.

## Recovery after an unknown external effect

Apply this only when a task can perform an external effect that is not safely
repeatable. Before an authorized request, retain the available operation identity
or service-supported idempotency key, target and read-only outcome lookup in the
existing State/evidence record. Record returned IDs as soon as they are available;
do not invent an ID that the service does not recognize.

A timeout or disconnect can occur after the effect succeeds. Leave its outcome
`unknown` until observed. On recovery, query the actual service using that identity
and reconcile its receipt before deciding to retry. If the same authorized action
is safe to retry, reuse its existing idempotency key; a new key may create a second
effect. Never put a business write into the observational anchor to obtain retries.

For example, if a record was created but the response was lost, lookup of the
existing request should settle whether it exists before another create is sent.
If neither readback nor deduplication is available, do independent safe work and
leave that action unresolved. Ask the owner only for an actual authority or risk
decision, not for a fact they cannot supply. Record the missing observation and
what would make retry safe. Local locks/events cannot guarantee exactly-once
effects, and Stop cannot reverse a write or wake a crashed host.

## Setup and final result

Before the owner leaves, exercise the actual artifact entry point, confirm the
native continuation service and resource controls, arm using the current native
session identity, and establish where the owner will read results. Native
authorization/sandbox controls own effects; Stop cannot undo a forbidden write.
Estimate closeout needs from the actual consumer and relevant checks during setup;
respect native quota signals during execution. If a limit prevents the accepted
review or verification, preserve the pending work and report incomplete instead
of weakening checks or extending the budget by assumption.

Ordinary Stop means only a turn ended. A completion candidate triggers current
verification. The event's `verification_passed` is the accepted-contract result;
native goal status and agent prose are separate claims. The event also carries
review provenance when required. `validate_artifact.py .goals --status --json`
exposes `last_verification` separately from `last_anchor_check`: a pending candidate or
newer refusal or unfinished verification takes precedence over an old green.
`verification_started` and settlement share one attempt ID; an unfinished start is
pending/unknown until reconciled and may be marked interrupted by a later owning
gate. It is counted once and is not silently retried. This is a historical observation
(`fresh_check: false`), not a live recheck of subsequently edited outputs.
For final delivery, finish all output edits and required review, then call:

```sh
python3 /installed/skill/scripts/goal_run.py verify demo --root /project --session-id <current-native-session-id> --claim "Accepted result ready"
```

This explicit completion attempt uses the same gate as Stop and returns its actual
recorded observation as JSON before the final response. Exit 0 requires this attempt's
`verification_passed: true`; a missing record, refusal, unknown or exhausted ceiling
returns nonzero. It never starts a model or simulates a host lifecycle event. Read the
result, reconcile any separately enabled native goal using the host's real tools, and deliver the
output/evidence paths, attempt and remaining limits. Do not edit reviewed outputs
after verification; changes require fresh review and verification. Subsequent ordinary
Stop does not repeat the consumed attempt. The observation is about that measured
state, not future edits.

The candidate-file Stop path remains a fallback. Its final model response may precede
verification: report pending until a real event is observed, and use status/audit or
a later native turn to reconcile. A host without the needed continuation or result
delivery is a supported interactive run, not an unattended one.
