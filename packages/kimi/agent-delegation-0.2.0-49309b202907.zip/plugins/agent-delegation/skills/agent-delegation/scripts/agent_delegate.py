#!/usr/bin/env python3
"""Receipt-backed mission delegation through a pinned ACPX runtime."""

from __future__ import annotations

import argparse
from contextlib import contextmanager
from datetime import UTC, datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import signal
import subprocess
import sys
import tempfile
import time
from typing import Any, Callable, Iterable, Iterator
import uuid


VERSION = "0.2.0"
SCHEMA_VERSION = 1
DEFAULT_TIMEOUT_SECONDS = 7200
MAX_TIMEOUT_SECONDS = 7200
TARGET_NAME = re.compile(r"^[a-z0-9][a-z0-9-]{0,62}$")
RESERVED_TARGETS = {
    "cancel",
    "compare",
    "config",
    "exec",
    "flow",
    "prompt",
    "sessions",
    "set",
    "set-mode",
    "status",
}
PERMISSION_FLAGS = {
    "approve-all": "--approve-all",
    "approve-reads": "--approve-reads",
    "deny-all": "--deny-all",
}


class DelegationError(RuntimeError):
    """A user-facing delegation failure."""


def _home() -> Path:
    configured = os.environ.get("AGENT_DELEGATION_HOME")
    return Path(configured).expanduser().resolve() if configured else Path.home()


def _registry_path() -> Path:
    configured = os.environ.get("AGENT_DELEGATION_CONFIG")
    if configured:
        return Path(configured).expanduser().resolve()
    return _home() / ".config" / "agent-delegation" / "config.json"


def _read_json_object(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise DelegationError(
            f"Missing configuration {path}; run the reviewed install_user.py first."
        ) from exc
    except json.JSONDecodeError as exc:
        raise DelegationError(f"Invalid JSON in {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise DelegationError(f"Expected a JSON object in {path}.")
    return value


def _atomic_write_json(path: Path, value: dict[str, Any], mode: int = 0o600) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary_path = Path(temporary)
    try:
        os.fchmod(descriptor, mode)
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary_path, path)
    finally:
        temporary_path.unlink(missing_ok=True)


def _atomic_write_text(path: Path, value: str, mode: int = 0o600) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary_path = Path(temporary)
    try:
        os.fchmod(descriptor, mode)
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            handle.write(value)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary_path, path)
    finally:
        temporary_path.unlink(missing_ok=True)


@contextmanager
def _configuration_lock(registry_path: Path) -> Iterator[None]:
    lock_path = registry_path.parent / ".config.lock"
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with lock_path.open("a+", encoding="utf-8") as handle:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def _load_registry() -> tuple[Path, dict[str, Any]]:
    path = _registry_path()
    registry = _read_json_object(path)
    if registry.get("schema_version") != SCHEMA_VERSION:
        raise DelegationError(
            f"Unsupported registry schema {registry.get('schema_version')!r}; expected {SCHEMA_VERSION}."
        )
    targets = registry.get("targets")
    if not isinstance(targets, dict):
        raise DelegationError("Registry must contain a targets object.")
    acpx = registry.get("acpx_path")
    if not isinstance(acpx, str) or not Path(acpx).is_absolute():
        raise DelegationError("Registry acpx_path must be an absolute path.")
    return path, registry


def _validate_target_record(name: object, target: object) -> None:
    if not isinstance(name, str) or not TARGET_NAME.fullmatch(name):
        raise DelegationError(f"Invalid target name {name!r}.")
    if name in RESERVED_TARGETS or name == "human":
        raise DelegationError(f"Reserved target name {name!r}.")
    if not isinstance(target, dict):
        raise DelegationError(f"Target {name!r} must be an object.")
    argv = target.get("argv")
    if (
        not isinstance(argv, list)
        or not argv
        or not all(isinstance(item, str) and item for item in argv)
    ):
        raise DelegationError(f"Target {name!r} must have a non-empty string argv array.")
    if not Path(argv[0]).is_absolute():
        raise DelegationError(f"Target {name!r} argv[0] must be absolute.")


def _target(registry: dict[str, Any], name: str) -> dict[str, Any]:
    target = registry["targets"].get(name)
    if not isinstance(target, dict):
        available = ", ".join(sorted(registry["targets"]))
        raise DelegationError(f"Unknown target {name!r}; available targets: {available}.")
    _validate_target_record(name, target)
    return target


def _acpx_config_path(registry: dict[str, Any]) -> Path:
    configured = registry.get("acpx_config_path")
    if not isinstance(configured, str) or not Path(configured).is_absolute():
        raise DelegationError("Registry acpx_config_path must be an absolute path.")
    return Path(configured)


def _parse_chain(raw: str | None, caller: str) -> list[str]:
    chain = [part.strip() for part in raw.split(",")] if raw else [caller]
    if not chain or any(not part for part in chain):
        raise DelegationError("Delegation chain contains an empty entry.")
    if chain[-1] != caller:
        chain.append(caller)
    return chain


def _read_task(
    args: argparse.Namespace, cwd: Path, max_chars: int | None
) -> tuple[str, str]:
    if args.task is not None:
        task = args.task
        source = "argument"
    elif args.task_file is not None:
        task_path = Path(args.task_file).expanduser()
        if not task_path.is_absolute():
            task_path = cwd / task_path
        task_path = task_path.resolve()
        try:
            task = task_path.read_text(encoding="utf-8")
        except (OSError, UnicodeError) as exc:
            raise DelegationError(f"Cannot read task file {task_path}: {exc}") from exc
        source = str(task_path)
    elif not sys.stdin.isatty():
        task = sys.stdin.read()
        source = "stdin"
    else:
        raise DelegationError("Provide --task, --task-file, or piped stdin.")
    if not task.strip():
        raise DelegationError("Task must not be empty.")
    if max_chars is not None and len(task) > max_chars:
        raise DelegationError(f"Task has {len(task)} characters; configured limit is {max_chars}.")
    return task, source


def _delegation_context(
    delegation_id: str,
    caller: str,
    target: str,
    chain: list[str],
    max_depth: int,
    cwd: Path,
    permissions: str,
    terminal: bool,
) -> str:
    context = {
        "schema": "agent-delegation-context/v1",
        "delegation_id": delegation_id,
        "caller": caller,
        "target": target,
        "chain": [*chain, target],
        "depth": len(chain),
        "max_depth": max_depth,
        "cwd": str(cwd),
        "permissions": permissions,
        "terminal": terminal,
        "authority": (
            "Available transport capabilities do not create authority. Follow the mission's "
            "explicit goal, requirements, inherited authority, and commit gates; pause only "
            "before an ungranted effect."
        ),
    }
    return (
        "<agent-delegation-context>\n"
        + json.dumps(context, ensure_ascii=False, sort_keys=True)
        + "\n</agent-delegation-context>\n\n"
    )


def _new_receipt_dir(registry: dict[str, Any], delegation_id: str) -> Path:
    root_raw = registry.get("receipt_root")
    if not isinstance(root_raw, str) or not Path(root_raw).is_absolute():
        raise DelegationError("Registry receipt_root must be an absolute path.")
    root = Path(root_raw)
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    path = root / f"{stamp}-{delegation_id}"
    path.mkdir(mode=0o700)
    return path


def _session_update(item: dict[str, Any]) -> dict[str, Any]:
    params = item.get("params")
    if not isinstance(params, dict):
        return {}
    update = params.get("update")
    return update if isinstance(update, dict) else {}


def _extract_result(events: Iterable[str], max_chars: int | None) -> dict[str, Any]:
    contents: list[dict[str, Any]] = []
    errors: list[dict[str, Any]] = []
    methods: dict[object, str] = {}
    result: dict[str, Any] = {
        "stop_reason": None, "acp_session_id": None, "acpx_record_id": None,
        "parsed_event_count": 0, "unparsed_event_count": 0,
    }
    for line in events:
        if not line.strip():
            continue
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            result["unparsed_event_count"] += 1
            continue
        if not isinstance(item, dict):
            result["unparsed_event_count"] += 1
            continue
        result["parsed_event_count"] += 1
        request_id = item.get("id")
        if isinstance(request_id, (str, int)) and isinstance(item.get("method"), str):
            methods[request_id] = item["method"]
        update = _session_update(item)
        if update.get("sessionUpdate") == "agent_message_chunk":
            content = update.get("content")
            if isinstance(content, dict):
                contents.append(content)
        params = item.get("params")
        if isinstance(params, dict) and isinstance(params.get("sessionId"), str):
            result["acp_session_id"] = params["sessionId"]
        response = item.get("result")
        if not isinstance(response, dict) and isinstance(item.get("action"), str):
            response = item
        if isinstance(response, dict):
            if isinstance(response.get("stopReason"), str):
                result["stop_reason"] = response["stopReason"]
            for source, dest in (("sessionId", "acp_session_id"), ("acpSessionId", "acp_session_id"),
                                 ("acpxSessionId", "acp_session_id"), ("acpxRecordId", "acpx_record_id"),
                                 ("agentSessionId", "agent_session_id")):
                if isinstance(response.get(source), str):
                    result[dest] = response[source]
            if isinstance(response.get("action"), str):
                result["action"] = response["action"]
            if isinstance(response.get("cancelled"), bool):
                result["cancel_requested"] = response["cancelled"]
        error = item.get("error")
        if isinstance(error, dict):
            method = methods.get(request_id) if isinstance(request_id, (str, int)) else None
            scope = "tool" if method and (method.startswith(("fs/", "terminal/")) or method == "session/request_permission") else "rpc"
            errors.append({**error, "request_id": request_id, "method": method, "scope": scope})
        if "result" in item or "error" in item:
            if isinstance(request_id, (str, int)):
                methods.pop(request_id, None)
    full_text = "".join(c.get("text", "") for c in contents if c.get("type") == "text" and isinstance(c.get("text"), str))
    result.update({
        "assistant_text": full_text if max_chars is None else full_text[:max_chars],
        "assistant_text_truncated": max_chars is not None and len(full_text) > max_chars,
        "assistant_content": contents,
        "rpc_errors": errors,
        "tool_errors": [error for error in errors if error["scope"] == "tool"],
        # Keep the legacy field, without labeling ordinary client operations as protocol failures.
        "protocol_errors": [error.get("message", "") for error in errors if error["scope"] != "tool"],
    })
    return result


def _result_status(code: int, parsed: dict[str, Any], interrupted: str | None, control: bool) -> str:
    if interrupted:
        return interrupted
    stop = parsed["stop_reason"]
    if stop == "cancelled" or code == 130:
        return "cancelled"
    if code == 3 or code == 124:
        return "timeout"
    if code == 5:
        return "denied"
    if code == 4:
        return "not_found"
    if code != 0:
        return "error"
    if control:
        return "success" if parsed.get("action") else "incomplete"
    if stop == "end_turn":
        return "success"
    if stop == "refusal":
        return "refused"
    return "error" if parsed["protocol_errors"] and not stop else "incomplete"


def _positive_int(raw: Any, label: str) -> int:
    try:
        value = int(raw)
    except (TypeError, ValueError) as exc:
        raise DelegationError(f"{label} must be a positive integer.") from exc
    if isinstance(raw, bool) or str(value) != str(raw) or value < 1:
        raise DelegationError(f"{label} must be a positive integer.")
    return value


def _stop_process(process: subprocess.Popen) -> None:
    # ACPX gets a chance to cancel the turn and close its agent before forced cleanup.
    for signum in (signal.SIGINT, signal.SIGTERM, signal.SIGKILL):
        try:
            os.killpg(process.pid, signum)
        except ProcessLookupError:
            return
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            continue
        try:
            os.killpg(process.pid, 0)
        except ProcessLookupError:
            return


def _stream_command(command: list[str], prompt: str, env: dict[str, str], timeout: float,
                    stdout: Any, stderr: Any,
                    on_interrupt: Callable[[], None] | None = None) -> tuple[int, str | None]:
    # File descriptors preserve streamed bytes even when the process is interrupted.
    with tempfile.TemporaryFile() as task_input:
        task_input.write(prompt.encode("utf-8"))
        task_input.seek(0)
        process = subprocess.Popen(command, stdin=task_input, stdout=stdout, stderr=stderr,
                                   env=env, start_new_session=True)
        try:
            return process.wait(timeout=max(0.001, timeout)), None
        except subprocess.TimeoutExpired:
            code, reason = 124, "timeout"
        except KeyboardInterrupt:
            code, reason = 130, "cancelled"
        if on_interrupt:
            on_interrupt()
            try:
                # Keep the waiting client alive to receive the turn's terminal event.
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                _stop_process(process)
        else:
            _stop_process(process)
        return code, reason


@contextmanager
def _session_turn_lock(receipt_dir: Path, argv: list[str], cwd: Path,
                       session: str | None, deadline: float) -> Iterator[None]:
    if session is None:
        yield
        return
    # ACPX can cancel the active turn, but cannot remove a particular queued turn.
    # Wait before submitting so interrupting a waiter cannot cancel another task.
    identity = json.dumps([argv, str(cwd), session], ensure_ascii=False)
    lock_root = receipt_dir.parent / ".session-locks"
    lock_root.mkdir(mode=0o700, exist_ok=True)
    lock_path = lock_root / (hashlib.sha256(identity.encode()).hexdigest() + ".lock")
    with lock_path.open("a+b") as handle:
        os.chmod(lock_path, 0o600)
        waiting = False
        while True:
            try:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if not waiting:
                    print(json.dumps({"status": "waiting", "session_name": session,
                                      "receipt_dir": str(receipt_dir)}), file=sys.stderr, flush=True)
                    waiting = True
                if time.monotonic() >= deadline:
                    raise TimeoutError("Timed out waiting for the session's current turn.")
                time.sleep(0.1)
        # Closing the descriptor releases the lock, including on interruption.
        yield


def _configured_char_limit(registry: dict[str, Any], key: str) -> int | None:
    raw = registry.get(key)
    if raw is None:
        return None
    return _positive_int(raw, f"Registry {key}")


def _normalized_exit_code(code: int) -> int:
    return code if 0 <= code <= 125 else 1


def _run(args: argparse.Namespace) -> int:
    _, registry = _load_registry()
    target = _target(registry, args.to)
    control = args.command in ("cancel", "close")
    caller = (args.caller or os.environ.get("AGENT_DELEGATION_CALLER") or "unknown").strip()
    if not caller or "," in caller:
        raise DelegationError("Caller must be a non-empty label without commas.")
    chain = [caller] if control else _parse_chain(args.chain if args.chain is not None else os.environ.get("AGENT_DELEGATION_CHAIN"), caller)
    configured_depth = 1 if control else _positive_int(registry.get("max_delegation_depth", 4), "max_delegation_depth")
    inherited_depth = 1 if control else _positive_int(os.environ.get("AGENT_DELEGATION_MAX_DEPTH", configured_depth), "inherited max depth")
    ceiling = min(configured_depth, inherited_depth)
    max_depth = args.max_depth if args.max_depth is not None else ceiling
    if not control and (max_depth < 1 or max_depth > ceiling or len(chain) > max_depth):
        raise DelegationError(f"Delegation depth {len(chain)} must fit max-depth 1..{ceiling} (requested {max_depth}).")

    cwd = Path(args.cwd).expanduser().resolve()
    if not cwd.is_dir():
        raise DelegationError(f"Delegation cwd is not an existing directory: {cwd}")
    timeout = args.timeout if args.timeout is not None else _positive_int(
        registry.get("default_timeout_seconds", DEFAULT_TIMEOUT_SECONDS), "default_timeout_seconds")
    max_timeout = timeout if control else _positive_int(registry.get("max_timeout_seconds", MAX_TIMEOUT_SECONDS), "max_timeout_seconds")
    if timeout < 1 or timeout > max_timeout:
        raise DelegationError(f"timeout must be between 1 and {max_timeout} seconds.")
    max_task_chars = None if control else _configured_char_limit(registry, "max_task_chars")
    max_result_chars = None if control else _configured_char_limit(registry, "max_result_chars")
    task, task_source = ("", "control") if control else _read_task(args, cwd, max_task_chars)
    if args.session is not None:
        args.session = args.session.strip()
        if not args.session:
            raise DelegationError("Session name must not be empty.")
    delegation_id = uuid.uuid4().hex
    prompt = "" if control else _delegation_context(delegation_id, caller, args.to, chain,
                    max_depth, cwd, args.permissions, args.terminal) + task
    for label, executable in (("Pinned ACPX", registry["acpx_path"]), ("Target", target["argv"][0])):
        if control and label == "Target":
            continue
        if not Path(executable).is_file() or not os.access(executable, os.X_OK):
            raise DelegationError(f"{label} executable is missing or not executable: {executable}")

    # ACPX parses this quoted argv without a shell. The registry is the launch authority;
    # global/project agent aliases cannot silently select a different executable.
    base = [registry["acpx_path"], "--agent", shlex.join(target["argv"]), "--cwd", str(cwd),
            "--timeout", str(timeout), "--format", "json", "--json-strict", "--suppress-reads",
            PERMISSION_FLAGS[args.permissions], "--non-interactive-permissions", "fail"]
    if not args.terminal:
        base.append("--no-terminal")
    if args.model:
        base.extend(["--model", args.model])
    if control:
        suffix = ["cancel", "--session", args.session] if args.command == "cancel" else ["sessions", "close", args.session]
        commands = [(base + suffix, "")]
    elif args.session:
        commands = [(base + ["sessions", "ensure", "--name", args.session], ""),
                    (base + ["prompt", "--session", args.session, "--file", "-"], prompt)]
    else:
        commands = [(base + ["exec", "--file", "-"], prompt)]
    request = {
        "schema": "agent-delegation-request/v1", "delegation_id": delegation_id,
        "created_at": datetime.now(UTC).isoformat(), "caller": caller, "target": args.to,
        "chain": [*chain, args.to], "cwd": str(cwd), "timeout_seconds": timeout,
        "permissions": args.permissions, "terminal": args.terminal,
        "authorization_note": args.authorization_note, "task_source": task_source,
        "task_chars": len(task), "task_sha256": hashlib.sha256(task.encode()).hexdigest(),
        "target_argv": target["argv"], "session_name": args.session, "requested_model": args.model,
        "operation": args.command,
    }
    if args.dry_run:
        print(json.dumps({**request, "status": "dry_run", "command": commands[-1][0],
                          "commands": [command for command, _ in commands]}, ensure_ascii=False, indent=2))
        return 0
    receipt_dir = _new_receipt_dir(registry, delegation_id)
    _atomic_write_json(receipt_dir / "request.json", request)
    child_env = {**os.environ, "AGENT_DELEGATION_CALLER": args.to,
                 "AGENT_DELEGATION_CHAIN": ",".join([*chain, args.to]),
                 "AGENT_DELEGATION_MAX_DEPTH": str(max_depth)}
    print(json.dumps({"status": "running", "delegation_id": delegation_id,
                      "receipt_dir": str(receipt_dir)}), file=sys.stderr, flush=True)
    started = time.monotonic()
    return_code, interrupted, launch_error, cancellation_exit_code = 1, None, None, None
    def handle_termination(signum: int, frame: Any) -> None:
        raise KeyboardInterrupt
    previous_handler = signal.signal(signal.SIGTERM, handle_termination)
    try:
        with (receipt_dir / "events.ndjson").open("xb", buffering=0) as stdout, (receipt_dir / "stderr.log").open("xb", buffering=0) as stderr:
            os.chmod(stdout.name, 0o600)
            os.chmod(stderr.name, 0o600)
            def cancel_named_turn() -> None:
                nonlocal cancellation_exit_code
                try:
                    cancellation_exit_code, _ = _stream_command(
                        base + ["cancel", "--session", args.session], "", child_env, 10, stdout, stderr)
                except OSError as exc:
                    cancellation_exit_code = 1
                    stderr.write((str(exc) + "\n").encode())
            try:
                with _session_turn_lock(receipt_dir, target["argv"], cwd,
                                        args.session if not control else None, started + timeout):
                    prompt_started = False
                    try:
                        for command, command_input in commands:
                            prompt_started = bool(command_input)
                            return_code, interrupted = _stream_command(command, command_input, child_env,
                                timeout + 30 - (time.monotonic() - started), stdout, stderr,
                                cancel_named_turn if args.session and prompt_started and not control else None)
                            if return_code != 0 or interrupted:
                                break
                    except KeyboardInterrupt:
                        return_code, interrupted = 130, "cancelled"
                    finally:
                        if interrupted and args.session and prompt_started and not control and cancellation_exit_code is None:
                            cancel_named_turn()
            except KeyboardInterrupt:
                return_code, interrupted = 130, "cancelled"
            except TimeoutError as exc:
                return_code, interrupted = 124, "timeout"
                stderr.write((str(exc) + "\n").encode())
            except OSError as exc:
                launch_error = str(exc)
                stderr.write((launch_error + "\n").encode())
                return_code = 1
    finally:
        signal.signal(signal.SIGTERM, previous_handler)
    with (receipt_dir / "events.ndjson").open(encoding="utf-8", errors="replace") as events:
        parsed = _extract_result(events, max_result_chars)
    status = _result_status(return_code, parsed, interrupted, control)
    if cancellation_exit_code is not None and (
        cancellation_exit_code != 0 or parsed["stop_reason"] not in ("cancelled", "end_turn")
    ):
        status = "incomplete"
    result = {
        "schema": "agent-delegation-result/v1", **parsed, "status": status,
        "delegation_id": delegation_id, "caller": caller, "target": args.to,
        "chain": [*chain, args.to], "cwd": str(cwd), "exit_code": return_code,
        "session_name": args.session, "requested_model": args.model, "operation": args.command,
        "timeout_seconds": timeout, "cancellation_exit_code": cancellation_exit_code,
        "launch_error": launch_error, "duration_seconds": round(time.monotonic() - started, 3),
        "receipt_dir": str(receipt_dir),
    }
    _atomic_write_json(receipt_dir / "result.json", result)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if status == "success":
        return 0
    return {"cancelled": 130, "timeout": 124, "denied": 5}.get(status, _normalized_exit_code(return_code) or 1)


def _list_targets(args: argparse.Namespace) -> int:
    _, registry = _load_registry()
    rows = []
    for name in sorted(registry["targets"]):
        target = registry["targets"][name]
        if not isinstance(target, dict):
            rows.append({"name": name, "argv": [], "observed_version": None, "provenance": "invalid record; run doctor"})
            continue
        rows.append(
            {
                "name": name,
                "argv": target.get("argv", []),
                "observed_version": target.get("observed_version"),
                "provenance": target.get("provenance"),
            }
        )
    if args.json:
        print(json.dumps({"schema_version": SCHEMA_VERSION, "targets": rows}, indent=2))
    else:
        for row in rows:
            print(f"{row['name']}\t{row['observed_version'] or '-'}\t{row['argv'][0] if row['argv'] else '-'}")
    return 0


def _run_version_probe(argv: list[str]) -> tuple[bool, str]:
    try:
        completed = subprocess.run(
            argv,
            text=True,
            capture_output=True,
            timeout=30,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return False, str(exc)
    output = (completed.stdout + completed.stderr).strip().splitlines()
    summary = output[0] if output else f"exit {completed.returncode}"
    return completed.returncode == 0, summary


def _doctor(args: argparse.Namespace) -> int:
    _, registry = _load_registry()
    checks: list[dict[str, Any]] = []
    acpx = Path(registry["acpx_path"])
    checks.append({"check": "acpx_executable", "ok": acpx.is_file() and os.access(acpx, os.X_OK), "detail": str(acpx)})
    names = [args.to] if args.to else sorted(registry["targets"])
    selected_argv: list[str] = [str(acpx)]
    for name in names:
        try:
            target = _target(registry, name)
        except DelegationError as exc:
            checks.append({"check": f"target:{name}:record", "ok": False, "detail": str(exc)})
            continue
        executable = Path(target["argv"][0])
        selected_argv.extend(target["argv"])
        checks.append({"check": f"target:{name}:executable", "ok": executable.is_file() and os.access(executable, os.X_OK),
                       "detail": str(executable), "launch_argv": target["argv"]})
        probe = target.get("version_argv")
        if isinstance(probe, list) and probe:
            ok, detail = _run_version_probe(probe)
            expected = target.get("observed_version")
            drift = isinstance(expected, str) and expected not in detail
            checks.append({"check": f"target:{name}:version_probe", "ok": ok, "required": False,
                           "warning": "informational probe unavailable" if not ok else ("observed version drift" if drift else None),
                           "detail": detail, "note": "This probe may differ from the CLI bundled by an adapter."})
    runtime_root_raw = registry.get("runtime_root")
    packages = registry.get("runtime_packages") or {}
    if isinstance(runtime_root_raw, str) and isinstance(packages, dict):
        for package, expected in sorted(packages.items()):
            root = Path(runtime_root_raw) / "node_modules" / package
            if args.to and not any(Path(arg).is_absolute() and Path(arg).is_relative_to(root) for arg in selected_argv):
                continue
            observed = None
            try:
                observed = json.loads((root / "package.json").read_text())["version"]
            except (OSError, ValueError, KeyError, TypeError):
                pass
            checks.append({"check": f"runtime_package:{package}", "ok": observed == expected,
                           "detail": f"expected {expected}, observed {observed}"})
    limits = {"default_timeout_seconds": registry.get("default_timeout_seconds", DEFAULT_TIMEOUT_SECONDS),
              "max_timeout_seconds": registry.get("max_timeout_seconds", MAX_TIMEOUT_SECONDS),
              "max_delegation_depth": registry.get("max_delegation_depth", 4),
              "max_task_chars": registry.get("max_task_chars"), "max_result_chars": registry.get("max_result_chars")}
    try:
        for key in ("default_timeout_seconds", "max_timeout_seconds", "max_delegation_depth"):
            limits[key] = _positive_int(limits[key], key)
        for key in ("max_task_chars", "max_result_chars"):
            _configured_char_limit(registry, key)
        if limits["default_timeout_seconds"] > limits["max_timeout_seconds"]:
            raise DelegationError("Default timeout exceeds configured maximum.")
    except DelegationError as exc:
        checks.append({"check": "limits", "ok": False, "detail": str(exc)})
    ok = all(check["ok"] for check in checks if check.get("required", True))
    payload = {"status": "ok" if ok else "error", "limits": limits, "checks": checks,
               "launch_source": "registry argv (passed directly to ACPX)"}
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        for check in checks:
            marker = "WARN" if check.get("warning") else ("ok" if check["ok"] else "FAIL")
            print(f"{marker}\t{check['check']}\t{check['detail']}")
        print(json.dumps(limits))
    return 0 if ok else 1


def _backup_configuration(registry_path: Path, acpx_path: Path) -> Path:
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    backup = _home() / ".local" / "state" / "agent-delegation" / "backups" / f"{stamp}-register"
    backup.mkdir(parents=True, exist_ok=False, mode=0o700)
    for source, name in ((registry_path, "registry.json"), (acpx_path, "acpx-config.json")):
        if source.exists():
            _atomic_write_text(backup / name, source.read_text(encoding="utf-8"))
    return backup


def _register(args: argparse.Namespace) -> int:
    if not TARGET_NAME.fullmatch(args.name) or args.name in RESERVED_TARGETS or args.name == "human":
        raise DelegationError(f"Invalid or reserved target name {args.name!r}.")
    try:
        argv = json.loads(args.argv_json)
    except json.JSONDecodeError as exc:
        raise DelegationError(f"Invalid --argv-json: {exc}") from exc
    record: dict[str, Any] = {
        "argv": argv,
        "observed_version": args.observed_version,
        "provenance": args.provenance,
    }
    if args.version_argv_json:
        try:
            record["version_argv"] = json.loads(args.version_argv_json)
        except json.JSONDecodeError as exc:
            raise DelegationError(f"Invalid --version-argv-json: {exc}") from exc
    _validate_target_record(args.name, record)
    executable = Path(record["argv"][0])
    if not executable.is_file() or not os.access(executable, os.X_OK):
        raise DelegationError(f"Target executable is missing or not executable: {executable}")

    registry_path = _registry_path()
    with _configuration_lock(registry_path):
        registry = _read_json_object(registry_path)
        existing = (registry.get("targets") or {}).get(args.name)
        if existing is not None and not args.replace:
            raise DelegationError(f"Target {args.name!r} already exists; pass --replace to update it.")
        acpx_path = _acpx_config_path(registry)
        backup = _backup_configuration(registry_path, acpx_path)
        targets = registry.setdefault("targets", {})
        targets[args.name] = record
        acpx_config = _read_json_object(acpx_path)
        acpx_agents = acpx_config.setdefault("agents", {})
        if not isinstance(acpx_agents, dict):
            raise DelegationError("ACPX agents configuration must be an object.")
        acpx_agents[args.name] = {"argv": record["argv"]}
        _atomic_write_json(registry_path, registry)
        _atomic_write_json(acpx_path, acpx_config)
    print(
        json.dumps(
            {"status": "registered", "name": args.name, "backup_dir": str(backup)},
            indent=2,
        )
    )
    return 0


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="agent-delegate",
        description="Delegate missions through a pinned ACPX runtime.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {VERSION}")
    subparsers = parser.add_subparsers(dest="command", required=True)

    list_parser = subparsers.add_parser("list", help="List reviewed ACP targets.")
    list_parser.add_argument("--json", action="store_true")
    list_parser.set_defaults(handler=_list_targets)

    doctor_parser = subparsers.add_parser("doctor", help="Validate runtime, registry, and targets.")
    doctor_parser.add_argument("--json", action="store_true")
    doctor_parser.add_argument("--to", help="Check only this target and its runtime dependencies.")
    doctor_parser.set_defaults(handler=_doctor)

    run_parser = subparsers.add_parser("run", help="Run a delegated task, optionally in a named ACPX session.")
    run_parser.add_argument("--to", required=True, help="Registered target name.")
    run_parser.add_argument("--caller", help="Source label; defaults to the inherited caller or unknown.")
    run_parser.add_argument("--chain", help="Comma-separated provenance chain; repeated targets are allowed.")
    run_parser.add_argument("--max-depth", type=int, help="May lower the inherited/configured depth budget.")
    run_parser.add_argument("--cwd", required=True, help="Existing absolute or resolvable task directory.")
    task_group = run_parser.add_mutually_exclusive_group()
    task_group.add_argument("--task", help="Short task text; prefer --task-file for long packets.")
    task_group.add_argument("--task-file", help="UTF-8 mission envelope path, or pipe mission text on stdin.")
    run_parser.add_argument("--timeout", type=int, help="Timeout in seconds, within the configured budget.")
    run_parser.add_argument("--session", help="Ensure and continue a named native ACPX session.")
    run_parser.add_argument("--model", help="Explicit target model; omitted to retain target defaults.")
    run_parser.add_argument(
        "--permissions",
        choices=sorted(PERMISSION_FLAGS),
        default="approve-all",
        help="ACPX transport policy; defaults to preserving the target's normal capabilities.",
    )
    terminal_group = run_parser.add_mutually_exclusive_group()
    terminal_group.add_argument(
        "--terminal",
        dest="terminal",
        action="store_true",
        help="Advertise ACP terminal capability (default).",
    )
    terminal_group.add_argument(
        "--no-terminal",
        dest="terminal",
        action="store_false",
        help="Explicitly remove ACP terminal capability for a restricted mission.",
    )
    run_parser.add_argument(
        "--authorization-note",
        help="Optional existing owner authority or prompt-boundary note stored in the receipt.",
    )
    run_parser.add_argument("--dry-run", action="store_true", help="Validate and print the launch plan only.")
    run_parser.set_defaults(terminal=True, handler=_run)

    for operation in ("cancel", "close"):
        control = subparsers.add_parser(operation, help=f"{operation.capitalize()} a named native ACPX session.")
        control.add_argument("--to", required=True)
        control.add_argument("--cwd", required=True)
        control.add_argument("--session", required=True)
        control.add_argument("--timeout", type=int, default=30)
        control.add_argument("--dry-run", action="store_true")
        control.set_defaults(handler=_run, caller=None, chain=None, max_depth=None,
                             model=None, permissions="approve-all", terminal=True, authorization_note=None)

    register_parser = subparsers.add_parser("register", help="Register an additional reviewed ACP target.")
    register_parser.add_argument("--name", required=True)
    register_parser.add_argument("--argv-json", required=True, help="JSON string array with absolute executable.")
    register_parser.add_argument("--version-argv-json", help="Optional JSON string array for a read-only version probe.")
    register_parser.add_argument("--observed-version", required=True)
    register_parser.add_argument("--provenance", required=True)
    register_parser.add_argument("--replace", action="store_true")
    register_parser.set_defaults(handler=_register)
    return parser


def main() -> int:
    parser = _build_parser()
    args = parser.parse_args()
    try:
        return int(args.handler(args))
    except (DelegationError, OSError) as exc:
        print(
            json.dumps(
                {"status": "error", "type": "delegation_error", "message": str(exc)},
                ensure_ascii=False,
            ),
            file=sys.stderr,
        )
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
