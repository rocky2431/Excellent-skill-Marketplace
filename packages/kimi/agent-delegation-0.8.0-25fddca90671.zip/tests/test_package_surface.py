from __future__ import annotations

import hashlib
import json
from pathlib import Path
import unittest


REPO_ROOT = Path(__file__).resolve().parents[1]


class PackageSurfaceTests(unittest.TestCase):
    def test_native_manifests_share_one_skill_tree(self) -> None:
        plugin = REPO_ROOT / "plugins/agent-delegation"
        expected = json.loads((plugin / ".codex-plugin/plugin.json").read_text())
        for relative in (".claude-plugin/plugin.json", ".zcode-plugin/plugin.json", "kimi.plugin.json"):
            manifest = json.loads((plugin / relative).read_text())
            self.assertEqual(manifest["name"], expected["name"])
            self.assertEqual(manifest["version"], expected["version"])
        self.assertTrue((plugin / "skills/agent-delegation/SKILL.md").is_file())

    def test_plugin_and_marketplace_point_to_canonical_skill(self) -> None:
        plugin_root = REPO_ROOT / "plugins/agent-delegation"
        plugin = json.loads(
            (plugin_root / ".codex-plugin/plugin.json").read_text(encoding="utf-8")
        )
        marketplace = json.loads(
            (REPO_ROOT / ".agents/plugins/marketplace.json").read_text(encoding="utf-8")
        )
        self.assertEqual(plugin["name"], "agent-delegation")
        self.assertEqual(plugin["skills"], "./skills/")
        self.assertTrue((plugin_root / "skills/agent-delegation/SKILL.md").is_file())
        entry = marketplace["plugins"][0]
        self.assertEqual(entry["name"], "agent-delegation")
        self.assertEqual(entry["source"]["path"], "./plugins/agent-delegation")

    def test_package_versions_are_consistent(self) -> None:
        plugin = json.loads(
            (
                REPO_ROOT
                / "plugins/agent-delegation/.codex-plugin/plugin.json"
            ).read_text(encoding="utf-8")
        )
        runtime = json.loads((REPO_ROOT / "runtime/package.json").read_text(encoding="utf-8"))
        lock = json.loads((REPO_ROOT / "runtime/package-lock.json").read_text(encoding="utf-8"))
        version = plugin["version"]
        self.assertEqual(runtime["version"], version)
        self.assertEqual(lock["version"], version)
        self.assertEqual(lock["packages"][""]["version"], version)
        self.assertIn(
            f'VERSION = "{version}"',
            (REPO_ROOT / "scripts/install_user.py").read_text(encoding="utf-8"),
        )
        self.assertIn(
            f'VERSION = "{version}"',
            (
                REPO_ROOT
                / "plugins/agent-delegation/skills/agent-delegation/scripts/agent_delegate.py"
            ).read_text(encoding="utf-8"),
        )

    def test_runtime_direct_dependencies_and_integrities_are_exact(self) -> None:
        package = json.loads((REPO_ROOT / "runtime/package.json").read_text(encoding="utf-8"))
        lock = json.loads((REPO_ROOT / "runtime/package-lock.json").read_text(encoding="utf-8"))
        expected = {
            "zcode-acp-server": (
                "0.46.6",
                "sha512-r2uUItqcQhzPDJ8ckRxJvEocThWW7+ObjN9/wTz7M6b5+RSbeIOdtoUL1RCmJ44FxfpJIAIGEeY3uoAYbLBpTg==",
            ),
            "pi-acp": ('0.0.33', 'sha512-vX9kY1tK14E72G4dBAx+RGCk/k7XPjTHls6dLUxA8WSkBav6B6JHuSBv3eusp50LCR/GTRsR2kIKsG0Z5jANzw=='),
            "acpx": (
                "0.13.2",
                "sha512-4hOLEo2kE/nCrPr50StbzU3G1WvzHkmKE/r3vxFAIr6GRI3VSmSRH62XCtnDpVcQNpBM8fVPAeTj39ewVhJwdQ==",
            ),
            "@agentclientprotocol/claude-agent-acp": (
                "0.75.1",
                "sha512-Un6I4BRkhpCFS3I7kr5C/lkAm8Nc3VuGZU2YQ3xIpJAIxV94iWO0Q2CH2QABxMERpONRu4Le6XC9V+5PImQZ2A==",
            ),
            "@agentclientprotocol/codex-acp": (
                "1.10.0",
                "sha512-b4dDCPkH/GgHRb3JelXz4QdNirdoTjO3yYM1ImUJMxVXxgZLZMguEXNhZOH2G755UKzf6ZypiiC7UHe3fKgp2Q==",
            ),
        }
        self.assertEqual(
            package["dependencies"],
            {name: version for name, (version, _) in expected.items()},
        )
        for name, (version, integrity) in expected.items():
            lock_key = f"node_modules/{name}"
            self.assertEqual(lock["packages"][lock_key]["version"], version)
            self.assertEqual(lock["packages"][lock_key]["integrity"], integrity)

    def test_public_delegate_entry_source_is_the_accepted_pin(self) -> None:
        entry = REPO_ROOT / "runtime/acpx_delegate_entry.cjs"
        self.assertTrue(entry.is_file())
        self.assertEqual(
            hashlib.sha256(entry.read_bytes()).hexdigest(),
            "f734ed38cce00f14aa3229a6b21f8c7a452d6f7c2ef46f6b362907ba6aacecbd",
        )

    def test_skill_is_generic_and_has_no_unfinished_scaffold(self) -> None:
        text = (
            REPO_ROOT
            / "plugins/agent-delegation/skills/agent-delegation/SKILL.md"
        ).read_text(encoding="utf-8")
        self.assertNotIn("TODO", text)
        self.assertIn("Delegation is not limited to coding", text)
        for target in ("Hermes", "Claude Code", "Codex", "Kimi", "zCode", "OpenCode"):
            self.assertIn(target, text)

    def test_skill_preserves_capabilities_and_documents_explicit_restrictions(self) -> None:
        skill = (
            REPO_ROOT
            / "plugins/agent-delegation/skills/agent-delegation/SKILL.md"
        ).read_text(encoding="utf-8")
        wrapper = (
            REPO_ROOT
            / "plugins/agent-delegation/skills/agent-delegation/scripts/agent_delegate.py"
        ).read_text(encoding="utf-8")
        self.assertIn("Capability is not authority", skill)
        self.assertIn("defaults to `approve-all` with Terminal advertised", skill)
        self.assertIn('default="approve-all"', wrapper)
        self.assertIn('run_parser.set_defaults(terminal=True, handler=_run)', wrapper)
        self.assertIn('"--no-terminal"', wrapper)


if __name__ == "__main__":
    unittest.main()
