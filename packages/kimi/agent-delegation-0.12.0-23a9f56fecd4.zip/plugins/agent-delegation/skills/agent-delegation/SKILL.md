---
name: agent-delegation
description: Delegate missions between Hermes, Claude Code, Codex, Kimi, zCode, OpenCode, Pi, Grok Build, or another installed ACP agent, with native session continuation and inspectable results.
---

# Agent Delegation

Give the worker a mission, relevant context, existing authority, and a useful completion condition. Let it choose the reasoning, exploration, tools, and solution. Delegation is not limited to coding. A short prompt is enough; use [task-packet.md](references/task-packet.md) for a more involved handoff.

This Skill is usable on its own. When continuing work from another Skill or agent,
pass the existing result/specification and selected state record by accessible path,
with the actual workspace, revision and necessary uncommitted artifacts. Preserve
acceptance IDs and meanings, exclusions, prior failures, key corrections and granted
authority. The worker reads those sources before reconstructing the task. No Task
State, Deep Thinking or UltraGoal installation is required on either side.

Resolve `<skill-dir>` to the absolute directory containing this loaded `SKILL.md`. Run its bundled script for every operation; do not discover another copy through PATH. Use `python3 "<skill-dir>/scripts/agent_delegate.py" list --json` if targets are unknown. Choose a target for its useful context, tools, or independent perspective; the same agent type can run another independent task.

## Submit and receive

For ordinary delegation, submit once and keep the returned `delegation_id` with the task it identifies:

```bash
python3 "<skill-dir>/scripts/agent_delegate.py" submit --to codex \
  --cwd /absolute/task/root --task-file /absolute/mission.md
```

Choose completion delivery by the **originating host**, independently of `--to`.
This Skill handles external ACP missions only.

- **Codex:** use `submit --caller codex --notify codex` when this host consumes
  its native message queue. Its independent observer sends one completion event
  to the captured originating thread. Collect its full result with `wait --id`;
  in the originating task this also removes that event if it is still queued.
  This route passed a five-minute Pi mission
  and idle wakeup on Desktop 26.903.61454; verify the consumer on other hosts.
  A `functions.exec` watcher plus `send_message_to_thread` failed the same idle
  requirement: it sent only after the next user turn. Do not treat code-cell
  persistence as independent execution. A connected App Server client can also
  deliver through `turn/start` with `toolOutput`. If neither route is available,
  keep one attached wait while the host holds the turn active, or report pending
  delivery and recover on the next user turn. Do not use model polling.
  See [host delivery and observed limits](references/operations.md#codex).
- **Claude Code / zCode / Kimi:** submit once, then run `wait --id <id> --event` once
  using the host's native background Bash tool (`run_in_background: true`). The
  host reports the observer's completion; collect with a full `wait --id <id>` then.
  The background output contains only an event and receipt path. Backgrounding
  `submit` alone reports submission, not mission completion. Do not poll TaskOutput
  or repeatedly read its output file while waiting.
- **Grok Build:** submit once with `--caller grok`, then run `wait --id <id> --event`
  through native `run_terminal_command` with `block_until_ms: 0`. End the turn;
  Grok's command-completion event wakes the same session. Read that event and
  collect once with the full `wait --id <id>`. Keep the native session open.
  Do not use Bash's `run_in_background` argument or detach the observer with `&`.
- **OpenCode:** submit once with `--caller opencode`, then run `wait --id <id> --event`
  once through the native `shell` tool with `background: true`, even when the mission
  looks short. End the turn; OpenCode reports the command's completion and resumes
  the same session. Read that event and collect once with the full `wait --id <id>`.
  Never wait in the foreground: release builds stop a foreground command at its
  shell timeout, which loses the observer while the mission keeps running. Do not
  append `&` or read the shell's output file while waiting.
- **Other hosts:** use a native background completion notification when available,
  or one attached wait when the host can keep it alive. Without a wake facility,
  retain the ID and report that limitation; do not emulate one with timed model turns.

The observer waits until this task completes or its worker is lost. It blocks on
the existing worker lock, without periodic status reads. Replace `<delegation_id>`
with the returned full ID:

```bash
python3 "<skill-dir>/scripts/agent_delegate.py" wait --id <delegation_id>
```

Read the JSON on every return; a successful command exit is not task completion.

| Returned state | Next action |
|---|---|
| `already_collected: true` | This task already collected the result. Continue without integrating or announcing it again; use explicit `--replay` only if recovery requires the original output. |
| `terminal: false` (`starting`, `queued`, or `running`) | Keep this ID and the completion observer. Do independent work or yield. |
| `wait_timed_out: true` | An explicitly bounded observation ended; the task continues. Keep its completion delivery, or arrange one background wait on this ID. Do not create a repeated model wait loop, resubmit, or cancel because an observation expired. |
| `terminal: true`, `status: success` | Read `assistant_text` and `assistant_content`, integrate the result, and verify decision-critical claims proportionally. |
| `terminal: true`, another status | Inspect the reason, partial output, and receipt before deciding how to recover. `incomplete` or `execution_state: unknown` needs inspection before retrying; the worker may have performed effects. |

`execution_state: unknown` means the wrapper cannot establish the worker's outcome.
A saved `queued` phase, zero execution time, or empty logs alone do not prove that
work never started or has stopped. Report the outcome as unresolved unless native
state or effects establish it; do not describe that delegated task as completed.
For example, `{"terminal": true, "status": "incomplete", "execution_state": "unknown", "execution_seconds": null}`
means: "The wrapper ended without a final result; native execution remains unknown.
Inspect native state and effects before retrying." Here `terminal` ends wrapper
observation; it does not establish that the native task stopped.

`status --id <delegation_id>` and `wait --event` are read-only observations. A full
terminal `wait` collects one payload per delegation ID, on every originating host,
even without notifications. Synchronous `run` also records its returned payload as
collected. A separate durable collection marker survives process restarts; the
original result receipt is preserved. When a Codex origin is known, another Codex
task's wait remains passive and cannot acknowledge it. For other hosts, only the
designated recipient should use full `wait`/`ack`; other readers use `status`.
If you already integrated a result obtained through `status` or a file read, run
`ack --id <delegation_id>` in its originating task.
An acknowledgment does not mean business acceptance. Check `notification.collection_error`
if cleanup fails; retain the receipt and recover acknowledgment without resubmitting.
If a late event is already marked `collected`, continue current work without another
result read, dispatch, or user-facing "already handled" reply.
Repeated full waits return a compact `already_collected`
event instead of replaying worker content, including concurrent waits. Use
`wait --id <delegation_id> --replay` only for deliberate rereading or recovery
after interrupted collection; the immutable receipt remains available.
Codex queue cleanup is separate from collection: an API failure can leave a compact
notice queued, but cannot replay an already-collected payload. The native queue API
is experimental and was tested on the recorded local host; do not promise permanent
API compatibility or exactly-once model behavior after crashes. Native host task
notifications may still appear; keep one observer and do not re-integrate old events.

If a submit response is lost, recover the ID from its stderr receipt or saved request before submitting again. If the host interrupts a `wait`, resume observation with the same ID; the submitted task runs independently of that observer.

The timeouts have different meanings: optional `wait --timeout` limits one diagnostic
observation (zero reads once); without it, observation waits for completion.
`submit --timeout` limits execution, excluding queue wait and session setup. Omit
the execution override to use the configured budget. Add `--queue-timeout` only
when the task needs a queue deadline; by default it waits for admission or cancellation.

## Follow up or cancel when needed

A delegation ID identifies one submitted task. A session name carries conversation context across tasks. Omit `--session` for independent work, even when several tasks go to the same target. To continue a conversation, submit a new follow-up with the same target, cwd, and `--session <name>` used for the first task. Wrapper turns sharing that session wait automatically; separate sessions or one-shot tasks can run independently.

When a specific task should stop, cancel its ID and then observe that ID until the outcome is known:

```bash
python3 "<skill-dir>/scripts/agent_delegate.py" cancel --id <delegation_id>
```

A cancellation acknowledgement is not proof that work stopped. Use task-ID cancellation for a queued task; session-wide cancellation targets the session's active turn. Cancellation and session closure are conditional controls, not routine result-collection steps. See [operations.md](references/operations.md) for synchronous `run`, session controls, receipts, and recovery.

A native `cancelled` stop reason confirms that the model turn was interrupted. Spawned terminal commands or background jobs may survive it, as observed with Codex. When those jobs also need to stop, inspect and stop the specific jobs through the target's native controls; do not infer process cleanup from the turn's stop reason.

The worker does not automatically inherit the caller's conversation or model. Pass the context it needs; use `--model` only for an explicit model choice, otherwise retain the target's defaults. Likewise pass `--config-option KEY=VALUE` (repeatable) only for an explicit session setting such as reasoning effort; each result lists the advertised `config_options`, and reasoning effort is the option in category `thought_level`. See [session configuration](references/operations.md#session-configuration-options). The wrapper launches the registered argv and records provenance. Agent names may repeat in the chain. Nested workers inherit caller/chain metadata. When metadata is absent, set `--caller` to your actual host label if known; otherwise retain `unknown`. Supply `--chain` only from known provenance.

## Authority and capabilities

Capability is not authority. Delegation carries the owner's existing authorization and cannot enlarge it. Pause only before an ungranted effect; continue unrelated analysis and preparation. Do not ask for the same in-scope authorization again merely because work moved to another agent.

Pi can initiate missions through this same CLI; pass `--caller pi` at the top level.
Use its native Skill entry `/skill:agent-delegation`.

The wrapper defaults to `approve-all` with Terminal advertised. Network, Shell, and tool choices are not removed merely because a task is described as read-only. `--authorization-note` is optional receipt metadata, never a startup gate or a permission grant.

Use `approve-reads`, `deny-all`, or `--no-terminal` only for an intentional capability restriction. ACPX cannot infer the semantic safety of arbitrary Shell commands; a restricted non-interactive permission request can return `denied`. Do not add command-text allowlists. A cwd and a prompt are not an OS sandbox; preserve any real host or tool policy required by the task.

## Read the result

The start message on stderr identifies a private receipt directory. Events and diagnostics are written there during execution. The final JSON includes the stop reason, text, content blocks, session identity, structured errors, and receipt path; partial output survives timeout and cancellation. Status text an adapter marks as outside the answer, such as Claude hook notices or Pi's startup block, is kept in `notices`, not in `assistant_text`.

Keep the delegation ID, terminal receipt and actual output references in the existing
task record, if present; do not create a second progress ledger merely for dispatch.
One designated writer integrates the worker's evidence into that record. Record the
consumer's business verdict and its check separately from transport status. Use
existing project document paths or the project's documented convention; otherwise put
new business artifacts in `delegations/<YYYY-MM-DD>-<slug>/` at the project root. On
first use, create `delegations/` with a `README.md` whose first line is
`<!-- managed-by: agent-delegation -->`; a `delegations/` folder without that line
belongs to the project, so choose another location with the user. Keep private
receipts in their existing runtime location.

`success` means the ACP turn ended normally, not that the user's outcome is proven. Integrate the result and verify decision-critical claims proportionally. Tool errors such as a missing optional file do not automatically invalidate a completed turn. Inspect their details instead of requiring an empty error list or repeating all of the worker's work.

For the managed Pi target, `pi-acp` runs the bound local Pi CLI through RPC. Its
tools execute locally, so `approve-reads`, `deny-all`, and `--no-terminal` are
rejected rather than presented as effective restrictions. The receipt reconciles
ACP `end_turn` with this mission in the mapped native Pi session; missing native
evidence is `incomplete`. A native model error is not successful delegation.

The wrapper sets no default task/result character cap; ACPX itself rejects a single incoming ACP message above 64 MiB unless `ACPX_MAX_ACP_MESSAGE_BYTES` raises it. Timeout and depth come from the registry; `doctor --to <target> --json` shows effective limits and target health. Run it when diagnosing a failure, not as a mandatory gate before each delegation.

Raw event streams grow without limit. `compact` losslessly gzips those of finished receipts and deletes nothing; see [compact finished receipts](references/operations.md#compact-finished-receipts).

Managed targets use the installed local CLI; Codex and Claude adapters bind it explicitly. `runtime_identity` separates CLI, adapter, and ACPX versions observed at startup. A warm session may still use its earlier process. A legacy session without a startup record is marked unverified. Ordinary Skill updates preserve the installed runtime; an explicit `install --update-runtime` upgrades it. After an upgrade, let old warm sessions go idle before continuing them, or close them. See [operations.md](references/operations.md) for update and recovery details.

The managed zCode target uses `zcode-acp-server` over the local CLI app-server. It resolves the CLI, account, and configured model at startup; it never guesses a fallback model. Use `install --update-zcode-adapter --targets zcode` for a targeted bridge update. See [zCode runtime](references/operations.md#zcode-runtime) for discovery overrides and readiness diagnostics.

The managed Kimi target uses native `kimi acp` with ACPX `--no-fs` so its own filesystem loads parent project instructions. Like managed Pi, it rejects `approve-reads`, `deny-all`, and `--no-terminal` because these cannot constrain native tools. Model/account configuration remains with Kimi. See [Kimi runtime](references/operations.md#kimi-runtime).

The managed `grok` target uses the official Grok Build CLI through `grok agent --no-leader stdio`; no bridge package is needed. Keep its native authentication, model defaults, and `GROK_HOME`. Like Pi, native tool paths prevent complete ACP restrictions, so `approve-reads`, `deny-all`, and `--no-terminal` are rejected. Use `--caller grok` when Grok initiates a mission, with the normal other-host completion rules above. See [Grok Build runtime](references/operations.md#grok-build-runtime).
