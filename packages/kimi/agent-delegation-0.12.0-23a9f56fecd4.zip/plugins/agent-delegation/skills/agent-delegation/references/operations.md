# Operations

## Runtime and target configuration

Each host owns one installation. Codex, Claude Code, Kimi Code, and zCode use
their native plugin managers; portable hosts use one user Skill directory.
Resolve `<skill-dir>` from the loaded `SKILL.md` and execute its bundled script.
The optional `agent-delegate` compatibility command only forwards to the absolute
`AGENT_DELEGATION_ENTRY` supplied by its caller. Without that context it fails
with instructions instead of selecting an unrelated host's version.

The historical `~/.local/share/agent-delegation/skill/scripts/agent_delegate.py`
path contains only that forwarder, preserving ACPX named-session command identity.
There is no shared `SKILL.md` or business implementation there. The bundled runner
supplies its own entry to the launcher and removes it before starting the target
host, whose subsequent delegations use that host's own loaded Skill. Active native
sessions keep their existing process until restarted; updating files is not a hot swap.

The wrapper registry is `~/.config/agent-delegation/config.json`. Its `targets`
entries are the launch source: custom targets pass their exact argv to ACPX without
a shell. Managed targets use a stable `launch_argv` entry that executes a snapshot
of the registered `argv`. A project `.acpxrc.json` agent alias cannot select another executable.
ACPX still loads its native model, authentication, MCP, and other configuration.
The installer also maintains aliases in `~/.acpx/config.json` for direct operator
use; these aliases are not a second startup gate for the wrapper.

Codex binds `CODEX_PATH`; Claude binds `CLAUDE_CODE_EXECUTABLE`. Each points to the
stable local CLI entry, rather than the adapter's bundled CLI. At adapter startup
the launcher resolves that entry once, probes the selected executable, and passes
its resolved path to the adapter. Missing executables and compatibility errors
are surfaced; there is no bundled-CLI fallback or dependency download per task.

Fresh installations default to 7200 seconds and depth 4. Existing registry values
are preserved, including longer owner-configured budgets. `--timeout` must fit the
configured maximum; `--max-depth` may lower the inherited/configured ceiling.
Neither budget counts sibling tasks or constitutes a semantic authorization gate.

Task and result text have no default character cap in the wrapper. Optional positive
`max_task_chars` limits input; `max_result_chars` limits the convenience
`assistant_text` field. `assistant_content` keeps the agent's full answer blocks and
the event file keeps every message. All configured limits are validated before the
worker starts. ACPX 0.15.1 and later rejects a single incoming ACP message above
64 MiB by default; set `ACPX_MAX_ACP_MESSAGE_BYTES` in the environment that starts
the wrapper to raise it, or `0` to disable it. A warm session owner keeps the value
it started with.

Status text that an adapter marks as outside the answer goes to `notices`, not
`assistant_text` or `assistant_content`: hook notices that claude-agent-acp tags
`_meta.claudeCode.kind: informational`, and the startup block that pi-acp declares
as `_meta.piAcp.startupInfo` in its `session/new` response. Each notice keeps its
source, kind, level and content block. Unmarked text stays in the answer.

## Session configuration options

Adapters advertise session settings as ACP config options in their `session/new`
or `session/load` response. Each result reports the latest catalog in
`config_options` (`id`, `category`, `current_value`, `values`), so a first
delegation shows which keys a target accepts. A later turn on a warm named
session receives no new catalog; the wrapper then reads ACPX's saved session
record while it still holds the session, taking `current_value` from the
selections ACPX replays before the next prompt. `null` means no catalog was
observed. Select one explicitly with
`--config-option KEY=VALUE`, repeatable; omit it to keep the target's defaults.
`requested_config_options` records the selection in the receipt.

A one-shot task passes the selections to `acpx exec --config-option` (ACPX 0.14
and later). A named session applies each with `acpx set` after `sessions ensure`
and before the prompt; ACPX saves the accepted value and replays it on reconnect,
so later turns keep it until another selection replaces it. ACPX forwards keys and
values unchecked. The adapter validates them: a rejected selection ends the task
with `status: error` before any prompt is sent (`prompt_request_count: 0`).

Reasoning effort is the option whose category is `thought_level`. Observed on
2026-10-24 with ACPX 0.21.0:

| Target | Adapter / CLI | Effort option id | Advertised values |
|---|---|---|---|
| codex | codex-acp 2.2.2, codex-cli 0.159.3 | `reasoning_effort` | `low` `medium` `high` `xhigh` `max` `ultra` |
| claude | claude-agent-acp 0.95.0, Claude Code 2.1.310 | `effort` | `default` `low` `medium` `high` `xhigh` `max` |
| grok | grok 1.0.70 | `reasoning_effort` | `xhigh` `high` `medium` `low` |
| zcode | zcode-acp-server 0.76.2 | `thought` | `low` `high` `max` |
| pi | pi-acp 0.0.33, Pi 1.4.0 | `thought_level` | from the Pi model |

Codex accepted `reasoning_effort=low` and rejected `reasoning_effort=bogus` with
`Invalid params`; Claude accepted `effort=low`. Catalogs change with adapter and
model versions, so read the current `config_options` instead of relying on this
table.

## Task observation and time budgets

`submit` starts a task-owned background wrapper and returns its `delegation_id`.
`status --id <delegation_id>` reads its current snapshot or final result.
`wait --id <delegation_id>` blocks on the worker's ownership lock until it exits,
then reads the final receipt (or reports lost ownership). No timer wakes the model
and no repeated file reads are needed. An optional `--timeout N` bounds one
diagnostic observation; zero requests an immediate snapshot. On expiry it returns `terminal: false` and
`wait_timed_out: true`, without cancelling execution. Interrupting the observer
also leaves the submitted task running. Reuse the same ID to collect its result.

`submit` and `status` returning exit zero only confirm submission or observation.
An expired `wait` also exits zero. Check `terminal` and `status` in the JSON.
A `wait` that returns a final result uses the task's outcome as its exit code.

| Option | Clock and effect |
|---|---|
| `submit --timeout N` (also `run`) | Execution budget in seconds, after queue admission and named-session setup. Defaults to the registry value. |
| `submit --queue-timeout N` (also `run`) | Optional positive limit on waiting for the wrapper session lock. Expiry ends only this waiting task. Omitted means no queue deadline. |
| `wait --timeout N` | Optional nonnegative observation duration. Omitted means wait for completion. Expiry never stops execution. |

Named-session setup has its own bounded attempt and does not subtract from the
execution budget. Receipts expose `queue_wait_seconds`, `execution_seconds`,
`execution_started_at`, and `timeout_phase` (`queue`, `setup`, or `execution`).
Execution timing includes cleanup; native startup and cancellation grace can make
wall-clock duration exceed the requested execution budget.

`run` accepts the same mission options as `submit` but keeps execution attached to
the invoking process and returns the final JSON. Use it when synchronous execution
is specifically useful and the host can keep that process alive. Interrupting
`run` can stop its task; it does not have `wait`'s observer-only semantics.

## Host completion delivery

The originating host owns result delivery. The execution target may be any
registered external ACP agent; no native subagent routing is involved.

### Common collection contract

Execution, notification, result collection, and business acceptance are separate.
`collection.json` records one payload claim per delegation ID on every host, using
the existing receipt lock (`notification.lock`) independently of notification state.
Synchronous `run` and full terminal `wait` claim the payload; `ack` records an
already-read result. Concurrent/repeated collectors return `already_collected`.
`status`, `wait --event`, and explicit `wait --replay` preserve diagnostic/recovery
access. A claim is not evidence that the model integrated or accepted the result;
after an interrupted return, use explicit replay or the immutable receipt.

A saved Codex origin protects against collection by another known task, including
submissions without queue notifications. Other hosts do not provide a portable,
verified session identity through this CLI: the designated recipient uses full
`wait`/`ack`, and independent inspectors use `status`. This is a local collection
contract, not an access-control boundary between processes of the same OS user.

### Claude Code, zCode and Kimi

Submit once. Start `python3 "<skill-dir>/scripts/agent_delegate.py" wait --id <delegation_id> --event` through the host's
native Bash tool with `run_in_background: true`. Keep both the delegation ID and
the host's background-task ID. The waiter remains attached to that background
task and exits only when the real worker ends. Do not add `&`, detach the waiter,
or background only `submit`: those report the launcher's exit rather than the
mission's outcome. Let the host's task notification trigger collection; read the
compact event after completion, then collect with a full `wait --id`. The host's
output file must not carry a second copy of the worker's full result. Native task
notifications can still be shown after an early collection; the shared collection
marker prevents another payload return. Do not claim to erase another host's UI.

When a host tears down its background tasks, the observer can end while the
submitted mission continues. Keep the delegation ID for later recovery. An output
notification about a killed observer does not prove the mission stopped.

CC's `asyncRewake` command hooks can also wake an idle session on exit code 2;
ordinary `async` hooks only deliver on a subsequent turn. Native background Bash
already covers ordinary delegation, so no global hook is installed here. zCode's
native background task notification similarly avoids a global hook.

### Codex

Background process execution and starting a model turn are separate capabilities.
The official App Server interface documents `process/outputDelta` and
`process/exited` for client-owned processes, and `turn/start` with `toolOutput` to
start a turn from an external result. A client already connected to the server
owning the originating thread can await `python3 "<skill-dir>/scripts/agent_delegate.py" wait --id <id> --event`
and deliver that compact event through `turn/start`. Use the actual thread ID;
retain its receipt and event ID for recovery and deduplication. The existing
external worker and blocking observer are sufficient; a new process-control
system is not required.

This is a documented client integration path, not an installed Desktop adapter.
Confirm the authorized connection to the server that owns this thread before
claiming it works. Starting an unrelated app-server or resuming the same saved
thread under another owner does not establish delivery to the current session.

**The local code-runner callback failed idle acceptance.** On Desktop 26.903.61454
with bundled Codex 0.153.4, a five-minute external Pi mission completed at
2026-09-09 16:33:01 UTC. The `functions.exec` watcher did not issue its callback
until 16:41:14, after a user message started a turn at 16:41:10. A surviving cell
and successful `send_message_to_thread` call during an active turn do not prove
independent execution after the parent final response. Do not use that recipe
for unattended wakeup. Keep one attached wait when the host can leave the turn
active without repeated model calls; otherwise retain the ID and report pending
delivery. Do not emulate a callback with repeated `functions.wait` or status calls.

Official interfaces: [process events](https://learn.chatgpt.com/docs/app-server#process-execution),
[starting a turn with tool output](https://learn.chatgpt.com/docs/app-server#start-a-turn).

For Codex hosts that consume their persistent message queue (including the
Desktop version verified below):

```bash
python3 "<skill-dir>/scripts/agent_delegate.py" submit --caller codex --notify codex --to zcode \
  --cwd /absolute/task/root --task-file /absolute/mission.md
```

The optional CLI path captures the actual `CODEX_THREAD_ID` and available `codex` executable at
submission. A separate observer waits on the existing worker lock and invokes
`codex queue --thread <original-id> --message <completion-event>` once. It also
reports a worker that exited without a result as `incomplete` / unknown execution.
Worker termination releases the OS lock; no completion-file polling is required.

The native queue API is experimental (`experimentalApi: true`), not a promised
stable API. Codex CLI 0.153.4 explicitly rejects `thread/queue/list` without this
capability. Official App Server docs describe experimental opt-in and supported
`turn/start(toolOutput)` clients; the independent local Desktop queue adapter was
verified through the installed CLI/schema and actual queue/idle probes. Do not
conflate those different evidence levels or treat a separate app-server as the
owner of the live model turn.

`notification.json` tracks `pending`, `sending`, `queued`, `collected`, `failed`, or `unknown`.
The event contains a stable `event_id`, delegation ID, wrapper outcome and receipt
path; it does not copy the worker's conversation into the parent. Delivery is
serialized per task. A repeated `notify` does not enqueue an already queued event.
The recipient should integrate each `event_id` once in its existing task record.
A full terminal `wait` first claims the payload through the common collection
contract. In the captured originating task it also removes only the saved queue
ID through native `thread/queue/delete` and records notification `collected`.
This short-lived App Server manages the shared persistent
queue only; it never resumes a thread or starts a model turn. A repeated `notify`
cannot resend a collected event. `status`, `wait --event`, and another task's reads
remain passive. After integrating a direct file/status read, use `ack --id <id>`
in the original task; it returns a compact acknowledgment instead of repeating
the worker text. Collection is transport bookkeeping, not business acceptance.
Concurrent or repeated full waits return `already_collected` after the first
payload claim, including when queue cleanup failed. Explicit replay and the
immutable receipt provide recovery after an interrupted return.

Queue deletion requires the host's native API. Failure leaves the notification
state intact and adds `collection_error`, without undoing result collection or deleting
receipts. A `deleted: false` response means the item is no longer queued; a model
turn already started from it cannot be undone. Keep result integration idempotent.
Never clear an entire queue or treat an event-only observer as result consumption.

ACPX 0.13.2 has an observed named-session permission accounting defect: an earlier
denial can produce exit 5 for a later clean turn. The wrapper reconciles only this
version, with a complete parsed `end_turn`, assistant output, no new permission
requests and no RPC errors. It records `status_note` and preserves raw `exit_code`;
actual current-turn permission failures and uncertain output remain failures.

**Queue acceptance is not automatic wakeup.** Some hosts may only drain queued
input at a later user turn. Verify an idle-session probe in the actual Codex host
before relying on unattended continuation. On 2026-09-09, Desktop 26.903.61454
with Codex 0.153.4 passed an isolated idle probe through this independent CLI
notifier. The parent turn ended at 17:03:26 UTC; Pi finished one `sleep 300` and
returned `PI_IDLE_R2_OK` at 17:06:11.195. The notifier attempted enqueueing at
17:06:11.222, and the completion event started a new turn in the original thread
at 17:06:13. No intervening user turn or scheduled run occurred. Delegation
`6b6350c9e2b14717a7f1d3222ef0b4b8` took 306.91 execution seconds and ended with a
verified native Pi stop. This establishes idle delivery for that configuration,
not every Codex host or recovery after an app restart.

The collection repair was rechecked on 2026-09-14 with Codex CLI 0.153.4 and an
independent 45-second worker fixture using no model. The parent turn ended before
completion; the queued event started a new turn without intervening user input.
Collecting that already-delivered event and repeating the wait suppressed replay.
Native queue deletion, concurrent collection, and explicit replay also passed.
This validates the common Codex receiver, not live acceptance of every target's
model service or another originating host's notification UI.

Codex ordinary async hooks do not start a new turn. Do not repeatedly call
`wait`, use timer prompts, or spawn a new Codex
session to disguise this capability gap. Keep the receipt and recover on the next
user turn if this host does not drain the queue.

Inspect `status --id <delegation_id>` when diagnosing delivery; it includes the
notification state. To complete a saved pending notification, or retry a known
failed delivery after correcting its cause:

```bash
python3 "<skill-dir>/scripts/agent_delegate.py" notify --id <delegation_id>
python3 "<skill-dir>/scripts/agent_delegate.py" notify --id <delegation_id> --retry
```

Both commands retain the saved destination even if invoked from another shell.
A timeout or a crash during `sending` is `unknown`: the queue may have accepted
the event. Inspect the original queue before an explicit retry. There is no
automatic retry of uncertain delivery and no claim of exactly-once handling
across process failure. Task execution is never resubmitted by notification recovery.

### Official interfaces and evidence limits

Relevant official references were checked on 2026-09-14. Documentation establishes
the host facility; it does not certify this wrapper or every host/version pair.

| Host | Official basis | Integration boundary |
| --- | --- | --- |
| Codex | [App Server experimental opt-in](https://learn.chatgpt.com/docs/app-server#experimental-api-opt-in) | Desktop queue methods require the experimental capability. Installed CLI/schema and native queue/idle probes establish support on the recorded version. |
| Claude Code | [Background Bash](https://code.claude.com/docs/en/interactive-mode#background-bash-commands), [async hook wakeup](https://code.claude.com/docs/en/hooks#run-hooks-in-the-background) | Use one native background observer. Host exit can terminate background tasks; preserve the delegation ID for recovery. |
| zCode | [Subagents](https://zcode.z.ai/cn/docs/subagents), [hooks](https://zcode.z.ai/cn/docs/hooks) | Installed 0.16.5 also exposes background Bash and completion notices. These sources and code inspection alone do not prove a live external-delegation round trip. |
| Kimi Code | [Built-in Bash tools](https://moonshotai.github.io/kimi-code/en/reference/tools.html) | Native background Bash reports completion and owns timeout/cleanup. A CLI process that exits cannot be assumed to keep observing. |
| Pi | [Extension message delivery](https://github.com/earendil-works/pi/blob/main/packages/coding-agent/docs/extensions.md) | `sendMessage` with `triggerTurn` can wake a session through a loaded extension. This Skills-only package does not install that extension; use one attached wait unless the host already supplies a wake facility. |
| OpenCode | [`shell` tool `background`](https://github.com/anomalyco/opencode/blob/464688ba686b715e28326e209b08116ad60b86e0/packages/core/src/tool/plugin/shell.ts) (source, 2.2.7) | A background command's completion notifies and resumes the session. See [OpenCode runtime](#opencode-runtime) for what was observed live. |

The host-independent collection contract was checked across all 36 combinations
of Codex, Claude, zCode, Kimi, Pi and OpenCode caller/target labels with
deterministic worker fixtures, including concurrent collectors. These are
shared-logic checks, not 36 live model-service acceptance tests.
Real Claude Code and Kimi Code origins
calling native Codex also passed background completion followed by one payload
and one compact `already_collected` result on 2026-09-14. zCode 0.16.5 submitted
and armed its background observer, but its single-prompt process then exited;
resuming that native session and collecting the original delegation passed.
That is recovery evidence, not proof of idle wakeup in zCode Desktop.
The native response included progress
text before its expected final marker; do not confuse response formatting with
delivery failure or silently discard progress content.

Observed host checks on 2026-09-09: the independent Codex queue notifier passed
idle wakeup. The earlier five-minute Pi test rejected the code-runner recipe as
an idle wakeup mechanism. Earlier code-runner cross-turn delivery was confounded by another message
opening the receiving turn first. CC 2.1.266 emitted a native `task_notification`
and automatically continued after its background observer completed. The zCode
0.16.5 live check stopped at provider quota error 429 / 1310 before tool execution,
so its delivery remains unverified. The first ten-minute interval heartbeat had
no recorded last run before the owner returned. A second, fixed-time one-run
heartbeat was scheduled for 17:11:04 UTC and independently started the original
thread at 17:11:17, after the callback-handling turn had ended at 17:09:56.
Its saved `last_run_at` was 17:11:17.218, 13.218 seconds after the due time.
It was then paused, with no next run. The callback and fixed-time fallback both
passed separately in this experiment; the original interval blocker remains
undetermined.
These checks separate host delivery from the external worker's business outcome.

For an explicitly requested callback experiment, a scheduled fallback is a separate
delivery channel with its own acceptance. Local Desktop source inspection found
that the notification policy affects completion notifications, not whether a run
starts. Interval heartbeats calculate their next eligible time from recent thread
activity and may defer for a busy thread or an input draft. A fixed-time, one-run
fallback avoids that interval calculation, but still requires the host scheduler
to run. Verify the actual scheduled timestamp, heartbeat `last_run_at`, and
receiving turn. The successful heartbeat above created no `automation_runs` row;
that table alone cannot establish whether a heartbeat ran. Saving the
automation or selecting important updates proves neither. Do not treat an idle
callback as accepted if a fallback or user message opened the receiving turn first.

## Sessions and cancellation

`submit --session <name>` (also `run`) ensures a native ACPX session and sends a
prompt. Reuse the same target, cwd, and name for continuation. Wrapper calls
sharing these values and the receipt root wait their turn before submitting to
ACPX. Queue wait does not consume execution budget. Different sessions, or calls
without `--session`, are independent; the target's own capacity still applies.
The target must implement the ACP capabilities needed for its session lifecycle.

The managed launch command stays stable across runtime upgrades. An existing warm
ACPX owner keeps its original adapter and CLI process; its startup identity stays
in subsequent receipts. The next newly started adapter uses the selected runtime
and current local CLI. Pre-launcher named sessions are discovered through ACPX's
local index and continue under their original command. They remain in the old
runtime until closed; their CLI identity is unverified without a startup record.

ACPX 0.18 and 0.19 strengthened queue-owner handoff and process-identity checks,
and those guarantees need updated clients and owners. After
`install --update-runtime`, let a warm owner started by the older ACPX finish and
go idle before continuing its session, or close the session and start a fresh
one. Mixed versions keep the older race conditions; a healthy legacy owner stays
usable. See the [v0.18.0](https://github.com/openclaw/acpx/releases/tag/v0.18.0)
and [v0.19.0](https://github.com/openclaw/acpx/releases/tag/v0.19.0) upgrade notes.

For one task, including a queued task, use:

```bash
python3 "<skill-dir>/scripts/agent_delegate.py" cancel --id <delegation_id>
```

This requests cancellation only for that invocation; an old task ID cannot cancel
a later turn. Observe the same ID until a final outcome is available. If wrapper
ownership is lost, the snapshot reports `incomplete` with
`execution_state: unknown`: this is not proof the native worker stopped. Inspect
events, partial output, and the native session before retrying a task with effects.
Elapsed timing fields are `null` when wrapper ownership is lost, because neither
the final duration nor time spent in each phase can be established.

A cancellation can land while the adapter is still starting, before the turn's
prompt is sent. ACPX 0.18 and later then withdraws the prompt and reports no ACP
stop reason; ACPX 0.13.2 still sent the prompt and cancelled the native turn. The
wrapper reports `cancelled` without a stop reason only when ACPX acknowledged the
cancellation and the event stream, which records every sent `session/prompt`, has
none for this turn: `prompt_request_count` is 0 and `status_note` says so. Without
that evidence the result stays `incomplete`.

Native cancellation interrupts a model turn; it does not guarantee that every
spawned terminal command has stopped. In the Codex 0.153.4 / codex-acp 1.10.0 live
check, `stopReason: cancelled` arrived while a previously started terminal sleep
still ran. Both Codex and Claude confirmed turn cancellation; that alone does not
establish terminal cleanup. Inspect native terminal/job state when cleanup matters, and stop the specific job using
the target's controls. The wrapper does not kill an entire warm session or guess
which unrelated/background processes should be terminated.

Only when intentionally stopping a named session's active turn, use:

```bash
python3 "<skill-dir>/scripts/agent_delegate.py" cancel --to codex --cwd /absolute/task/root --session review
```

Only when that conversation is finished and no remaining task needs it, close it:

```bash
python3 "<skill-dir>/scripts/agent_delegate.py" close --to codex --cwd /absolute/task/root --session review
```

The OS releases a wrapper's session lock on exit. Direct native ACPX calls do not
participate in this lock; keep them sequential with wrapper turns. Native ACPX
operations remain available for capabilities not exposed here; preserve the same
target, task authority, and useful evidence.

## Receipts and recovery

Each `run`, `submit`, or native session control creates a private directory under
`~/.local/state/agent-delegation/runs/`:

- `request.json`: operation, requested model/session, argv, limits, and task hash;
  it does not contain the original task prompt.
- `events.ndjson` and `stderr.log`: streamed bytes, available while work runs.
  ACPX suppresses read-file bodies in its event output, not in the worker's tools.
- `state.json`: task ID, live phase, timing, and wrapper ownership metadata.
- `worker.log`: background wrapper diagnostics for `submit`. Its private
  `launch.json` holds the launch plan, including the mission, until the worker
  consumes and removes it; inherited environment secrets are not serialized.
- `result.json`: terminal state, text, original content blocks, session ids,
  structured RPC/tool errors, runtime identity, and receipt location.
- `collection.json`: host-independent payload claim; `notification.lock` serializes
  this claim with optional host notification changes. It is not business acceptance.
- `runtime.json`: CLI path/version, adapter path/version, ACPX path/version, and
  adapter launch PID/time. Named sessions reuse the startup record under
  `.session-locks/`; the final receipt gets its own copy. `observation` distinguishes
  `adapter_launch`, `legacy_session_unverified`, and `launch_unobserved`.
- `notification.json`, `notification.log`, `notification.lock`: optional Codex
  completion destination, delivery state, diagnostics, and duplicate-send lock.

Task-ID `status`, `wait`, and `cancel` reuse this receipt instead of creating new
tasks. Cancellation writes a task-specific request for the owning wrapper; it does
not signal a saved PID or blindly cancel the active session. If the submit response
was lost, the starting message on stderr and `request.json` preserve its ID.

Terminal states distinguish normal completion (`success`), `cancelled`, `timeout`,
`denied`, `not_found`, `refused`, `incomplete`, and `error`. The underlying exit
code is retained; wrapper cancellation and timeout exit with 130 and 124.
A cancellation request succeeding does not mean the active task has already
finished; read that task's final receipt.
When the executing wrapper is interrupted, it also cancels its submitted named
session turn. `cancellation_exit_code` records that control request; an unconfirmed
cancellation is `incomplete`. Recovery controls do not consume delegation depth
or depend on task character limits or the worker executable still being present.
If ACPX returns without a terminal event, the result remains `incomplete`, even
when its process exits zero; inspect the events and diagnostics before continuing.

`rpc_errors` preserves method, code, message, and data where available.
`tool_errors` identifies client file/terminal/permission operations; the legacy
`protocol_errors` field excludes those ordinary operations. A recovered tool
error does not turn `end_turn` into failure. Raw events remain the evidence when
an adapter cannot supply enough information to classify an event.

### Compact finished receipts

`events.ndjson` keeps every streamed update, including token-level message chunks,
so long missions can leave hundreds of megabytes per receipt and nothing removes them.
Once `result.json` exists, `status`, `wait`, `ack` and replay read only that file; the raw
stream is evidence for a person, not input to the wrapper. `compact` gzips it losslessly:

```bash
python3 "<skill-dir>/scripts/agent_delegate.py" compact                 # report only
python3 "<skill-dir>/scripts/agent_delegate.py" compact --apply         # compress
python3 "<skill-dir>/scripts/agent_delegate.py" compact --older-than-days 30 --apply
```

It selects receipts whose `result.json` was written at least `--older-than-days` ago
(default 7) and whose worker no longer holds `worker.lock`. Receipts without a final
result keep their raw stream for inspection. Each stream becomes `events.ndjson.gz` only
after the compressed copy reads back byte-for-byte; the original is then removed, and no
other file is touched or deleted. Read a compacted stream with `gzip -dc events.ndjson.gz`.
The report counts compacted and skipped receipts and the bytes before and after.

## Diagnose and recover

```bash
python3 "<skill-dir>/scripts/agent_delegate.py" doctor --to codex --json
```

Doctor reports effective budgets and separates the configured CLI, adapter, and
ACPX identities in `runtimes`. This is the selection for a new process, not proof
that a warm session has upgraded. Read its receipt for the observed startup.
Version drift and unavailable version probes are informational. A missing bound
CLI or adapter is an actionable failure; fix that target or configuration layer.
Do not treat an unrelated target warning as a global startup prohibition.

Repair authentication directly through the provider. Normal task execution does
not download a replacement runtime or use `npx -y`.

## Kimi runtime

Kimi provides native ACP through `kimi acp`; no third-party bridge is needed.
Register the target without creating a second native-host Skill copy:

```bash
python3 scripts/install_user.py install --hosts none --targets kimi
```

The installer uses `kimi` on PATH before the standard user-install fallback. An
explicitly registered custom argv remains the launch authority until the owner
chooses to register it again. Stable symlinks are retained at registration and
resolved when a new process starts. CLI versions are observations, not selection
rules. `KIMI_CODE_HOME` remains the native data/configuration root and controls
portable Skill and plugin discovery; it does not select the binary directory.

The managed target sets `native_fs: true`, passing upstream ACPX `--no-fs`.
Kimi then uses its existing filesystem implementation for instruction discovery
and tools. This preserves the requested cwd and native parent/child instruction
precedence without copying instructions into a second prompt or widening ACPX's
filesystem root. See [Kimi ACP](https://moonshotai.github.io/kimi-code/en/reference/kimi-acp)
and the [native filesystem fallback](https://github.com/MoonshotAI/kimi-code/blob/main/packages/acp-server/src/acp-fs/acpFsService.ts).

Native filesystem access is not bounded by ACPX's cwd subtree. The wrapper rejects
`approve-reads`, `deny-all`, and `--no-terminal` for this managed target instead of
claiming client restrictions govern native tools. Existing host permission policy
and mission authority still apply. `runtime_identity.native_fs` records the launch
selection; warm sessions keep their previous initialized capabilities until their
process restarts. Use a fresh session when verifying the new behavior.

On 2026-09-21, Kimi 0.42.0 with the already installed ACPX 0.13.2 passed a nested-cwd
file-tool test that required distinct parent and child instruction markers, with
no ACP file errors. Test versions describe this observation, not a runtime branch.
The newer client is not required for this correction.

## zCode runtime

The official local CLI inspected on 2026-09-21 (0.16.9) exposes ZCode Protocol
`app-server`, not an ACP subcommand. The managed target uses the maintained
[community zcode-acp-server bridge](https://github.com/william0wang/zcode-acp).
Its implementation remains an npm dependency; the Skill owns discovery,
installation, launch identity, and diagnostics. See the bridge's
[provider/bootstrap troubleshooting](https://github.com/william0wang/zcode-acp/blob/main/docs/TROUBLESHOOTING.md).
This observation is not a claim about every past or future official release.

A 2026-09-21 check of npm latest ACPX 0.18.0, its
[release](https://github.com/openclaw/acpx/releases/tag/v0.18.0), and
[published agent registry](https://github.com/openclaw/acpx/blob/v0.18.0/src/agent-registry.ts)
found no built-in zCode entry or dedicated zCode change. The maintained bridge
continues through ACPX's supported custom-agent route. Do not replace it merely
because a newer generic client release exists; require applicable compatibility
evidence before changing runtime dependencies.

```bash
python3 scripts/install_user.py install --hosts none --targets zcode --update-zcode-adapter
python3 "<skill-dir>/scripts/agent_delegate.py" doctor --to zcode --json
```

The explicit zCode upgrade resolves the current npm release, saves its exact
version and lockfile in a new generation, and preserves other existing dependency
versions. The repository lockfile records the tested snapshot. Ordinary Skill
updates preserve the installed bridge; runtime execution does not fetch packages.
The old runtime and external adapters are retained for existing sessions or rollback.

Each new process resolves the CLI from `ZCODE_BIN` (legacy
`ZCODE_ACP_ZCODE_PATH` is accepted), then `zcode` on PATH, then macOS bundle metadata.
No application directory, CLI version, or Node installation directory is assumed.
Ambiguous/missing installations fail with an explicit override instruction.
`ZCODE_NODE` (legacy `ZCODE_ACP_NODE`) selects Node; otherwise PATH supplies it.
The bridge resolves provider files beside the selected CLI, including both built-in
and personal tables required by its account protocol. A CLI upgrade is followed on
new launches; an already running session keeps its existing process.

The account root is `ZCODE_HOME`, or `ZCODE_DATA_BASE_DIR/.zcode`, or `~/.zcode`.
The current native backend requires a root ending in `.zcode`; conflicting roots
are rejected rather than silently selecting another account. The configured model
comes from that account's `v2/provider_config.json` default selection, then
`cli/config.json` legacy selection. Set both `ZCODE_PROVIDER` and `ZCODE_MODEL`
to override explicitly. No fixed provider/model or first-enabled-model fallback
is selected. The bridge maps legacy IDs using the current native model catalog.
Credentials remain in zCode's own configuration.

Doctor checks native `startup/storageState` readiness without creating a session
or sending a model request: `--version` and exit status alone miss a known startup
failure. Doctor does not prove authentication or model completion. The startup
receipt records the actual CLI, adapter, Node, account root, and requested model.
A live test of bridge 0.46.6 with CLI 0.16.9 completed a configured-model request;
other CLI/bridge combinations require their own verification, not version branches.

## Install and register

From a reviewed checkout, `install --hosts kimi` installs that host's Skill and
configures only Kimi's target. Use `--targets` to select ACP targets separately
from Skill hosts; `--hosts none --targets none` installs only the shared runtime.
Existing unselected targets and custom budgets are preserved. Replacing an
unmanaged Skill or executable remains an explicit operation.

Ordinary `python3 scripts/install_user.py install` preserves an existing runtime,
including its lockfile. It does not run npm against it. The first installation,
or the following explicit upgrade, installs current stable releases:

```bash
python3 scripts/install_user.py install --update-runtime
```

The installer uses `npm install --save-exact --ignore-scripts` in a new directory
under `~/.local/share/agent-delegation/runtimes/`. It records installed versions and
the lock hash before updating the registry and command links. Failed installation
leaves the previous runtime selected. Old directories are retained for active
processes, legacy sessions, and rollback. An explicit runtime upgrade also refreshes
previously managed Codex/Claude/Pi/zCode adapter targets even if those Skill hosts are not
selected. Custom targets remain unchanged.

The repository's `runtime/package-lock.json` is a reproducible development/test
snapshot, not an installer version policy. To roll back, restore the backed-up
registry and ACPX configuration and repoint the `acpx` command to that registry's
`acpx_path`. Retain any runtime directories still needed by active tasks or sessions.

## Grok Build runtime

Register the installed official CLI with `install --hosts none --targets grok`.
The managed target runs `grok agent --no-leader stdio`, reusing ACPX sessions,
model selection, cancellation and receipts. `native_fs: true` removes the client
filesystem capability so Grok uses its own file tools, preserving reads of loaded
Skills outside the task directory. No npm adapter or runtime upgrade
is required. Login and model defaults stay in Grok; `GROK_HOME` is inherited.
Grok can also load this package through its native plugin manager and initiate
missions with `--caller grok`. Run one `wait --id <id> --event` through native
`run_terminal_command` with `block_until_ms: 0`, then end the turn. Grok delivers
the background command's completion to the idle session; collect the full result
once after that event. Keep the session open. No extra wakeup extension is needed.

Grok has native tool paths and built-in auto-approvals. `--no-terminal` can fall
back to local execution rather than remove shell access. The managed target
rejects `approve-reads`, `deny-all`, and `--no-terminal` before dispatch; native
permission rules and hooks remain effective. Do not register it manually without
this restriction metadata and assume ACP permissions constrain all native tools.

Primary references, checked 2026-10-14: [ACP agent mode](https://github.com/xai-org/grok-build/blob/main/crates/codegen/xai-grok-pager/docs/user-guide/15-agent-mode.md),
[permissions](https://github.com/xai-org/grok-build/blob/main/crates/codegen/xai-grok-pager/docs/user-guide/22-permissions-and-safety.md).

Observed on 2026-10-14 with macOS, Grok 1.0.52 and ACPX 0.13.2: normal-HOME
managed launch, file read/write, named-session recall, explicit `--model grok-4.7`,
`submit`/`wait` and one-time collection passed with `end_turn` receipts. The two
turns took 29.875s and 8.736s with no TLS retries. Grok retained the real account,
model configuration and all three configured MCP servers.

The local repair installed Hindsight's official `grok-build` hooks and disabled
only inherited global Claude hook entries tied to missing Clawd scripts, Claude
transcript parsing, or Claude token accounting. Native, project and plugin hooks
remained enabled; permission requests still occurred. Use the host's supported
hook controls and inspect the actual hook list before changing another setup.

Earlier runs had TLS retries, an incomplete receipt and a timeout. macOS power
logs show that both failing Grok executions crossed system sleep intervals
(950s and 197s). The runtime now holds `caffeinate -i` only while a delegation is
executing or queued, and releases it on completion or interruption. This prevents
idle sleep from suspending the active transport; it does not override an explicit
system sleep or prove that every remote TLS failure has the same cause. Twenty
subsequent TLS handshakes and the recorded native flows succeeded without retries.
Never disable certificate validation or promote incomplete receipts to success.

A real Grok-origin background observer also completed a Claude delegation: the
parent turn ended at 27.218s, then a native completion event woke it to validate
the receipt and write the expected marker at 79.431s, without a second user prompt
or model polling. This establishes the tested live session's idle delivery.

A subsequent real run exposed the client filesystem rejecting a user Skill outside
the cwd. After selecting native filesystem tools, a fresh normal-HOME session read
the installed Hindsight Skill and copied a file successfully in 33.354s, with no
RPC or tool errors.

## OpenCode runtime

Register the installed CLI with `install --hosts none --targets opencode`, or add
`--hosts opencode` to also install the portable Skill. The Skill directory follows
OpenCode's own global config resolution: `$OPENCODE_CONFIG_DIR/skills`, else
`$XDG_CONFIG_HOME/opencode/skills`, else `~/.config/opencode/skills`
([global roots](https://github.com/anomalyco/opencode/blob/464688ba686b715e28326e209b08116ad60b86e0/packages/util/src/global-roots.ts)).
Run the installer with the same environment OpenCode uses. The managed target runs
`opencode acp` from the `opencode` on PATH, falling back to `~/.opencode/bin/opencode`;
the selected stable entry is recorded, and its observed version never pins execution.
No adapter package or runtime upgrade is needed.
Each ACP process starts its own private OpenCode server, so the background service
and its paired browsers or apps are not involved. Login, providers, model defaults
and permission rules stay in OpenCode. The session advertises `model`, `effort`
(category `thought_level`) and `mode` options; `--config-option model=<id>` selects
one of the advertised model values.

OpenCode's ACP server forwards a permission request only when OpenCode's own rules
evaluate a tool call to "ask", and it never uses the ACP filesystem or Terminal.
Calls its rules allow run without any ACP request. The managed target therefore sets
`native_local_tools: true`, which rejects `approve-reads`, `deny-all` and
`--no-terminal` before dispatch. Use OpenCode's own permission configuration when a
task needs a real restriction. Targets registered before this change lack the flag;
register again with `--targets opencode`.

OpenCode also loads `~/.claude/skills` and `~/.agents/skills` and keeps one Skill
per id. The installer refuses any host selection that would leave OpenCode with
both its own copy and a portable Claude Code or Codex copy.

Source references, checked 2026-11-18 at OpenCode commit `464688ba` (2.2.7):
[ACP permission bridge](https://github.com/anomalyco/opencode/blob/464688ba686b715e28326e209b08116ad60b86e0/packages/cli/src/acp/permission.ts),
[Skill compatibility roots](https://github.com/anomalyco/opencode/blob/464688ba686b715e28326e209b08116ad60b86e0/packages/core/src/config/plugin/compatibility.ts),
[non-interactive run lifecycle](https://github.com/anomalyco/opencode/blob/464688ba686b715e28326e209b08116ad60b86e0/packages/cli/src/run/noninteractive.ts).

Observed on 2026-11-18 with macOS, OpenCode 2.3.0 and ACPX 0.21.0:

- ACPX `--deny-all` did not restrict OpenCode: with zero permission requests it
  wrote a file and ran a Shell command in the task directory.
- Claude Code to OpenCode through the wrapper: `submit`, one native background
  `wait --event`, then one full `wait`. The mission read a file, wrote the sum to a
  new file and returned the expected marker in 16.683s with `end_turn`; a repeated
  `wait` returned the compact collected event.
- `--config-option model=<id>` switched the session model and returned `end_turn`
  in 5.149s.
- OpenCode to Codex, driven by `opencode run` with this Skill loaded and the
  ordinary request "use the agent-delegation skill to delegate this to codex". With
  a Codex mission that ran for 130.822s, OpenCode submitted with `--caller opencode`,
  started `wait --event` through `shell` with `background: true` and ended its turn
  at 07:13:14Z. When the observer exited, OpenCode started a new turn at 07:15:25Z
  without user input, collected the payload once with a full `wait`, and reported
  the expected marker.
- With the first wording of the OpenCode rule, two of three short missions (a
  26.906s Codex mission and an OpenCode-to-OpenCode mission) were observed through a
  foreground `wait` instead. Both completed and collected once, but only because
  they finished within the model's shell timeout.
- After the rule required the background route for short missions too and named
  the reason, four parallel OpenCode-to-OpenCode runs with the same request all
  used background `wait --event`, ended the turn, resumed, collected once with a
  full `wait`, and reported the correct count. These runs used the installed
  portable Skill and OpenCode's configured default model.

Release builds leave OpenCode's `shell_timeout_background` flag off
([flag defaults](https://github.com/anomalyco/opencode/blob/464688ba686b715e28326e209b08116ad60b86e0/packages/core/src/flag.ts)),
so a foreground command that reaches its shell timeout is stopped rather than moved
to the background. A foreground `wait` would then lose its observer while the
mission keeps running, which is why the Skill requires the background route.

`opencode run` waits for the background jobs its prompt started and the turns they
wake before it exits. The interactive TUI resumes through the same server-side job
notification, but it was not observed separately here.

## Custom ACP targets

Register an already installed ACP executable when the owner requests a new target:

```bash
python3 "<skill-dir>/scripts/agent_delegate.py" register --name example \
  --argv-json '["/absolute/path/example", "acp"]' \
  --observed-version '1.2.3' --provenance 'official package example@1.2.3'
```

Registration backs up the configuration. Verify the selected target and a small
appropriate round trip before relying on a new adapter for substantial work.
