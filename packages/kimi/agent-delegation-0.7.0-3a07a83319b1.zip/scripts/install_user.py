#!/usr/bin/env python3
"""Install the agent-delegation Skill; explicitly upgrade its shared runtime."""

from __future__ import annotations

import argparse
from datetime import UTC, datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tempfile
import tomllib
from typing import Any


VERSION = "0.7.0"
DEFAULT_TIMEOUT_SECONDS = 7200
MAX_TIMEOUT_SECONDS = 7200
REPO_ROOT = Path(__file__).resolve().parents[1]
SKILL_SOURCE = (
    REPO_ROOT
    / "plugins"
    / "agent-delegation"
    / "skills"
    / "agent-delegation"
)
sys.path.insert(0, str(SKILL_SOURCE / "scripts"))
import zcode_runtime

DELEGATE_ENTRY_SOURCE = REPO_ROOT / "runtime" / "acpx_delegate_entry.cjs"
HOSTS = ("hermes", "claude", "codex", "kimi", "zcode", "opencode", "pi")
PORTABLE_HOSTS = ("hermes", "opencode", "pi")
RUNTIME_PACKAGES = ("acpx", "@agentclientprotocol/claude-agent-acp", "@agentclientprotocol/codex-acp")
LEGACY_DEFAULT_CHAR_LIMITS = {
    "max_task_chars": 200000,
    "max_result_chars": 20000,
}


class InstallError(RuntimeError):
    """A user-facing installation failure."""


def _skill_destination(home: Path, host: str) -> Path:
    if host == "zcode":
        return zcode_runtime.data_home(dict(os.environ), home) / "skills/agent-delegation"
    roots = {
        "hermes": home / ".hermes" / "skills",
        "claude": home / ".claude" / "skills",
        "codex": home / ".agents" / "skills",
        "kimi": Path(os.environ.get("KIMI_CODE_HOME") or home / ".kimi-code").expanduser() / "skills",
        "opencode": home / ".config" / "opencode" / "skills",
        "pi": Path(os.environ.get("PI_CODING_AGENT_DIR") or home / ".pi/agent").expanduser() / "skills",
    }
    return roots[host] / "agent-delegation"


def _parse_hosts(raw: str) -> list[str]:
    if raw.strip().lower() == "none":
        return []
    hosts: list[str] = []
    for item in raw.split(","):
        host = item.strip().lower()
        if not host or host in hosts:
            continue
        if host not in HOSTS:
            raise InstallError(f"Unsupported host {host!r}; choose from {', '.join(HOSTS)}, or none.")
        hosts.append(host)
    if not hosts:
        raise InstallError("At least one host is required, or pass --hosts none.")
    return hosts


def _atomic_write_text(path: Path, text: str, mode: int = 0o600) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary_path = Path(temporary)
    try:
        os.fchmod(descriptor, mode)
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary_path, path)
    finally:
        temporary_path.unlink(missing_ok=True)


def _atomic_write_json(path: Path, value: dict[str, Any], mode: int = 0o600) -> None:
    _atomic_write_text(
        path,
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        mode,
    )


def _read_json_object(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise InstallError(f"Invalid JSON in {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise InstallError(f"Expected a JSON object in {path}.")
    return value


def _remove_legacy_default_char_limits(registry: dict[str, Any]) -> None:
    for key, legacy_default in LEGACY_DEFAULT_CHAR_LIMITS.items():
        if registry.get(key) == legacy_default:
            registry.pop(key)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _managed_marker(path: Path) -> Path:
    return path / ".agent-delegation-managed.json"


def _is_managed_skill(path: Path) -> bool:
    try:
        marker = _read_json_object(_managed_marker(path))
    except InstallError:
        return False
    return marker.get("package") == "agent-delegation"


def _backup_item(source: Path, destination: Path) -> None:
    if not source.exists() and not source.is_symlink():
        return
    destination.parent.mkdir(parents=True, exist_ok=True)
    if source.is_dir() and not source.is_symlink():
        shutil.copytree(source, destination, symlinks=True)
    else:
        shutil.copy2(source, destination, follow_symlinks=False)


def _new_backup_dir(home: Path, operation: str) -> Path:
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    path = home / ".local" / "state" / "agent-delegation" / "backups" / f"{stamp}-{operation}"
    path.mkdir(parents=True, exist_ok=False, mode=0o700)
    return path


def _copy_skill(
    destination: Path,
    backup: Path,
    backup_name: str,
    replace_existing: bool,
) -> None:
    if destination.exists() or destination.is_symlink():
        if not _is_managed_skill(destination) and not replace_existing:
            raise InstallError(
                f"Refusing to replace unmanaged Skill {destination}; use --replace-existing after review."
            )
        _backup_item(destination, backup / "skills" / backup_name)
    destination.parent.mkdir(parents=True, exist_ok=True)
    staging_parent = Path(tempfile.mkdtemp(prefix=".agent-delegation-", dir=destination.parent))
    staged = staging_parent / destination.name
    retired = staging_parent / "previous"
    try:
        shutil.copytree(
            SKILL_SOURCE,
            staged,
            ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
        )
        _atomic_write_json(
            _managed_marker(staged),
            {
                "package": "agent-delegation",
                "version": VERSION,
                "installed_at": datetime.now(UTC).isoformat(),
            },
        )
        script = staged / "scripts" / "agent_delegate.py"
        script.chmod(script.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        if destination.exists() or destination.is_symlink():
            destination.rename(retired)
        staged.rename(destination)
    except Exception:
        if not destination.exists() and retired.exists():
            retired.rename(destination)
        raise
    finally:
        shutil.rmtree(staging_parent, ignore_errors=True)


def _check_native_plugin(home: Path, host: str) -> None:
    paths = {
        "claude": home / ".claude/plugins/installed_plugins.json",
        "codex": home / ".codex/config.toml",
        "kimi": _skill_destination(home, "kimi").parents[1] / "plugins/installed.json",
    }
    path = (_skill_destination(home, "zcode").parents[1] / "cli/plugins/installed_plugins.json"
            if host == "zcode" else paths.get(host))
    if path is None or not path.is_file():
        return
    data = (tomllib.loads(path.read_text()) if path.suffix == ".toml"
            else _read_json_object(path)).get("plugins", {})
    names = data if isinstance(data, dict) else [item.get("id", "") for item in data]
    if any(name.split("@")[0] == "agent-delegation" for name in names):
        raise InstallError(f"{host} already owns agent-delegation as a plugin; update it through "
                           "that host's plugin manager, not a second user Skill installation.")


def _install_forwarder(share_root: Path, backup: Path, replace_existing: bool) -> Path:
    # Keep the historical command path: ACPX named sessions use it as identity.
    canonical = share_root / "skill"
    entry = canonical / "scripts/agent_delegate.py"
    if canonical.exists() and not entry.is_file():
        raise InstallError(f"Unexpected legacy Skill layout: {canonical}")
    if (canonical / "SKILL.md").exists():
        if not _is_managed_skill(canonical) and not replace_existing:
            raise InstallError(f"Unmanaged legacy Skill: {canonical}; review before replacement.")
        _backup_item(canonical, backup / "skills/canonical")
        shutil.rmtree(canonical)
    _atomic_write_text(entry, (REPO_ROOT / "scripts/agent_delegate_forward.py").read_text(), 0o755)
    return entry


def _resolve_executable(home: Path, candidates: list[Path], names: list[str]) -> Path:
    for candidate in candidates:
        if candidate.is_file() and os.access(candidate, os.X_OK):
            return candidate.absolute()
    for name in names:
        resolved = shutil.which(name)
        if resolved:
            path = Path(resolved).absolute()
            if path.is_file() and os.access(path, os.X_OK):
                return path
    readable = ", ".join(str(path) for path in candidates) or ", ".join(names)
    raise InstallError(f"Required executable was not found: {readable}")


def _version_line(argv: list[str]) -> str:
    try:
        completed = subprocess.run(
            argv,
            text=True,
            capture_output=True,
            timeout=15,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise InstallError(f"Version probe failed for {argv[0]}: {exc}") from exc
    if completed.returncode != 0:
        raise InstallError(f"Version probe failed for {argv[0]} with exit {completed.returncode}.")
    lines = (completed.stdout + completed.stderr).strip().splitlines()
    if not lines:
        raise InstallError(f"Version probe returned no output for {argv[0]}.")
    return lines[0]


def _runtime_versions(runtime_root: Path) -> dict[str, str]:
    versions = {}
    for name in (*RUNTIME_PACKAGES, "pi-acp", "zcode-acp-server"):
        if name not in RUNTIME_PACKAGES and not (runtime_root / "node_modules" / name / "package.json").exists():
            continue
        version = _read_json_object(runtime_root / "node_modules" / name / "package.json").get("version")
        if not isinstance(version, str) or not version:
            raise InstallError(f"Missing runtime package {name} in {runtime_root}; use install --update-runtime")
        versions[name] = version
    return versions


def _install_delegate_entry(runtime_root: Path, backup: Path) -> Path:
    """Deliver the reviewed public delegate entry beside the selected runtime's SDK."""
    if not DELEGATE_ENTRY_SOURCE.is_file():
        raise InstallError(f"Missing reviewed delegate entry {DELEGATE_ENTRY_SOURCE}.")
    entry = runtime_root / DELEGATE_ENTRY_SOURCE.name
    if entry.exists():
        if _sha256(entry) == _sha256(DELEGATE_ENTRY_SOURCE):
            return entry
        _backup_item(entry, backup / "runtime" / entry.name)
    _atomic_write_text(entry, DELEGATE_ENTRY_SOURCE.read_text(encoding="utf-8"), 0o644)
    return entry


def _install_runtime(home: Path, backup: Path, replace_existing: bool,
                     update_runtime: bool = False, update_zcode_adapter: bool = False) -> tuple[Path, Path]:
    share_root = home / ".local" / "share" / "agent-delegation"
    marker_path = share_root / ".managed.json"
    if share_root.exists() and not marker_path.exists() and not replace_existing:
        raise InstallError(
            f"Refusing to replace unmanaged runtime root {share_root}; use --replace-existing after review."
        )
    registry = _read_json_object(home / ".config/agent-delegation/config.json")
    existing_root = Path(registry.get("runtime_root", share_root / "runtime"))
    if existing_root.is_dir() and not update_runtime and not update_zcode_adapter:
        # Skill updates never run npm against an existing runtime, even when it is
        # incomplete. An explicit update stages a replacement without touching it.
        # The reviewed delegate entry still refreshes beside the selected SDK.
        _install_delegate_entry(existing_root, backup)
        return share_root, existing_root
    for name in ("package.json", "package-lock.json"):
        existing = existing_root / name
        if existing.exists():
            _backup_item(existing, backup / "runtime" / name)
    npm = shutil.which("npm")
    if not npm:
        raise InstallError("npm is required to install or update the ACPX runtime.")
    node = shutil.which("node")
    if not node:
        raise InstallError("Node.js is required to install or update the ACPX runtime.")
    node_version = _version_line([node, "--version"])
    try:
        node_parts = [int(part) for part in node_version.lstrip("v").split(".")[:2]]
        node_major, node_minor = node_parts
    except (IndexError, ValueError) as exc:
        raise InstallError(f"Cannot parse Node.js version {node_version!r}.") from exc
    if node_major < 22 or (node_major == 22 and node_minor < 13):
        raise InstallError(f"The runtime requires Node.js >=22.13; observed {node_version}.")
    generations = share_root / "runtimes"
    generations.mkdir(parents=True, exist_ok=True)
    runtime_root = Path(tempfile.mkdtemp(prefix=datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ-"), dir=generations))
    try:
        if update_zcode_adapter and existing_root.is_dir() and not update_runtime:
            for name in ("package.json", "package-lock.json"):
                shutil.copy2(existing_root / name, runtime_root / name)
            packages = ["zcode-acp-server@latest"]
        else:
            _atomic_write_json(runtime_root / "package.json", {
                "name": "agent-delegation-runtime", "version": VERSION, "private": True,
            }, 0o644)
            packages = [*[name + "@latest" for name in RUNTIME_PACKAGES], "pi-acp@0.0.33"]
            if update_zcode_adapter or (existing_root / "node_modules/zcode-acp-server").is_dir():
                packages.append("zcode-acp-server@latest")
        completed = subprocess.run(
            [npm, "install", "--save-exact", "--ignore-scripts", "--no-audit", "--no-fund",
             *packages],
            cwd=runtime_root, text=True, capture_output=True, timeout=300, check=False,
        )
        if completed.returncode != 0:
            raise InstallError(f"Runtime update failed; the previous runtime is unchanged:\n{completed.stderr[-4000:]}")
        versions = _runtime_versions(runtime_root)
        _version_line([str(runtime_root / "node_modules/.bin/acpx"), "--version"])
        entry = _install_delegate_entry(runtime_root, backup)
        _atomic_write_json(runtime_root / ".agent-delegation-managed.json", {
            "package": "agent-delegation", "installed_at": datetime.now(UTC).isoformat(),
            "runtime_packages": versions,
            "runtime_lock_sha256": _sha256(runtime_root / "package-lock.json"),
            "runtime_entry_sha256": _sha256(entry),
        })
    except BaseException:
        shutil.rmtree(runtime_root)
        raise
    _atomic_write_json(
        marker_path,
        {
            "package": "agent-delegation",
            "version": VERSION,
        },
    )
    return share_root, runtime_root


def _build_managed_targets(home: Path, runtime_root: Path, names: list[str]) -> dict[str, dict[str, Any]]:
    targets: dict[str, dict[str, Any]] = {}
    candidates = {
        "hermes": home / ".local/bin/hermes", "claude": home / ".local/bin/claude",
        "codex": home / ".local/bin/codex", "kimi": home / ".kimi-code/bin/kimi",
        "opencode": home / ".opencode/bin/opencode",
        "pi": home / ".local/bin/pi",
    }
    for name in names:
        executable = (_resolve_executable(home, [], [os.environ.get("ZCODE_NODE") or os.environ.get("ZCODE_ACP_NODE") or "node"]) if name == "zcode"
                      else _resolve_executable(home, [candidates[name]], [name]))
        argv = [str(executable), "acp"]
        provenance = f"existing local {name} installation with native ACP"
        if name in ("claude", "codex"):
            package = "claude-agent-acp" if name == "claude" else "codex-acp"
            adapter = (runtime_root / "node_modules/.bin" / package).resolve()
            if not adapter.is_file() or not os.access(adapter, os.X_OK):
                raise InstallError(f"ACP adapter is missing or not executable: {adapter}; use install --update-runtime")
            argv = [str(adapter)]
            provenance = f"@agentclientprotocol/{package} with the local {name} CLI"
        elif name == "pi":
            adapter = (runtime_root / "node_modules/.bin/pi-acp").resolve()
            if not adapter.is_file() or not os.access(adapter, os.X_OK):
                raise InstallError("Pi ACP adapter is missing; use install --update-runtime")
            argv = [str(adapter)]
            provenance = "pi-acp bridging the existing local Pi CLI through RPC"
        elif name == "zcode":
            adapter = runtime_root / "node_modules/zcode-acp-server/dist/index.js"
            if not adapter.is_file():
                raise InstallError("Managed zCode ACP adapter is missing; use install --update-zcode-adapter --targets zcode")
            argv = [str(executable), str(adapter)]
        targets[name] = {"argv": argv, "version_argv": [str(executable), "--version"],
                         "observed_version": _version_line([str(executable), "--version"]),
                         "provenance": provenance,
                         "launch_argv": [str(home / ".local/share/agent-delegation/skill/scripts/agent_delegate.py"),
                                         "_launch", "--to", name]}
        if name in ("claude", "codex"):
            targets[name].update(
                cli_env={"CLAUDE_CODE_EXECUTABLE" if name == "claude" else "CODEX_PATH": str(executable)},
                adapter_package="@agentclientprotocol/" + package,
            )
        elif name == "pi":
            targets[name].update(cli_env={"PI_ACP_PI_COMMAND": str(executable)},
                                 adapter_package="pi-acp", native_local_tools=True)
        elif name == "zcode":
            targets[name]["zcode_runtime"] = True
            targets[name]["adapter_package"] = "zcode-acp-server"
            targets[name]["adapter_path"] = str(adapter)
            resolved, _ = zcode_runtime.prepare(targets[name], dict(os.environ))
            targets[name].pop("version_argv")
            targets[name]["observed_version"] = _version_line(resolved["version_argv"])
            targets[name]["provenance"] = "managed zcode-acp-server; ZCode resources and model resolved at each new launch"
    return targets


def _merge_registry(
    home: Path,
    runtime_root: Path,
    managed_targets: dict[str, dict[str, Any]],
    backup: Path,
) -> tuple[Path, dict[str, Any], Path]:
    registry_path = home / ".config" / "agent-delegation" / "config.json"
    acpx_path = home / ".acpx" / "config.json"
    _backup_item(registry_path, backup / "config" / "registry.json")
    _backup_item(acpx_path, backup / "config" / "acpx.json")
    registry = _read_json_object(registry_path)
    existing_targets = registry.get("targets")
    if existing_targets is not None and not isinstance(existing_targets, dict):
        raise InstallError("Existing delegation targets must be a JSON object.")
    targets = {**(existing_targets or {}), **managed_targets}
    for name, target in managed_targets.items():
        previous = (existing_targets or {}).get(name, {})
        if target.get("launch_argv") and previous.get("argv"):
            # Old named sessions retain their native command scope. New sessions
            # use a stable launcher whose command survives later runtime upgrades.
            target["legacy_argv"] = previous.get("legacy_argv", [])
            if not previous.get("launch_argv") and previous["argv"] not in target["legacy_argv"]:
                target["legacy_argv"] = [*target["legacy_argv"], previous["argv"]]
    registry.update(
        {
            "schema_version": 1,
            "acpx_path": str((runtime_root / "node_modules" / ".bin" / "acpx").resolve()),
            "acpx_config_path": str(acpx_path),
            "acpx_delegate_entry": str((runtime_root / "acpx_delegate_entry.cjs").resolve()),
            "runtime_root": str(runtime_root),
            "runtime_packages": _runtime_versions(runtime_root),
            "runtime_lock_sha256": _sha256(runtime_root / "package-lock.json"),
            "targets": targets,
        }
    )
    registry.setdefault("receipt_root", str(home / ".local/state/agent-delegation/runs"))
    registry.setdefault("default_timeout_seconds", DEFAULT_TIMEOUT_SECONDS)
    registry.setdefault("max_timeout_seconds", MAX_TIMEOUT_SECONDS)
    registry.setdefault("max_delegation_depth", 4)
    _remove_legacy_default_char_limits(registry)

    acpx = _read_json_object(acpx_path)
    agents = acpx.setdefault("agents", {})
    if not isinstance(agents, dict):
        raise InstallError("Existing ACPX agents must be a JSON object.")
    for name, record in targets.items():
        argv = record.get("argv") if isinstance(record, dict) else None
        if not isinstance(argv, list) or not argv:
            if name in managed_targets:
                raise InstallError(f"Delegation target {name!r} has invalid argv.")
            continue
        if name in managed_targets:
            agents[name] = {"argv": record.get("launch_argv", argv)}
        else:
            agents.setdefault(name, {"argv": argv})
    acpx.setdefault("defaultPermissions", "approve-all")
    acpx.setdefault("nonInteractivePermissions", "fail")
    acpx.setdefault("timeout", DEFAULT_TIMEOUT_SECONDS)
    _atomic_write_json(registry_path, registry)
    _atomic_write_json(acpx_path, acpx)
    return registry_path, registry, acpx_path


def _install_symlink(
    path: Path,
    target: Path,
    backup: Path,
    replace_existing: bool,
) -> None:
    if path.exists() or path.is_symlink():
        if path.is_symlink() and path.resolve() == target.resolve():
            return
        managed_root = path.parent.parent / "share" / "agent-delegation"
        is_managed = path.is_symlink() and str(path.resolve()).startswith(str(managed_root.resolve()))
        if not is_managed and not replace_existing:
            raise InstallError(
                f"Refusing to replace unmanaged command {path}; use --replace-existing after review."
            )
        _backup_item(path, backup / "bin" / path.name)
        path.unlink()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.symlink_to(target)


def _install(args: argparse.Namespace) -> int:
    home = Path(args.home).expanduser().resolve() if args.home else Path.home()
    hosts = _parse_hosts(args.hosts)
    target_names = _parse_hosts(args.targets) if args.targets is not None else hosts
    if not SKILL_SOURCE.is_dir():
        raise InstallError(f"Missing Skill source {SKILL_SOURCE}.")
    for host in hosts:
        _check_native_plugin(home, host)
    backup = _new_backup_dir(home, "install")
    update_zcode = getattr(args, "update_zcode_adapter", False)
    share_root, runtime_root = _install_runtime(home, backup, args.replace_existing, args.update_runtime, update_zcode)
    if update_zcode and "zcode" not in target_names:
        target_names.append("zcode")
    # A runtime upgrade refreshes already managed adapter targets even when the
    # selected Skill hosts exclude them; custom registrations are left alone.
    if args.update_runtime:
        existing_targets = _read_json_object(home / ".config/agent-delegation/config.json").get("targets", {})
        for name in ("claude", "codex", "pi", "zcode"):
            previous = existing_targets.get(name, {})
            if name not in target_names and (previous.get("adapter_package") or
                    str(previous.get("provenance", "")).startswith("@agentclientprotocol/")):
                target_names.append(name)
    targets = _build_managed_targets(home, runtime_root, target_names)
    forwarder = _install_forwarder(share_root, backup, args.replace_existing)
    for host in hosts:
        _copy_skill(
            _skill_destination(home, host),
            backup,
            host,
            args.replace_existing,
        )
    registry_path, registry, acpx_config = _merge_registry(
        home, runtime_root, targets, backup
    )
    local_bin = home / ".local" / "bin"
    _install_symlink(
        local_bin / "agent-delegate",
        forwarder,
        backup,
        args.replace_existing,
    )
    _install_symlink(
        local_bin / "acpx",
        Path(registry["acpx_path"]),
        backup,
        args.replace_existing,
    )
    manifest = {
        "package": "agent-delegation",
        "version": VERSION,
        "installed_at": datetime.now(UTC).isoformat(),
        "hosts": hosts,
        "backup_dir": str(backup),
        "registry": str(registry_path),
        "acpx_config": str(acpx_config),
        "runtime_root": str(runtime_root),
        "runtime_updated": args.update_runtime,
        "zcode_adapter_updated": update_zcode,
        "runtime_packages": registry["runtime_packages"],
        "runtime_lock_sha256": registry["runtime_lock_sha256"],
        "targets": sorted(targets),
    }
    manifest_path = home / ".local" / "state" / "agent-delegation" / "install-manifest.json"
    _atomic_write_json(manifest_path, manifest)
    print(json.dumps({"status": "installed", **manifest}, ensure_ascii=False, indent=2))
    return 0


def _doctor(args: argparse.Namespace) -> int:
    home = Path(args.home).expanduser().resolve() if args.home else Path.home()
    command = home / ".local" / "bin" / "agent-delegate"
    if not command.is_file() or not os.access(command, os.X_OK):
        raise InstallError(f"agent-delegate is not installed at {command}.")
    completed = subprocess.run(
        [str(command), "doctor", "--json"],
        text=True,
        capture_output=True,
        timeout=120,
        check=False,
        env={**os.environ, "AGENT_DELEGATION_HOME": str(home),
             "AGENT_DELEGATION_ENTRY": str(SKILL_SOURCE / "scripts/agent_delegate.py")},
    )
    sys.stdout.write(completed.stdout)
    sys.stderr.write(completed.stderr)
    return completed.returncode


def _uninstall(args: argparse.Namespace) -> int:
    home = Path(args.home).expanduser().resolve() if args.home else Path.home()
    hosts = _parse_hosts(args.hosts)
    registry_path = home / ".config" / "agent-delegation" / "config.json"
    registry = _read_json_object(registry_path)
    registered_targets = registry.get("targets") or {}
    if not isinstance(registered_targets, dict):
        raise InstallError("Existing delegation targets must be a JSON object.")
    custom_targets = sorted(set(registered_targets) - set(HOSTS))
    if args.remove_runtime and custom_targets:
        raise InstallError(
            "Refusing to remove the shared runtime while custom targets remain: "
            + ", ".join(custom_targets)
        )
    backup = _new_backup_dir(home, "uninstall")
    removed: list[str] = []
    for host in hosts:
        destination = _skill_destination(home, host)
        if destination.exists() and _is_managed_skill(destination):
            _backup_item(destination, backup / "skills" / host)
            shutil.rmtree(destination)
            removed.append(str(destination))
    if args.remove_runtime:
        acpx_config_path = home / ".acpx" / "config.json"
        _backup_item(registry_path, backup / "config" / "registry.json")
        _backup_item(acpx_config_path, backup / "config" / "acpx.json")
        acpx_config = _read_json_object(acpx_config_path)
        agents = acpx_config.get("agents") or {}
        if not isinstance(agents, dict):
            raise InstallError("Existing ACPX agents must be a JSON object.")
        for name in HOSTS:
            record = registered_targets.get(name)
            expected = {"argv": record.get("launch_argv", record.get("argv"))} if isinstance(record, dict) else None
            if expected is not None and agents.get(name) == expected:
                agents.pop(name, None)
        if agents:
            acpx_config["agents"] = agents
        else:
            acpx_config.pop("agents", None)
        _atomic_write_json(acpx_config_path, acpx_config)
        if registry_path.exists():
            registry_path.unlink()
            removed.append(str(registry_path))
        share_root = home / ".local" / "share" / "agent-delegation"
        marker = share_root / ".managed.json"
        if marker.exists():
            _backup_item(marker, backup / "runtime" / ".managed.json")
            shutil.rmtree(share_root)
            removed.append(str(share_root))
        for name in ("agent-delegate", "acpx"):
            command = home / ".local" / "bin" / name
            if command.is_symlink() and "agent-delegation" in str(command.resolve()):
                _backup_item(command, backup / "bin" / name)
                command.unlink()
                removed.append(str(command))
        manifest = home / ".local" / "state" / "agent-delegation" / "install-manifest.json"
        if manifest.exists():
            _backup_item(manifest, backup / "state" / "install-manifest.json")
            manifest.unlink()
            removed.append(str(manifest))
    print(
        json.dumps(
            {"status": "uninstalled", "removed": removed, "backup_dir": str(backup)},
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--home", help="Override the target home directory.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    install_parser = subparsers.add_parser("install")
    install_parser.add_argument("--hosts", default=",".join(PORTABLE_HOSTS))
    install_parser.add_argument("--targets", help="ACP targets to configure; defaults to selected hosts. Use none for runtime/Skill only.")
    install_parser.add_argument("--replace-existing", action="store_true")
    install_parser.add_argument("--update-runtime", action="store_true",
                                help="Install current stable npm releases in a new directory; retain the old runtime.")
    install_parser.add_argument("--update-zcode-adapter", action="store_true",
                                help="Stage the current zCode ACP adapter; preserve other dependency versions and the old runtime.")
    install_parser.set_defaults(handler=_install)

    doctor_parser = subparsers.add_parser("doctor")
    doctor_parser.set_defaults(handler=_doctor)

    uninstall_parser = subparsers.add_parser("uninstall")
    uninstall_parser.add_argument("--hosts", default=",".join(HOSTS))
    uninstall_parser.add_argument("--remove-runtime", action="store_true")
    uninstall_parser.set_defaults(handler=_uninstall)
    return parser


def main() -> int:
    args = _build_parser().parse_args()
    try:
        return int(args.handler(args))
    except (InstallError, zcode_runtime.ZCodeRuntimeError) as exc:
        print(json.dumps({"status": "error", "message": str(exc)}), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
