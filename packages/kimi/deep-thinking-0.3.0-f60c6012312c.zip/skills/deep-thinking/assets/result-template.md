# Inquiry result

<!-- Adapt to the requested report, decision memo, argument, article, or plan.
     A bounded embedded result may reuse an existing section. Keep a separately
     delivered or versioned result independently readable. An adopted plan can
     remain here; do not create another plan just to hand it off.
     Write in the user's language and remove all template instructions. -->

## Answer and status

Answer the original question first. State whether this is a supported conclusion,
a conditional recommendation, an unresolved disagreement, or an early-stop result.
Describe the current scope and relevant conditions; do not invent owner acceptance.

## Reasons and evidence

Explain the decisive reasoning and cite directly inspected sources near the claims
they support. Keep source observations, applicability assumptions, and inferences
distinct. The result must be understandable without reading the conversation.
Explain the premise connecting decisive evidence to the conclusion; carry its
conditions and uncertainty with the claim wherever it is summarized or handed off.

## Alternatives and objections

Where relevant, compare meaningful alternatives and the strongest objection.
Preserve a useful minority insight with its status rather than hiding disagreement.

## Conditions, limits, and next action

State prerequisites, pivotal unknowns, and what would change the conclusion. For an
actionable proposal, identify a feasible next test with observable outcomes. An
external test still to do is not a completed verification. Omit new actions when the
current purpose is already fulfilled or the user asked to stop without further work.

## Execution handoff (only for an actionable result)

Reuse an existing specification instead of writing it again. Preserve the source
direction and adopted plan/milestone where applicable, with source date or revision.
State this work's contribution and milestone exit evidence; a completed step does
not establish the milestone or long-term outcome. Omit inapplicable layers. Preserve
acceptance IDs, requirement meanings, boundaries and evidence conditions. If no
accepted execution criteria exist, state the requested outcome in prose and place
suggested criteria under Proposed execution criteria. Do not manufacture a contract
while delivering a research recommendation. Assign new requirement IDs only for a
requested contract or plan, grounded in the owner's actual requested outcomes.
Keep this table's requirement IDs unchanged from the source. Describe test cases in
the evidence column; label stricter policies and implementation choices as proposals
outside the requirement table, unless the owner already accepted them.
Do not give a chosen means or an additional future-scenario test a requirement ID.
Derive conditions faithfully from the requested outcomes; label new criteria as
proposals and keep authorized work independent of adopting optional improvements.

<!-- Keep this table only for accepted criteria or a requested contract/plan.
     Otherwise replace it with clearly proposed execution criteria. -->
| ID | Required outcome and pass condition | Evidence or independent check |
|---|---|---|
| A1 | Describe an observable result, not a prescribed work step. | Name how it will be checked. |

State exclusions, confirmed constraints, unresolved decisions and their owners.
Keep examples and tentative means labelled; neither becomes an accepted requirement
through compression or handoff. Preserve key owner wording and corrections by reference
or short exact excerpt, separately from the operational interpretation.
Separate granted implementation authority from a proposal; delivering this result
does not authorize execution. Identify the actual workspace, source documents,
relevant revision and uncommitted files, and one useful next action. Name an existing
execution-state record if there is one; no receiving Skill or extra file is required.
Remove this section for a non-actionable inquiry.
